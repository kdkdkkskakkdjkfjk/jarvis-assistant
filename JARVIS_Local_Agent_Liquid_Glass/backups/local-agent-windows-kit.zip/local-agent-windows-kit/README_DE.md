# Lokaler KI-Agent fuer Windows (kostenlose Starter-Konfiguration)

Diese Starter-Konfiguration ersetzt den kostenpflichtigen Claude-Code-Kern durch Ollama + OpenCode. Sie installiert Komponenten nicht automatisch, bis du das PowerShell-Skript selbst startest. Das Skript erstellt `C:\Users\<du>\my-agent-local`, klont die offiziellen Repositories, legt Standard-Konfigurationen an und ueberschreibt bestehende Dateien nicht.

## Was kostenlos lokal laeuft

- Modell: Qwen3 ueber Ollama (kein API-Schluessel, keine nutzungsabhaengigen Gebühren)
- Agent/Dateizugriff: OpenCode
- Gedaechtnis: Markdown-Dateien in `vault\`, angezeigt in Obsidian
- Gesicht: `ai-visualizer`
- Gestenboard: `barehands`
- Experimentelle Sprache: `voice_bridge.py`, lokale Whisper-Transkription + Windows-Sprachausgabe; schickt die erkannte Anfrage an `opencode run`.

Wichtig: Diese Komponenten sind **nicht** so nahtlos integriert wie der originale Installer. `backtalk` benutzt den Claude Agent SDK; diese Starter-Bridge ersetzt diese Schicht vereinfacht. Die Visualizer-Statusanimation wird geschaltet, echte Lippen-/Audio-Wellenform-Synchronisierung ist nicht enthalten. Die Gestenoberflaeche kann Dateien/Notizen anzeigen, aber Board-Aktionen der KI muessen spaeter separat angebunden werden.

## 1. Programme installieren

In PowerShell:

```powershell
winget install --id Git.Git -e
winget install --id Python.Python.3.12 -e
winget install --id Obsidian.Obsidian -e
winget install --id Ollama.Ollama -e
```

Installiere OpenCode separat vom offiziellen Download: https://opencode.ai/download (Windows x64). Schliesse PowerShell danach und oeffne ein neues Fenster.

Pruefen:

```powershell
git --version
py -3.12 --version
ollama --version
opencode --version
nvidia-smi
```

`nvidia-smi` zeigt den VRAM der NVIDIA-Grafikkarte. Mit mindestens etwa 8 GB VRAM zuerst Qwen3 8B versuchen. Bei weniger VRAM oder Speicherfehlern Qwen3 4B nehmen.

```powershell
ollama pull qwen3:8b
# Bei zu wenig VRAM alternativ: ollama pull qwen3:4b
```

## 2. Komponenten vorbereiten

Entpacke dieses Kit, oeffne PowerShell im entpackten Kit-Ordner und fuehre aus:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\install-components.ps1
```

Das Zielverzeichnis ist `$HOME\my-agent-local`. Dein vorhandener Download `fullstack-agent-main` wird nicht geaendert.

Wenn du `qwen3:4b` verwenden musst, oeffne `C:\Users\<du>\my-agent-local\opencode.json` und ersetze **beide** Vorkommen von `qwen3:8b` durch `qwen3:4b`. Achte darauf, dass der Modellschluessel unter `provider.ollama.models` ebenfalls `qwen3:4b` heisst.

## 3. Gedächtnis aufbauen

1. Starte Obsidian und oeffne den Ordner `C:\Users\<du>\my-agent-local\vault` als Vault.
2. In PowerShell:

```powershell
Set-Location "$HOME\my-agent-local"
opencode
```

3. Gib dem Agenten diesen Auftrag:

> Lies `components/ai-memory-vault/ai-memory-vault.md` vollstaendig. Richte das Memory-Vault-System in `vault/` ein. Wichtig: Du bist OpenCode mit lokalem Ollama-Modell, NICHT Claude Code. Verwende `AGENTS.md` und `opencode.json` statt `CLAUDE.md` und Claude-spezifischer Integration. Verwende keine kostenpflichtigen APIs oder Cloud-Modelle. Arbeite nur in `vault/` und den lokalen Projektdateien; ueberschreibe oder loesche nichts ohne meine Zustimmung. Erstelle mindestens `VAULT-INDEX.md`, ein Profil, aktive Prioritaeten, Tagesnotizvorlage und Ordner/Notizen fuer Projekte und wiederkehrende Aufgaben. Berichte, wenn ein Schritt mit dieser Umgebung nicht sicher oder nicht moeglich ist.

Das Memory-Vault-Projekt wurde primaer fuer Claude Code entwickelt; die manuelle Adaption fuer OpenCode ist erforderlich.

## 4. Gesicht starten

```powershell
Set-Location "$HOME\my-agent-local\components\ai-visualizer"
.\run.bat
```

Nutze die URL, die im Fenster angezeigt wird. Das Gesicht funktioniert auch einzeln im Demo-Modus. Fuer die echte Statusanzeige schreibt `voice_bridge.py` in `.voice_state`.

## 5. Gestenboard starten

```powershell
Set-Location "$HOME\my-agent-local\components\barehands"
.\run.bat
```

Oeffne in Chrome: http://127.0.0.1:8794/stage.html und erlaube Kamerazugriff. Der erste Start benoetigt Internet, damit MediaPipe/three.js aus CDNs geladen werden koennen. Danach koennen sie im Browser-Cache liegen. Die Konfiguration `barehands.json` zeigt bereits auf den lokalen Ordner `vault/`.

## 6. Sprach-Bridge einrichten

In einem neuen PowerShell-Fenster:

```powershell
Set-Location "$HOME\my-agent-local"
Set-ExecutionPolicy -Scope Process Bypass
.\SETUP-VOICE.ps1
```

Danach starte `START-VOICE.bat`. Beim ersten Start laedt faster-whisper das kleine Sprachmodell herunter. Fuer jede Anfrage: Enter druecken, sprechen, erneut Enter druecken. Die erkannte Anfrage geht an OpenCode; die Antwort wird mit einer lokalen Windows-Stimme vorgelesen. Die Standardkonfiguration transkribiert Deutsch und nutzt die CPU, damit CUDA-/VRAM-Konfiguration vorerst entfaellt.

Wenn keine deutsche Stimme vorhanden ist: Windows Einstellungen > Zeit und Sprache > Sprache/Sprachausgabe und ein deutsches Sprachpaket mit Sprachausgabe installieren. Die Voice-Bridge ist experimentell: Tool-Bestaetigungen, lange Antworten und einzelne Modell-Ausgaben koennen manuelle Nacharbeit erfordern. Erteile der KI keine unkontrollierten Rechte fuer wichtige Dateien.

## Sicherheits-/Kostenhinweise

- Die Modelle und Spracherkennung laden beim ersten Start Daten herunter; danach kann die lokale KI weitgehend offline arbeiten. Das Gestenboard benoetigt fuer den ersten CDN-Aufruf Internet.
- Die lokale Verarbeitung verursacht keine API-Gebuehren; Stromverbrauch, Speicherplatz und ein etwaiger Internetanschluss sind natuerlich nicht kostenlos.
- Bitte keine sensiblen Geheimnisse in Notes schreiben, solange du den lokalen Dateizugriff und deine Backup-Einstellungen nicht geprueft hast.
- Bei Weitergabe veraenderter Komponenten gelten deren jeweilige Open-Source-Lizenzen; pruefe sie vor einer Weiterverteilung.
