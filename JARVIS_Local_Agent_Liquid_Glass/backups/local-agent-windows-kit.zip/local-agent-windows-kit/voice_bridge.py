"""Experimental offline voice bridge for OpenCode + Ollama on Windows.

Records between two Enter presses, transcribes locally with faster-whisper,
sends the transcript to `opencode run`, speaks the answer with a Windows SAPI
voice via pyttsx3, and updates the face/ring state files.
"""
from __future__ import annotations

import re
import subprocess
import sys
import time
from pathlib import Path

import numpy as np
import pyttsx3
import sounddevice as sd
from faster_whisper import WhisperModel

BASE_DIR = Path(__file__).resolve().parent
VIS_DIR = BASE_DIR / "components" / "ai-visualizer"
HANDS_DIR = BASE_DIR / "components" / "barehands"
VIS_STATE = VIS_DIR / ".voice_state"
HANDS_STATE = HANDS_DIR / "state" / "state"
SAMPLE_RATE = 16_000


def set_state(value: str) -> None:
    for path in (VIS_STATE, HANDS_STATE):
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(value, encoding="utf-8")
        except OSError as exc:
            print(f"Hinweis: Statusdatei konnte nicht geschrieben werden ({path}): {exc}")


def record_audio() -> np.ndarray | None:
    input("Enter druecken, um die Aufnahme zu STARTEN ... ")
    chunks: list[np.ndarray] = []

    def callback(indata, frames, time_info, status):  # sounddevice callback
        if status:
            print(f"Audio-Hinweis: {status}", file=sys.stderr)
        chunks.append(indata.copy())

    set_state("listening")
    try:
        with sd.InputStream(
            samplerate=SAMPLE_RATE,
            channels=1,
            dtype="float32",
            callback=callback,
        ):
            input("Sprich jetzt. Enter druecken, um die Aufnahme zu BEENDEN ... ")
    except Exception as exc:
        set_state("idle")
        print(f"Mikrofonfehler: {exc}")
        return None

    if not chunks:
        set_state("idle")
        print("Keine Audiodaten empfangen.")
        return None
    return np.concatenate(chunks, axis=0).reshape(-1)


def choose_german_voice(engine) -> None:
    voices = engine.getProperty("voices") or []
    for voice in voices:
        marker = f"{getattr(voice, 'name', '')} {getattr(voice, 'id', '')}".lower()
        if any(term in marker for term in ("german", "de-de", "de_at", "de-at", "deutsch")):
            engine.setProperty("voice", voice.id)
            print(f"TTS-Stimme: {voice.name}")
            return
    print("Keine eindeutig deutsche Windows-Stimme gefunden. Es wird die Standardstimme verwendet.")
    print("Bei falscher Aussprache in Windows unter Einstellungen > Zeit und Sprache > Sprache eine deutsche Sprachstimme installieren.")


def clean_terminal_text(text: str) -> str:
    text = re.sub(r"\x1b\[[0-?]*[ -/]*[@-~]", "", text)
    return text.strip()


def call_opencode(prompt: str, continue_session: bool) -> str:
    command = ["opencode", "run"]
    if continue_session:
        command.append("--continue")
    command.append(prompt)
    env = dict(__import__("os").environ)
    env["NO_COLOR"] = "1"
    try:
        completed = subprocess.run(
            command,
            cwd=str(BASE_DIR),
            text=True,
            encoding="utf-8",
            errors="replace",
            capture_output=True,
            timeout=300,
            env=env,
        )
    except FileNotFoundError:
        raise RuntimeError("OpenCode wurde nicht gefunden. Installiere OpenCode und pruefe, ob 'opencode' in PowerShell funktioniert.")
    except subprocess.TimeoutExpired:
        raise RuntimeError("OpenCode hat nach 5 Minuten nicht abgeschlossen.")

    output = clean_terminal_text(completed.stdout or "")
    if completed.returncode != 0:
        detail = clean_terminal_text(completed.stderr or output)
        raise RuntimeError(detail or f"opencode run endete mit Code {completed.returncode}")
    if not output:
        output = clean_terminal_text(completed.stderr or "")
    return output or "Ich habe leider keine Textantwort erhalten. Bitte pruefe die OpenCode-Konsole und das Modell."


def main() -> int:
    if not (BASE_DIR / "opencode.json").exists():
        print("opencode.json fehlt. Bitte zuerst install-components.ps1 ausfuehren.")
        return 1
    print("Lade Whisper-Modell 'base' auf der CPU. Beim ersten Start wird es einmalig heruntergeladen.")
    try:
        whisper = WhisperModel("base", device="cpu", compute_type="int8")
        tts = pyttsx3.init()
        choose_german_voice(tts)
        tts.setProperty("rate", 175)
    except Exception as exc:
        print(f"Sprachkomponente konnte nicht gestartet werden: {exc}")
        return 1

    have_session = False
    print("Lokale Sprach-Bridge gestartet. Mit Strg+C beenden.")
    print("Hinweis: Wenn OpenCode bei Datei-/Shell-Aktionen eine Genehmigung verlangt, beantworte sie im selben Konsolenfenster.")
    try:
        while True:
            audio = record_audio()
            if audio is None or len(audio) < SAMPLE_RATE // 2:
                print("Aufnahme zu kurz; erneut versuchen.")
                set_state("idle")
                continue

            set_state("thinking")
            try:
                segments, _info = whisper.transcribe(audio, language="de", vad_filter=True)
                transcript = " ".join(segment.text.strip() for segment in segments).strip()
            except Exception as exc:
                print(f"Transkription fehlgeschlagen: {exc}")
                set_state("idle")
                continue

            if not transcript:
                print("Kein verstaendlicher Text erkannt.")
                set_state("idle")
                continue

            print(f"Du: {transcript}")
            prompt = (
                "Antworte auf Deutsch. Der folgende Text wurde aus Sprache transkribiert. "
                "Korrigiere offensichtliche Transkriptionsfehler anhand des Kontexts. "
                "Fuehre die angefragte Aufgabe mit den verfuegbaren OpenCode-Werkzeugen aus, "
                "wenn sie eindeutig ist. Frage bei destruktiven oder externen Aktionen vorher nach. "
                "Halte die gesprochene Antwort normalerweise kurz.\n\n"
                f"Gesprochene Anfrage: {transcript}"
            )
            try:
                answer = call_opencode(prompt, continue_session=have_session)
                have_session = True
            except Exception as exc:
                answer = f"Fehler beim lokalen KI-Aufruf: {exc}"

            print(f"Agent: {answer}\n")
            set_state("speaking")
            try:
                # Keep audible replies bounded; the full response remains in the console.
                spoken = answer if len(answer) <= 3500 else answer[:3500] + " ... Die vollstaendige Antwort steht in der Konsole."
                tts.say(spoken)
                tts.runAndWait()
            except Exception as exc:
                print(f"Sprachausgabe fehlgeschlagen: {exc}")
            set_state("idle")
    except KeyboardInterrupt:
        print("\nSprach-Bridge beendet.")
    finally:
        set_state("idle")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
