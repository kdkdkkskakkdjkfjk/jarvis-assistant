$ErrorActionPreference = 'Stop'
$Base = Join-Path $HOME 'my-agent-local'
$Components = Join-Path $Base 'components'
$Vault = Join-Path $Base 'vault'

if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
    throw "Git wurde nicht gefunden. Installiere Git for Windows, starte PowerShell neu und fuehre das Skript erneut aus: https://git-scm.com/download/win"
}

New-Item -ItemType Directory -Force -Path $Base, $Components, $Vault | Out-Null

function Write-Utf8NoBom([string]$Path, [string]$Text) {
    [System.IO.File]::WriteAllText($Path, $Text, (New-Object System.Text.UTF8Encoding($false)))
}

function Clone-Repo([string]$Url, [string]$Destination) {
    if (Test-Path $Destination) {
        if (Test-Path (Join-Path $Destination '.git')) {
            Write-Host "Vorhandenes Git-Repository bleibt erhalten: $Destination" -ForegroundColor Yellow
        } else {
            Write-Host "Ordner existiert bereits und wird nicht ueberschrieben: $Destination" -ForegroundColor Yellow
        }
    } else {
        git clone $Url $Destination
        if ($LASTEXITCODE -ne 0) { throw "git clone fehlgeschlagen: $Url" }
    }
}

Clone-Repo 'https://github.com/jaredrhod/ai-memory-vault.git' (Join-Path $Components 'ai-memory-vault')
Clone-Repo 'https://github.com/jaredrhod/ai-visualizer.git' (Join-Path $Components 'ai-visualizer')
Clone-Repo 'https://github.com/jaredrhod/barehands.git' (Join-Path $Components 'barehands')

$OpenCodeConfig = Join-Path $Base 'opencode.json'
if (-not (Test-Path $OpenCodeConfig)) {
$cfgText = @'
{
  "$schema": "https://opencode.ai/config.json",
  "model": "ollama/qwen3:8b",
  "provider": {
    "ollama": {
      "npm": "@ai-sdk/openai-compatible",
      "name": "Ollama (lokal)",
      "options": { "baseURL": "http://localhost:11434/v1" },
      "models": {
        "qwen3:8b": {
          "name": "Qwen3 8B (lokal)",
          "limit": { "context": 40000, "output": 8192 }
        }
      }
    }
  }
}
'@
    Write-Utf8NoBom $OpenCodeConfig $cfgText
}

$AgentsFile = Join-Path $Base 'AGENTS.md'
if (-not (Test-Path $AgentsFile)) {
@'
# Regeln fuer meinen lokalen KI-Agenten

- Nutze das konfigurierte lokale Ollama-Modell. Rufe keine kostenpflichtigen APIs oder Cloud-Modelle auf.
- Lies am Anfang einer neuen Aufgabe zuerst `vault/VAULT-INDEX.md`, sofern diese Datei existiert. Lies danach nur die fuer die Aufgabe relevanten Notizen.
- Nutze die Markdown-Dateien in `vault/` als dauerhaftes Gedaechtnis. Speichere wichtige neue Entscheidungen und Praeferenzen dort, aber frage bei sensiblen persoenlichen Informationen nach, bevor du sie dauerhaft notierst.
- Behaupte nicht, dich an etwas aus einer frueheren Sitzung zu erinnern, wenn es nicht im Gedaechtnis steht.
- Arbeite standardmaessig in diesem Projektordner. Aendere oder loesche keine vorhandenen Dateien endgueltig und fuehre keine destruktiven Befehle ohne ausdrueckliche Rueckfrage aus.
- Bei Aktionen mit Auswirkungen ausserhalb des Arbeitsordners oder bei Downloads/Installationen erklaere zuerst, was du vorhast, und frage nach Freigabe.
- Antworte standardmaessig auf Deutsch. Sei direkt, ehrlich und praktisch.
'@ | Set-Content -Encoding utf8 $AgentsFile
}

$Viz = Join-Path $Components 'ai-visualizer'
$VizExample = Join-Path $Viz 'ai-visualizer.json.example'
$VizConfig = Join-Path $Viz 'ai-visualizer.json'
if ((Test-Path $VizExample) -and -not (Test-Path $VizConfig)) {
    $vizObj = [ordered]@{ name = 'JARVIS'; badge = ''; face = 'board'; port = 8790; bus_dir = ''; thinking_sound = $true }
    Write-Utf8NoBom $VizConfig ($vizObj | ConvertTo-Json -Depth 5)
}

$Hands = Join-Path $Components 'barehands'
$HandsExample = Join-Path $Hands 'barehands.json.example'
$HandsConfig = Join-Path $Hands 'barehands.json'
if ((Test-Path $HandsExample) -and -not (Test-Path $HandsConfig)) {
    $VaultUrlPath = ((Join-Path $Base 'vault') -replace '\\','/')
    $handsObj = [ordered]@{
        name = 'JARVIS'
        port = 8794
        orbs = @(
            [ordered]@{ title = 'Gedaechtnis'; path = $VaultUrlPath; kind = 'notes' },
            [ordered]@{ title = 'Medien'; path = 'media'; kind = 'media' }
        )
    }
    Write-Utf8NoBom $HandsConfig ($handsObj | ConvertTo-Json -Depth 8)
}

$MediaDir = Join-Path $Hands 'media'
New-Item -ItemType Directory -Force -Path $MediaDir | Out-Null

$SetupVoice = Join-Path $Base 'SETUP-VOICE.ps1'
if (-not (Test-Path $SetupVoice)) {
@'
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
if (-not (Get-Command py -ErrorAction SilentlyContinue)) {
    throw "Python Launcher (py) fehlt. Installiere Python 3.12 und aktiviere 'Add Python to PATH': https://www.python.org/downloads/windows/"
}
py -3.12 -m venv .venv
if ($LASTEXITCODE -ne 0) { throw 'Konnte die virtuelle Python-Umgebung nicht erstellen.' }
& .\.venv\Scripts\python.exe -m pip install --upgrade pip
& .\.venv\Scripts\python.exe -m pip install numpy sounddevice faster-whisper pyttsx3
if ($LASTEXITCODE -ne 0) { throw 'Installation der Sprachpakete fehlgeschlagen.' }
Write-Host "Fertig. Starte danach START-VOICE.bat." -ForegroundColor Green
'@ | Set-Content -Encoding utf8 $SetupVoice
}

$StartVoice = Join-Path $Base 'START-VOICE.bat'
if (-not (Test-Path $StartVoice)) {
@'
@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Bitte zuerst SETUP-VOICE.ps1 in PowerShell ausfuehren.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" voice_bridge.py
pause
'@ | Set-Content -Encoding ascii $StartVoice
}

$StartFace = Join-Path $Base 'START-FACE.bat'
if (-not (Test-Path $StartFace)) {
@'
@echo off
cd /d "%~dp0components\ai-visualizer"
call run.bat
pause
'@ | Set-Content -Encoding ascii $StartFace
}

$StartHands = Join-Path $Base 'START-HANDS.bat'
if (-not (Test-Path $StartHands)) {
@'
@echo off
cd /d "%~dp0components\barehands"
call run.bat
pause
'@ | Set-Content -Encoding ascii $StartHands
}

$VoiceSource = Join-Path $PSScriptRoot 'voice_bridge.py'
$VoiceTarget = Join-Path $Base 'voice_bridge.py'
if ((Test-Path $VoiceSource) -and -not (Test-Path $VoiceTarget)) {
    Copy-Item $VoiceSource $VoiceTarget
}

Write-Host "" 
Write-Host "Komponenten vorbereitet unter: $Base" -ForegroundColor Green
Write-Host "Naechste Schritte: opencode.json pruefen, Ollama-Modell laden, Obsidian-Tresor in vault/ oeffnen und Gedachtnis mit OpenCode einrichten." -ForegroundColor Cyan
Write-Host "Hinweis: SETUP-VOICE.ps1 installiert nur lokale Audio-Bibliotheken; der Sprach-Bridge-Code muss als voice_bridge.py in diesem Ordner liegen." -ForegroundColor Yellow
