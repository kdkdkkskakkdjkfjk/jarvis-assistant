@echo off
cd /d "%~dp0"
title Jarvis - Handerkennung einrichten
where py >nul 2>nul
if not errorlevel 1 (py -3 scripts\fetch_handtracking.py) else (python scripts\fetch_handtracking.py)
echo.
pause
