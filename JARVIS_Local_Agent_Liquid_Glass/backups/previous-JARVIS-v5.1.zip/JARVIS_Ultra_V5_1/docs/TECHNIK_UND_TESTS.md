# JARVIS Ultra 5 – technischer Stand

Stand: 28. Oktober 2026. Grundlage ist die hochgeladene Datei
`jarvis_komplett_ueberarbeitet_v4_citylab.html`; keine unabhängige Ersatzdemo.

## Befund und Reparatur

Die ursprüngliche Gebäudeansicht bestand aus Leaflet-Umrissen und einer
schematischen SVG-Etagenansicht. Der separate Cesium-Globus lud lediglich
Bildkacheln auf ein Ellipsoid. Es fehlten eine Gebäudequelle und eine
Geländequelle; die Farbe war nicht die Ursache.

Die neue City-Intelligence-Ansicht benutzt eine einzige, erst bei Bedarf
initialisierte Cesium-Engine. Wiener Baukörper werden über den öffentlichen
WFS der Stadt Wien geladen. Für andere Gebiete verwendet die Anwendung
Overpass/OSM-Geometrie. Multipolygon-Innenhöfe und zusammengesetzte Ringe werden
berücksichtigt. Höhenherkunft ist sichtbar. Bei Wiener Daten wird die Differenz
O_KOTE minus T_KOTE benutzt; absolute Wiener-Null-Koten werden nicht fälschlich
als Gebäudehöhe oder ellipsoidische Höhe interpretiert. Überbauungen verwenden
U_KOTE relativ zum selben Bezugspunkt.

Gebäude werden geometrisch extrudiert, mit sichtbaren Dach- und Wandmaterialien.
Das sind keine fotogrammetrischen Fassaden und keine echten Indoor-Grundrisse.
Optional unterstützt die Engine World Terrain und ion-3D-Tiles. Ohne Token
bleibt die Geländeoberfläche ein Ellipsoid. Eine Aufbereitung vollständiger
Europa-Datensätze wurde nicht durchgeführt.

## Architektur

- Bestehende HTML-Anwendung: Seitenleiste, Kalender/ICS, Stundenplan/OCR, Kameras,
  lokale Werkzeuge und Piper-Sprachausgabe bleiben erhalten.
- `assets/core.js`: Transport, Zeitlimits, sichere Links, Anfragezuordnung.
- `assets/world.js`: Kamera, Geometrie, Inspektor, Ortssuche, begrenztes Streaming.
- `assets/ultra.js`: Kontextfenster, Gespräch, Einstellungen, System/Smart Home.
- `assets/motion.js`: 104 registrierte Zustandszuordnungen für 26 Komponentenfamilien
  und vier wiederverwendbare Feedback-Bewegungen. Das sind nicht 104 individuell
  gestaltete Animationen. Reduzierte Bewegung wird unterstützt.
- `jarvis_server.py`: Standardbibliothek, SQLite-Cache, Quelladapter, Schlüssel,
  lokale API. Kein allgemeiner URL-Proxy und keine Shell-/PC-Steuerung.
- SQLite-Verbindungen des Caches werden nach jeder Transaktion explizit
  geschlossen; das vermeidet unter Windows gesperrte temporäre Cache-Dateien.
- Cesium 1.119.0, Leaflet 1.9.4, JSZip 3.10.1 sind im ZIP enthalten. Optionale
  Piper-Modelle und Google OAuth kommen weiterhin vom jeweiligen Anbieter.

Vier nahe Geometriekacheln werden sequenziell geladen; maximal zwölf Kacheln
bleiben normalerweise im Szenencache. Geteilte Gebäude werden referenzgezählt.
Das Objektlimit von 6.500 ist eine weiche Grenze: die aktuell benötigten vier
Kacheln werden nicht mitten im Laden verworfen. Sehr dichte Ausschnitte können
sie überschreiten. Der Backend-Cache ist auf ca. 128 MB Nutzdaten begrenzt.
Die SQLite-Datei kann bereits reservierten Speicher behalten.
Beim Ansichtswechsel pausiert die Render-Schleife. Ein Orbit läuft nur auf
Knopfdruck. Rasterbilder werden ausschließlich für die aktuelle Ansicht vom
Kartendienst geladen; das Vorbereitungsskript lädt keine Rasterkarten vorab.

## Durchgeführte Prüfung

| Prüfung | Ergebnis |
|---|---|
| Python-Backendtests | 32 bestanden |
| Anfragezuordnung und sichere Links | 22 Prüfungen bestanden |
| Inline-/Modul-JavaScript-Syntax | geprüft |
| Start im echten Headless-Chromium | erfolgreich, keine JavaScript-Laufzeitfehler |
| Wien-3D live | 2.627 Baukörper, vier Kacheln, WebGL aktiv |
| Satellitenbild und Gebäude | im Browser visuell geprüft |
| Szenenpause bei Verlassen | bestätigt |
| Rechnung 12 + 8 × 2 | 28, kein unpassendes Kontextfenster |
| Wetteransicht Wien/morgen | echte API-Antwort und Vorhersage gerendert |
| Geschäftssuche Lidl | 30 echte Photon-Treffer mit Koordinaten; Umkreisfilter implementiert |
| Ortssuche Wien | sechs echte Treffer im Live-Test |
| Nachrichten Wien | 30 datierte RSS-Treffer im Live-Test |
| Commons-Bilder | acht echte Bilddatensätze mit Lizenzmetadaten |
| Telefonbreite 390 px | Dokumentbreite 390 px, kein horizontaler Überlauf |
| Mikrofon, Lautsprecher und Piper auf Nutzer-PC | noch lokal abzunehmen |
| Authentifizierte KI/Google/HA/ion | ohne Nutzerzugang nicht Ende-zu-Ende geprüft |
| Langzeittest über Nacht | nicht durchgeführt; wiederaufnehmbares Skript enthalten |

Die Browserprüfung nutzte einen Software-WebGL-Treiber. Der Testbrowser musste
für die hier eingesetzte Netzwerk-Testproxy-CA Zertifikatfehler ignorieren;
die ausgelieferte Anwendung deaktiviert keine Zertifikatsprüfung.
Fixtures in Tests sind nur Tests und werden niemals als echte App-Daten geliefert.

Öffentliche Overpass-Instanzen liefen im Test in Zeitüberschreitungen. Deshalb
wird Wien gezielt aus dem funktionierenden offiziellen WFS versorgt. Bei
Ortssuchen ist Photon als tatsächliche alternative Datenquelle implementiert.
Außerhalb Wiens ist die OSM-Gebäudepipeline implementiert und geometrisch getestet,
aber wegen der Overpass-Ausfälle hier nicht durchgängig live verifiziert.

## Grenzen und nötige Einrichtung

- Detailreiche Fassaden, Dachformen/Photogrammetrie und Geländehöhen erfordern
  eine geeignete zusätzliche Datenquelle/ion-Freigabe. Wiener Baukörper sind
  tatsächliche Vermessungsprismen, kein vollständiges Dachmodell.
- Öffnungszeiten nur, wenn die Kartendaten sie liefern. Keine erfundenen
  Bewertungen, Geschäftsaufnahmen oder Öffnungszustände. Routen öffnen Google
  Maps mit den ausgewählten Koordinaten; es gibt keinen neuen eigenen Routenserver.
- Gemini-Websuche ist implementiert; Claude ohne Suchwerkzeug weist auf fehlende
  Live-Recherche hin. Modellzugriff und Anbieterkontingente müssen zum Konto passen.
- Finanz-, Sport-, Verkehrs- und Musik-Dashboards mit eigenen strukturierten
  Live-Feeds wurden nicht implementiert. Entsprechende Wissensanfragen laufen
  über Text und, wenn angefordert/erkannt, Gemini-Websuche. Neue Visualisierungen
  können über `JarvisUltra.registerVisual(type, renderer)` ergänzt werden.
- Home Assistant liefert Geräte- und Sensorstatus. Nur bestätigte Lichtaktionen
  sind ausführbar. Räume, Szenen und zusätzliche Gerätesteuerungen bleiben offen.
- Schlüsseldatei ist lokal und über den Webserver nicht abrufbar, aber kein
  verschlüsselter OS-Tresor. Der ion-Lesetoken ist absichtlich browseröffentlich.
- Browser-Spracherkennung bleibt browserabhängig. Der bestehende Audio-Fallback
  sendet nur mit Zustimmung an Gemini. Hörbare Qualität/Erkennungsrate und
  reale Geräte lassen sich ohne die Hardware des Nutzers nicht bestätigen.
- Die Benutzeroberfläche übernimmt Farben, Ebenen und Panels der Referenzen;
  die gezeigten aufwendigen Interior-/Transport-Simulationen sind nicht nachgebaut.

## Quellen und Lizenzen

- Stadt Wien, Baukörpermodell und Höhenbezug:
  https://www.wien.gv.at/stadtplanung/baukoerpermodell-produktinformation
- WFS und Koordinatensysteme:
  https://digitales.wien.gv.at/open-data/geowebservices/
- Wiener Daten: `https://data.wien.gv.at/daten/geo`, Typ `ogdwien:FMZKBKMOGD`,
  EPSG:4326; Attribution Stadt Wien – data.wien.gv.at, CC BY 4.0.
- OSM-Daten: https://www.openstreetmap.org/copyright (ODbL).
- Overpass: https://overpass.private.coffee/ ; https://overpass-api.de/
- Photon: https://photon.komoot.io/ (OpenStreetMap-basierte Ortssuche).
- Imagery: Esri World Imagery; Esri, Maxar, Earthstar Geographics, GIS User Community.
- Cesium: https://cesium.com/learn/cesiumjs-learn/cesiumjs-quickstart/
- Open-Meteo: https://open-meteo.com/ (CC BY 4.0; Tarif-/Nutzungsbedingungen beachten).
- Nachrichten: RSS-Feeds von ORF/tagesschau bzw. thematische Google-News-RSS-Suche.
  Artikel und deren Bilder behalten die Rechte der jeweiligen Herausgeber.
- Bilder: Wikimedia Commons, mit individueller Datei-, Urheber- und Lizenzangabe.
- Gemini: https://ai.google.dev/api/generate-content und Search-Grounding-Dokumentation.

Das Originalarchiv ist in `original/` gesichert. Es enthält die Ausgangsversion;
die laufende Anwendung lädt daraus keine Dateien.
