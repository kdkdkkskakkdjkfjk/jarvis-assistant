# GitHub-Projekte: Quellcode- und Integrationsprüfung

Stand: 30. Oktober 2026. Repository-Metadaten, README, Lizenzdateien/Metadaten,
Dateibäume und repräsentative Implementierungen wurden auf GitHub gelesen.
Es wurde kein fremder Anwendungscode übernommen.

| Projekt | Geprüfter Ansatz und technischer Befund | Lizenz / Windows / Entscheidung |
|---|---|---|
| [J.E.S.T.E.R](https://github.com/heeelol/jester) | `src/hands/gestures.js`, `src/interaction/controller.js`, `src/voice/jester.js`: normalisierte Landmarken, Hysterese, Ein-/Zwei-Hand-Transformation und strukturierte Sprachaktionen. Express/OpenAI-Proxy und Electron-Overlay. Junges Repository; kleiner Funktionsumfang. | Keine Lizenzdatei oder GitHub-Lizenzmetadaten gefunden. Keine Codeübernahme. Verwendete Gestenideen sind in der vorhandenen MediaPipe-Zustandsmaschine bereits unabhängig implementiert. |
| [Open Interface](https://github.com/AmberSahdev/Open-Interface) | `app/models/openai_computer_use.py`: Screenshot→Modellschritte→Computer-Tool-Rückgabe-Schleife mit Sicherheitschecks. Screenshotübertragung an Modellanbieter und freie Maus-/Tastaturschritte erhöhen Datenschutz- und Fehlbedienungsrisiken. | GPL-3.0; README nennt Windows-Unterstützung. Nicht eingebunden: Lizenz-Copyleft und zu offene Steuerungsoberfläche. Jarvis behält bestätigte, eng begrenzte Aktionen. |
| [barehands](https://github.com/jaredrhod/barehands) | `server.py` beschreibt ein lokales Befehls-/Statusprotokoll, lokale Notizordner, Medienablage und Hand-Board. README beschreibt WebGL/MediaPipe-Orbs und Glas-Karten. | AGPL-3.0-or-later, Windows-11-Startskript. Kein Code übernommen. Jarvis hat bereits lokale Landmarken und Dragging; ein zweiter Szenenserver/Datei-Orb wäre eine getrennte Parallel-App. |
| [Dylan Leitenberg JARVIS](https://github.com/dylanleitenberg-tech/JARVIS) | `jarvis/vision/gestures.py` nutzt Arming, stabile Frames und Cooldowns; `jarvis/control/actions.py` registriert Modell-/Gesten-/HUD-Aktionen zentral. README beansprucht CAD- und Desktop-Aktionen, weist aber macOS-Tests aus. | MIT. README sagt Windows-Installer nicht getestet. Nützliche Stabilitätsprinzipien entsprechen der bestehenden Gesten-Engine; Python-GUI-Steuerung und CAD-Toolchain wären zusätzliche, hier ungeprüfte Prozesse. |
| [Iron Interface](https://github.com/collidingScopes/iron-interface) | README und `voice-control.js`: Hand-Orbit/Zoom und Sprachwechsel für ein Partikelszenario. Spracherkennung startet im Beispiel sofort und nutzt Englisch. | Keine Lizenzdatei/Metadaten gefunden; letzter Push in 2025. Kein Code übernommen. Jarvis-Kamera bleibt opt-in; die 3D-Welt hat echte Kameraaktionen und der Hologramm-Viewer 3D-Geometrie. |
| [3D Model Playground](https://github.com/collidingScopes/3d-model-playground) | README dokumentiert Three.js/MediaPipe/Web Speech, Drag/Rotate/Scale/Animate und GLB/GLTF-Import. GitHub zeigt keine Lizenzmetadaten/Lizenzdatei. | Kein Code übernommen. Der Jarvis-Viewer erhält jetzt einen lokal verarbeiteten OBJ-Import ohne neue Runtime-Abhängigkeit. GLB/GLTF ist damit nicht abgedeckt. |
| [Priler/jarvis](https://github.com/Priler/jarvis) | Rust/Tauri/Svelte, Vosk-/ONNX-Modellloader, Lua-Kommandos; README nennt sich veraltet, NLU/Chat unvollständig und derzeit Russisch als unterstützte Sprache. | GitHub meldet `NOASSERTION`; keine belastbare Wiederverwendungslizenz festgestellt. Vollständiger zusätzlicher Rust-Stack und Modellpakete wären auf dem Ziel-PC zu schwer. Kein Code übernommen. |

## Was in Jarvis zusammengeführt ist

- Opt-in MediaPipe-Kamera, Pinch-Klick/Drag, Zwei-Hand-Skalierung/Drehung,
  Wisch-/Scrollgesten, Kalibrierung, Glättung, Cooldowns und Trackingverlust.
- Sprachsteuerung auf den vorhandenen Jarvis-Intent-/KI-Pfad, vorhandene
  Piper-Ausgabe, Wetter-/News-/Ortsdaten, Karten-/Gebäudemodell und lokale
  bestätigte Home-Assistant-Lichtaktionen.
- Prozedurale 3D-Objekte und ein browserlokaler OBJ-Import im bestehenden Labor.
- Sprachbefehle wählen Globus/Kern/Gitter und setzen Größe, Drehung oder Ansicht
  des aktuellen Hologramms. Beispiele: „Zeige das Hologramm Globus“, „Vergrößere
  das Hologramm“, „Setze das Hologramm zurück“.
- Liquid Glass Brown mit blauen Jarvis-Lichtern, plus umschaltbare Obsidian-Variante.

Bewusst nicht enthalten sind frei laufende KI-Maus-/Tastaturautomation,
Screenshot-Uploads, Datei-/Notiz-Orbs, CAD-Generierung sowie GLB/GLTF-Lader.
Diese Funktionen brauchen andere Berechtigungen, Datenflüsse oder Toolchains;
die genannten Implementierungen erlauben keine kompatible, lizenzklare und
verlässlich abgesicherte Übernahme in diesem Schritt. Das Projekt behauptet
keine Ende-zu-Ende-Funktion dafür.
