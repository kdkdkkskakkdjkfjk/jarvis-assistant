# Handsteuerung, Hologramm und Recherche – Stand 29. Oktober 2026

## Was neu ist (Version 5.1)

| Baustein | Datei | Zweck |
|---|---|---|
| Gestenlogik | `assets/gesture-engine.js` | Reine Logik ohne Kamera/DOM: One-Euro-Glättung, Pinch mit Hysterese und Frame-Entprellung, Klick vs. Ziehen, Wischen mit Ruhephase und Abklingzeit, Scrollen (Zeige- + Mittelfinger), Zwei-Hand-Zoom/Drehen, Halten der offenen Handfläche (einmal pro Halten), Verlust-Erkennung (lässt gehaltene Pinch/Ziehen los) |
| Steuerung/UI | `assets/hands.js` | Kamera nur nach Klick, Berechtigungsfehler, Kamera wird bei Aus/Tab-Wechsel/Seitenverlassen freigegeben, MediaPipe-Laden, Cursor, Aktionen, Einstellungen, Kalibrierung, Tastatur-Alternativen |
| 3D-Labor | `assets/hologram.js` + Ansicht „Hologramm“ | Echte 3D-Geometrie (Rotationsmatrizen, Perspektive, Tiefenschattierung) auf Canvas 2D; rendert nur wenn sichtbar; senkt Punktdichte automatisch bei langsamen Frames |
| Weltsteuerung | `JarvisWorldControl` in `assets/world.js` | Zoom, Verschieben, Drehen, Neigen der Cesium-Kamera für Zwei-Hand-Gesten |
| Diagnose | `GET /api/diagnostics` | Prüft Konfiguration/Abhängigkeiten, liefert nie Schlüssel |
| Einrichtung | `scripts/fetch_handtracking.py`, `Setup-Handtracking.bat` | Lädt MediaPipe einmalig lokal (HTTPS, atomar, SHA-256-Manifest) |
| Sprache | `assets/core.js`, `assets/ultra.js` | „Handsteuerung ein/aus“, „Zeig mir das Hologramm“, „Nächstes Panel“ |

## Gesten und Tastatur-Alternativen

| Geste | Wirkung | Alternative |
|---|---|---|
| Pinch (Daumen+Zeigefinger) | Klick auf Button/Karte/Link | Maus, Enter |
| Pinch halten + bewegen | Karte ziehen, Fenster (Objektdetails) verschieben, Regler setzen, Hologramm drehen | Maus ziehen |
| Zwei Hände pinchen, auseinander/drehen/bewegen | Hologramm skalieren/drehen; 3D-Welt zoomen/verschieben/drehen | Mausrad, Strg+Ziehen, +/−, Q/E |
| Offene Hand schnell seitlich | Panel wechseln | Alt+←/→ |
| Zeige- + Mittelfinger hoch, vertikal bewegen | Scrollen | Alt+↑/↓, Mausrad |
| Offene Handfläche ~0,7 s halten | Konfigurierbar: pausieren / Kontrollraum / Antwort stoppen / nichts | Schalter „Pause“ |
| – | Handsteuerung ein/aus | Alt+H, Chip oben rechts, Sprachbefehl |

Die Bedeutung von „Konfigurierbare Gesten“ ist bewusst begrenzt: Offene Handfläche und Wischen sind in den Einstellungen umbelegbar. Eine freie Zuordnung beliebiger neuer Gesten gibt es nicht.

## Datenschutz

- Kamera startet nur nach deinem Klick, Alt+H oder Sprachbefehl; der Chip „Hand aktiv“ zeigt es an.
- Bilder werden im Browser ausgewertet. Es gibt keinen Upload und keine Speicherung. Gespeichert werden nur Einstellungen (`localStorage`: Empfindlichkeit usw.).
- Beim Ausschalten, Verbergen des Tabs oder Verlassen der Seite werden alle Kamera-Tracks gestoppt und das Modell freigegeben.
- Ohne lokale Dateien fragt Jarvis vor dem Laden aus dem Internet (jsDelivr, storage.googleapis.com) um Zustimmung.

## Recherche-Notiz aus der ZIP (durch aktuelle Prüfung ersetzt)

Die folgende Tabelle beschreibt nur den damaligen Stand vor der aktuellen
Prüfung. Sie ist nicht mehr maßgeblich. Aktuelle Quellcode-, Lizenz- und
Integrationsbefunde: [`GITHUB-PROJEKTVERGLEICH.md`](GITHUB-PROJEKTVERGLEICH.md).

| Projekt | Erkenntnis | Entscheidung |
|---|---|---|
| heeelol/jester | Beschreibung: MediaPipe + three.js + OpenAI-Sprache; Gesten→Transformationen (Pinch greifen/bewegen, zwei Hände skalieren/drehen), sehr junges Projekt, Lizenz im Treffer nicht sichtbar | Konzept als Anregung; **kein Code übernommen**, eigene Implementierung |
| MediaPipe Tasks Vision (`@mediapipe/tasks-vision`) | Apache-2.0 (Dateikopf der Google-Beispiele), Web-API `HandLandmarker`, `numHands`, GPU/CPU | **Verwendet** (fest auf 0.10.14) |
| Open-Interface, barehands, iron-interface, 3d-model-playground, dylanleitenberg-tech/JARVIS, Priler/jarvis | **Nicht untersucht** | Nicht integriert |
| (Namensverwechslung) eleow/Gesture-Recognition-and-Control | Nutzt den „Jester“-Datensatz, Python, MIT | Nicht passend (kein Browser) |

Computersteuerung (Open-Interface-Stil) wurde bewusst **nicht** gebaut: Es gibt weiterhin keine Shell- oder PC-Steuerung, nur die bestehenden bestätigten Home-Assistant-Lichtaktionen.

## Lizenzen der neuen Teile

- MediaPipe Tasks Vision: Apache-2.0. Modell `hand_landmarker.task` stammt aus Googles öffentlichem Modellspeicher (Bedingungen im MediaPipe-Modellkarten-Hinweis prüfen). Nach dem Setup liegt die Lizenzdatei in `assets/vendor/mediapipe/`.
- Gestenlogik, Hologramm und Steuerung: eigener Code, keine Fremdquellen kopiert.

## Bekannte Grenzen

- Erkennung wurde mit synthetischen Landmarks und Chromiums Testkamera geprüft, **nicht** mit echter Hand und echter Webcam.
- Leistung auf GTX 1060 (3 GB) nicht gemessen. Die Handerkennung läuft im Browser über GPU-Delegate, bei Fehlern automatisch CPU; das Hologramm benötigt kein WebGL.
- Cesium-Welt: Gebäude, Satellitenbilder und Klick auf Geschäfte benötigen Internet und wurden in dieser Umgebung nicht live geprüft (nur Start der Engine und Kamerasteuerung).
- Das Hologramm zeigt prozedurale, illustrative Objekte; keine geladenen glTF-Modelle.
- Keine Inhaltssicherheitsrichtlinie (CSP): die bestehende Seite nutzt Inline-Skripte.
