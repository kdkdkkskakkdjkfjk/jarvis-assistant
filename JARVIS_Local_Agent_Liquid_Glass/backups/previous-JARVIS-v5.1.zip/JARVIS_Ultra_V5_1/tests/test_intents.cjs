const assert=require('node:assert/strict');
const {intent,url}=require('../assets/core.js');
const cases=[
 ['Wie wird das Wetter morgen in Wien?','weather'],['Rechne 12 + 8 * 2','math'],['Was ist 2 plus 2?','math'],
 ['Zeig mir Wien','place'],['Zeig mir einen mathematischen Beweis','text'],['Erkläre Quantenphysik','text'],
 ['Aktuelle Nachrichten zu: Wien','news'],['Suche Bilder: Wien','images'],['Suche im Web: neueste Weltraummission','search'],
 ['Finde Lidl in Wien','places'],['Zeige Geschäfte in Wien','places'],['Finde Restaurants in meiner Nähe','nearby'],
 ['CPU Auslastung','system'],['Smart Home Geräte','home'],['Schalte Wohnzimmer an','home'],['Zeig meinen Kalender','calendar'],
 ['Hallo','text'],['Was ist ein schwarzes Loch?','text'],
 ['Schalte die Handsteuerung ein','hands'],['Handsteuerung ausschalten','hands'],['Handtracking aktivieren','hands'],['Zeig mir das Hologramm','view'],['Öffne das 3D-Labor','view'],
 ['Zeige das Hologramm Globus','holoModel'],['Wähle das 3D-Modell Gitter','holoModel'],['Vergrößere das Hologramm','holoControl'],['Setze das Hologramm zurück','holoControl'],
 ['Nächstes Panel','navigate'],['Vorherige Seite','navigate'],['Kontrollraum','view'],['Gestern war es schön','text']
];
for(const [text,type] of cases)assert.equal(intent(text).type,type,text);
assert.equal(intent('Wie wird das Wetter morgen in Wien?').place,'Wien');
assert.equal(intent('Wie ist das Wetter dort?','Wien','Graz').place,'Graz');
assert.equal(intent('Wetter übermorgen in Graz').day,2);
assert.equal(intent('Handsteuerung ausschalten').action,'off');
assert.equal(intent('Schalte die Handsteuerung ein').action,'on');
assert.equal(intent('Beende die Handsteuerung').action,'off');
assert.equal(intent('Nächstes Panel').dir,1);assert.equal(intent('Vorherige Seite').dir,-1);
assert.equal(intent('Zeige das Hologramm Globus').model,'globe');assert.equal(intent('Wähle das 3D-Modell Gitter').model,'cube');
assert.equal(intent('Vergrößere das Hologramm').action,'in');assert.equal(intent('Setze das Hologramm zurück').action,'reset');
assert.equal(url('javascript:alert(1)'),'');
console.log(`${cases.length+9} intent and link checks passed`);
