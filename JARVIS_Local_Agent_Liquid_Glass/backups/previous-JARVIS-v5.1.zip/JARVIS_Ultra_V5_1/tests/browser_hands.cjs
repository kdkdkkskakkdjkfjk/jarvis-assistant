/* Browser test for hand control, hologram and navigation. Uses Chromium's FAKE camera device
 * (synthetic test video), so it verifies permission flow, camera release, UI wiring and gesture->action
 * dispatch. It does NOT verify MediaPipe recognition of a real hand; that needs your webcam.
 * Run:  python Start-Jarvis.py --no-browser --port 8000   then   node tests/browser_hands.cjs */
const { chromium } = require('playwright');
const assert = require('assert');
const BASE = process.env.JARVIS_URL || 'http://localhost:8000/';
let n = 0; const ok = m => { n++; console.log('  ok -', m); };
(async () => {
  const browser = await chromium.launch({ executablePath: process.env.JARVIS_BROWSER_PATH || undefined, headless: true,
    args: ['--no-sandbox', '--use-fake-device-for-media-stream', '--use-fake-ui-for-media-stream'] });
  const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 }, permissions: ['camera'] });
  const page = await ctx.newPage(); const errors = [];
  page.on('pageerror', e => errors.push(e.message));
  await page.addInitScript(() => localStorage.setItem('ultra_speak', '0'));
  await page.goto(BASE, { waitUntil: 'domcontentloaded' }); await page.waitForTimeout(1500);

  // 1. UI present, camera OFF by default
  assert.ok(await page.locator('#handToggle').count(), 'toggle exists'); ok('hand toggle rendered in top bar');
  assert.strictEqual(await page.evaluate(() => document.body.dataset.hands), 'off'); ok('camera off by default');
  const camBefore = await page.evaluate(async () => (await navigator.mediaDevices.enumerateDevices()).length);

  // 2. Enable: without local MediaPipe files a consent dialog must appear; decline => nothing loaded, camera released
  let dialogs = 0; page.on('dialog', d => { dialogs++; d.dismiss(); });
  await page.locator('#handToggle').click(); await page.locator('#handStart').click();
  await page.waitForFunction(() => document.body.dataset.hands === 'off' || document.body.dataset.hands === 'error', {}, { timeout: 15000 });
  const afterDecline = await page.evaluate(() => ({ s: document.body.dataset.hands, live: [...document.querySelectorAll('video')].some(v => v.srcObject && v.srcObject.getTracks().some(t => t.readyState === 'live')) }));
  assert.ok(dialogs >= 1 || afterDecline.s === 'error', 'consent dialog or explicit error'); assert.strictEqual(afterDecline.live, false);
  ok(`declined/failed model load leaves camera released (state=${afterDecline.s}, dialogs=${dialogs})`);

  // 3. Camera permission denied path
  const ctx2 = await browser.newContext({ viewport: { width: 1200, height: 800 } }); const p2 = await ctx2.newPage();
  await p2.addInitScript(() => { navigator.mediaDevices.getUserMedia = () => Promise.reject(Object.assign(new Error('x'), { name: 'NotAllowedError' })); });
  await p2.goto(BASE, { waitUntil: 'domcontentloaded' }); await p2.waitForTimeout(1000);
  await p2.locator('#handToggle').click(); await p2.locator('#handStart').click();
  await p2.waitForFunction(() => document.body.dataset.hands === 'error');
  assert.match(await p2.locator('#handStatus').textContent(), /abgelehnt/); ok('permission denial shows a clear message; state=error, app keeps working');
  await ctx2.close();

  // 4. Keyboard fallbacks: Alt+Right moves through panels, Alt+Left back
  await page.keyboard.press('Escape');
  const v0 = await page.evaluate(() => document.body.dataset.dashboardView || 'home');
  await page.keyboard.press('Alt+ArrowRight'); const v1 = await page.evaluate(() => document.body.dataset.dashboardView);
  assert.notStrictEqual(v1, v0); await page.keyboard.press('Alt+ArrowLeft');
  assert.strictEqual(await page.evaluate(() => document.body.dataset.dashboardView), v0); ok(`Alt+→/← navigates panels (${v0} → ${v1} → ${v0})`);

  // 5. Voice/text intents drive real features
  await page.locator('#in').fill('Zeig mir das Hologramm'); await page.locator('#sendBtn').click();
  await page.waitForFunction(() => document.body.dataset.dashboardView === 'holo'); ok('text/voice command opens the 3D lab');

  // 6. Hologram renders real pixels and responds to mouse + keyboard + wheel
  await page.waitForFunction(() => window.JarvisHolo?.isActive()); await page.waitForTimeout(400);
  const px = async () => page.evaluate(() => { const c = document.querySelector('#holoCanvas'), d = c.getContext('2d').getImageData(0, 0, c.width, c.height).data; let k = 0; for (let i = 3; i < d.length; i += 4) if (d[i] > 10) k++; return k; });
  const drawn = await px(); assert.ok(drawn > 500, 'canvas has drawn content, got ' + drawn + ' ' + JSON.stringify(await page.evaluate(() => { const c = document.querySelector('#holoCanvas'); return { w: c.width, h: c.height, active: JarvisHolo.isActive(), hidden: !c.offsetParent, vis: document.visibilityState, lastT: JarvisHolo._state.lastT, raf: JarvisHolo._state.raf, dirty: JarvisHolo._state.dirty, auto: JarvisHolo._state.auto, red: matchMedia('(prefers-reduced-motion: reduce)').matches, motion: document.body.dataset.motion }; })) + ' errors=' + JSON.stringify(errors)); ok('hologram canvas draws content');
  const R0 = await page.evaluate(() => JSON.stringify(JarvisHolo._state.R));
  const box = await page.locator('#holoCanvas').boundingBox();
  await page.mouse.move(box.x + 300, box.y + 200); await page.mouse.down(); await page.mouse.move(box.x + 420, box.y + 240, { steps: 6 }); await page.mouse.up();
  assert.notStrictEqual(await page.evaluate(() => JSON.stringify(JarvisHolo._state.R)), R0); ok('mouse drag rotates the 3D object');
  await page.evaluate(() => JarvisHolo.reset()); await page.locator('#holoCanvas').focus();
  await page.keyboard.press('+'); await page.keyboard.press('+');
  assert.ok(await page.evaluate(() => JarvisHolo._state.scale) > 1.15); ok('keyboard + scales the object');
  await page.keyboard.press('r'); assert.strictEqual(await page.evaluate(() => JarvisHolo._state.scale), 1); ok('R resets');

  // 7. Gesture dispatch with synthetic landmarks (camera-free): pinch-click a real button
  const hand = (cx, cy, o = {}) => { const e = Object.assign({ idx: true, mid: true, ring: true, pink: true, thumb: true, pinch: false }, o); const L = Array.from({ length: 21 }, () => ({ x: cx, y: cy, z: 0 })); L[0] = { x: cx, y: cy + .1, z: 0 };
    const cols = { 5: -.045, 9: -.015, 13: .015, 17: .045 }; for (const [b, k, t] of [[5, 'idx', 8], [9, 'mid', 12], [13, 'ring', 16], [17, 'pink', 20]]) { const bx = cx + cols[b], by = cy + .02; L[b] = { x: bx, y: by, z: 0 }; L[b + 1] = { x: bx, y: by - .04, z: 0 }; L[b + 2] = { x: bx, y: by - (e[k] ? .07 : .015), z: 0 }; L[t] = e[k] ? { x: bx, y: by - .1, z: 0 } : { x: bx, y: by + .01, z: 0 }; }
    L[9] = { x: cx - .015, y: cy, z: 0 }; L[1] = { x: cx - .04, y: cy + .08, z: 0 }; L[2] = { x: cx - .06, y: cy + .06, z: 0 }; L[3] = { x: cx - .075, y: cy + .045, z: 0 }; L[4] = e.thumb ? { x: cx - .14, y: cy + .01, z: 0 } : { x: cx + .01, y: cy + .06, z: 0 }; if (e.pinch) L[4] = { x: L[8].x + .004, y: L[8].y + .004, z: 0 }; return { landmarks: L }; };
  await page.evaluate(() => { window.__hand = null; });
  await page.exposeFunction('__noop', () => {});
  await page.addScriptTag({ content: `window.__mk=${hand.toString()};` });
  await page.evaluate(() => document.querySelector('.rail-btn[data-view="home"]').click());
  // find where the rail "news" button is on screen and compute the camera-space point that maps there (mirror-free feed)
  const target = await page.locator('.rail-btn[data-view="news"]').boundingBox();
  // engine maps the central 62% of the frame to the screen: x = (p-0.19)/0.62
  const toCam = (px, py) => ({ x: 0.19 + (px / 1440) * 0.62, y: 0.19 + (py / 900) * 0.62 });
  const c = toCam(target.x + target.width / 2, target.y + target.height / 2);
  // The index TIP (landmark 8) drives the cursor; hand(cx,cy) puts the tip at (cx-0.045, cy-0.08).
  const cx = c.x + 0.045, cy = c.y + 0.08; let t = 1000;
  const feed = async (frames) => { for (const f of frames) { t += 33; await page.evaluate(([h, tt]) => JarvisHands._feed(h.map(x => window.__mk(...x)), tt), [f, t]); } };
  const pk = { mid: false, ring: false, pink: false };
  await feed(Array.from({ length: 30 }, () => [[cx, cy, pk]]));
  const hov = await page.evaluate(() => !!document.querySelector('.hand-hover')); assert.ok(hov, 'target highlighted'); ok('hovering a button with the hand cursor highlights it');
  await feed([...Array.from({ length: 6 }, () => [[cx, cy, { ...pk, pinch: true }]]), ...Array.from({ length: 6 }, () => [[cx, cy, pk]])]);
  await page.waitForTimeout(350);
  assert.strictEqual(await page.evaluate(() => document.body.dataset.dashboardView), 'news'); ok('PINCH on a rail button actually opens that panel (real click)');

  // 8. Swipe changes panel exactly once
  await feed(Array.from({ length: 12 }, () => [[.3, .5]]));
  const before = await page.evaluate(() => document.body.dataset.dashboardView);
  await feed(Array.from({ length: 25 }, (_, i) => [[.3 + i * .03, .5]]));
  const after = await page.evaluate(() => document.body.dataset.dashboardView); assert.notStrictEqual(after, before); ok(`open-hand swipe changed panel once (${before} → ${after})`);
  await feed(Array.from({ length: 40 }, () => [])); // hand leaves
  assert.strictEqual(await page.evaluate(() => document.querySelector('#handCursor').hidden), true); ok('tracking loss hides cursor and releases state');

  // 9. Two-hand gesture scales the hologram
  await page.evaluate(() => { JarvisHands.navigate; window.jarvisShowView('holo'); JarvisHolo.reset(); });
  await page.waitForFunction(() => JarvisHolo.isActive());
  const pk2 = { mid: false, ring: false, pink: false, pinch: true };
  await feed(Array.from({ length: 24 }, (_, i) => [[.4 - i * .006, .5, pk2], [.6 + i * .006, .5, pk2]]));
  const sc = await page.evaluate(() => JarvisHolo._state.scale); assert.ok(sc > 1.2, 'scale ' + sc); ok(`two-hand pinch spread scaled the hologram (×${sc.toFixed(2)})`);

  // 10. Settings persist & no page errors
  await page.locator('#handToggle').click(); await page.locator('#handSens').fill('1.6'); await page.locator('#handSens').dispatchEvent('input');
  assert.ok((await page.evaluate(() => localStorage.getItem('jarvis_hands_v1'))).includes('1.6')); ok('sensitivity setting persisted');
  await page.screenshot({ path: 'qa-hands-holo.png' });
  const real = errors.filter(e => !/Failed to load resource|net::|ERR_/.test(e)); assert.deepStrictEqual(real, [], real.join('\n')); ok('no JavaScript runtime errors');
  await browser.close(); console.log(`${n} browser checks passed`);
})().catch(e => { console.error('FAIL', e.message); process.exit(1); });
