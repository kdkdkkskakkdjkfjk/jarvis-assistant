/* Unit tests for the gesture engine using synthetic MediaPipe-style landmarks. */
const assert = require('assert');
const { createEngine } = require('../assets/gesture-engine.js');

/* Build 21 landmarks. cx,cy = palm centre (normalised). opts: idx,mid,ring,pink,thumb (extended?), pinch (bool) */
function hand(cx, cy, o = {}) {
  const e = Object.assign({ idx: true, mid: true, ring: true, pink: true, thumb: true, pinch: false }, o);
  const L = Array.from({ length: 21 }, () => ({ x: cx, y: cy, z: 0 }));
  const wrist = { x: cx, y: cy + 0.10 };
  L[0] = { ...wrist, z: 0 };
  const cols = { 5: -0.045, 9: -0.015, 13: 0.015, 17: 0.045 };       // finger bases (index..pinky)
  const fingers = [[5, 'idx', 8], [9, 'mid', 12], [13, 'ring', 16], [17, 'pink', 20]];
  for (const [base, key, tip] of fingers) {
    const bx = cx + cols[base], by = cy + 0.02;
    L[base] = { x: bx, y: by, z: 0 };
    L[base + 1] = { x: bx, y: by - 0.04, z: 0 };                       // PIP
    L[base + 2] = { x: bx, y: by - (e[key] ? 0.07 : 0.015), z: 0 };    // DIP
    L[tip] = e[key] ? { x: bx, y: by - 0.10, z: 0 } : { x: bx, y: by + 0.01, z: 0 }; // folded tip is nearer the wrist than the PIP
  }
  L[9] = { x: cx - 0.015, y: cy, z: 0 }; // palm size ~ dist(wrist, L[9]) = 0.10
  L[1] = { x: cx - 0.04, y: cy + 0.08, z: 0 }; L[2] = { x: cx - 0.06, y: cy + 0.06, z: 0 };
  L[3] = { x: cx - 0.075, y: cy + 0.045, z: 0 };
  L[4] = e.thumb ? { x: cx - 0.14, y: cy + 0.01, z: 0 } : { x: cx + 0.01, y: cy + 0.06, z: 0 };
  if (e.pinch) { L[4] = { x: L[8].x + 0.004, y: L[8].y + 0.004, z: 0 }; }
  return { landmarks: L, handedness: 'Right' };
}
const types = evs => evs.map(e => e.type);
const run = (eng, frames, t0 = 0, dt = 33) => { const all = []; frames.forEach((h, i) => all.push(...eng.update(h, t0 + i * dt))); return all; };
const still = (n, f) => Array.from({ length: n }, f);
let passed = 0; const test = (name, fn) => { fn(); passed++; console.log('  ok -', name); };

test('open palm held still emits exactly one palmHold (cooldown prevents repeats)', () => {
  const eng = createEngine();
  const ev = run(eng, still(120, () => [hand(.5, .5)]));
  assert.strictEqual(types(ev).filter(t => t === 'palmHold').length, 1);
});

test('pinch then release without moving = one click, no drag', () => {
  const eng = createEngine();
  const ev = run(eng, [...still(8, () => [hand(.5, .5, { idx: true, mid: false, ring: false, pink: false })]),
    ...still(8, () => [hand(.5, .5, { idx: true, mid: false, ring: false, pink: false, pinch: true })]),
    ...still(8, () => [hand(.5, .5, { idx: true, mid: false, ring: false, pink: false })])]);
  const t = types(ev);
  assert.strictEqual(t.filter(x => x === 'click').length, 1, t.join());
  assert.strictEqual(t.filter(x => x === 'pinchStart').length, 1);
  assert.ok(!t.includes('dragStart'));
});

test('single-frame pinch flicker is ignored (debounce)', () => {
  const eng = createEngine();
  const f = [...still(6, () => [hand(.5, .5, { mid: false, ring: false, pink: false })]), [hand(.5, .5, { mid: false, ring: false, pink: false, pinch: true })],
    ...still(6, () => [hand(.5, .5, { mid: false, ring: false, pink: false })])];
  assert.ok(!types(run(eng, f)).includes('pinchStart'));
});

test('pinch + move = dragStart, drag..., dragEnd, and no click', () => {
  const eng = createEngine({ smoothing: 0 });
  const pk = { mid: false, ring: false, pink: false, pinch: true };
  const frames = [...still(6, () => [hand(.5, .5, { mid: false, ring: false, pink: false })]),
    ...Array.from({ length: 25 }, (_, i) => [hand(.5 + i * 0.012, .5, pk)]),
    ...still(6, () => [hand(.8, .5, { mid: false, ring: false, pink: false })])];
  const t = types(run(eng, frames));
  assert.strictEqual(t.filter(x => x === 'dragStart').length, 1);
  assert.ok(t.filter(x => x === 'drag').length > 5);
  assert.strictEqual(t.filter(x => x === 'dragEnd').length, 1);
  assert.ok(!t.includes('click'));
});

test('fast horizontal open-hand motion = ONE swipe; no retrigger while still moving', () => {
  const eng = createEngine({ smoothing: 0 });
  const frames = [...still(10, () => [hand(.3, .5)]), ...Array.from({ length: 30 }, (_, i) => [hand(.3 + i * 0.03, .5)])];
  const sw = run(eng, frames).filter(e => e.type === 'swipe');
  assert.strictEqual(sw.length, 1); assert.strictEqual(sw[0].direction, 'right');
});

test('swipe left is reported as left', () => {
  const eng = createEngine({ smoothing: 0 });
  const frames = [...still(10, () => [hand(.8, .5)]), ...Array.from({ length: 12 }, (_, i) => [hand(.8 - i * 0.04, .5)])];
  const sw = run(eng, frames).filter(e => e.type === 'swipe');
  assert.strictEqual(sw.length, 1); assert.strictEqual(sw[0].direction, 'left');
});

test('slow drift of an open hand does NOT swipe', () => {
  const eng = createEngine({ smoothing: 0 });
  const frames = Array.from({ length: 90 }, (_, i) => [hand(.3 + i * 0.002, .5)]);
  assert.ok(!types(run(eng, frames)).includes('swipe'));
});

test('vertical motion with two fingers up scrolls (and does not swipe)', () => {
  const eng = createEngine({ smoothing: 0 });
  const pz = { ring: false, pink: false };
  const frames = Array.from({ length: 20 }, (_, i) => [hand(.5, .3 + i * 0.015, pz)]);
  const ev = run(eng, frames);
  const sc = ev.filter(e => e.type === 'scroll');
  assert.ok(sc.length > 5 && sc.every(e => e.dy > 0));
  assert.ok(!types(ev).includes('swipe'));
});

test('two pinching hands: start, scale up when apart, rotate, end', () => {
  const eng = createEngine();
  const pk = { mid: false, ring: false, pink: false, pinch: true };
  const frames = Array.from({ length: 20 }, (_, i) => [hand(.4 - i * 0.005, .5, pk), hand(.6 + i * 0.005, .5, pk)]);
  frames.push([hand(.4, .5), hand(.6, .5)]);
  const ev = run(eng, frames);
  const th = ev.filter(e => e.type === 'twoHand');
  assert.strictEqual(types(ev).filter(x => x === 'twoHandStart').length, 1);
  assert.ok(th.length > 10 && th[th.length - 1].scale > 1.2, 'scale ' + th[th.length - 1]?.scale);
  assert.strictEqual(types(ev).filter(x => x === 'twoHandEnd').length, 1);
  assert.ok(!types(ev).includes('click'));
});

test('tracking loss during a drag releases it exactly once; return emits found', () => {
  const eng = createEngine({ smoothing: 0 });
  const pk = { mid: false, ring: false, pink: false, pinch: true };
  const frames = [...still(6, () => [hand(.5, .5, { mid: false, ring: false, pink: false })]),
    ...Array.from({ length: 12 }, (_, i) => [hand(.5 + i * 0.012, .5, pk)]),
    ...still(30, () => []), ...still(5, () => [hand(.5, .5)])];
  const t = types(run(eng, frames));
  assert.strictEqual(t.filter(x => x === 'dragEnd').length, 1);
  assert.strictEqual(t.filter(x => x === 'lost').length, 1);
  assert.strictEqual(t.filter(x => x === 'found').length, 1);
});

test('brief 3-frame dropout does not count as lost', () => {
  const eng = createEngine();
  const t = types(run(eng, [...still(10, () => [hand(.5, .5)]), ...still(3, () => []), ...still(10, () => [hand(.5, .5)])]));
  assert.ok(!t.includes('lost'));
});

test('sensitivity scales pointer reach', () => {
  const a = createEngine({ smoothing: 0, sensitivity: 1 }), b = createEngine({ smoothing: 0, sensitivity: 2 });
  const f = still(8, () => [hand(.6, .5)]);
  const xa = run(a, f).filter(e => e.type === 'move').pop().x, xb = run(b, f).filter(e => e.type === 'move').pop().x;
  assert.ok(xb > xa, `${xb} > ${xa}`);
});

test('garbage input never throws', () => {
  const eng = createEngine();
  eng.update(null, 0); eng.update([{}], 10); eng.update([{ landmarks: [] }], 20); eng.update(undefined, 30);
});

console.log(`${passed} gesture checks passed`);
