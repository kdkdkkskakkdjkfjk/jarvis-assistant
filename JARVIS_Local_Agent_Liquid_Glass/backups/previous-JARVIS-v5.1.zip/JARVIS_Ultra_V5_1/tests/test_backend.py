"""Deterministic tests. Provider replies below are explicitly test fixtures."""
import concurrent.futures
import datetime as dt
import http.client
import importlib
import json
import os
from pathlib import Path
import sys
import tempfile
import threading
import time
import unittest
from unittest.mock import patch

TMP=tempfile.TemporaryDirectory()
os.environ['JARVIS_DATA_DIR']=TMP.name
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import jarvis_server as j


def geometry(points):
    return [{'lon':x,'lat':y} for x,y in points]


class GeometryTests(unittest.TestCase):
    def test_vienna_relative_vertical_datum(self):
        f={'id':'test','geometry':{'type':'Polygon','coordinates':[[[16,48],[16.1,48],[16.1,48.1],[16,48]]]},'properties':{'O_KOTE':42,'T_KOTE':16.5,'U_KOTE':24.6,'BW_GEB_ID':12}}
        p=j.vienna_features({'features':[f]})[0]['properties']
        self.assertEqual(p['height'],25.5)
        self.assertAlmostEqual(p['min_height'],8.1)
    def test_vienna_missing_height_skipped(self):
        f={'geometry':{'type':'Polygon','coordinates':[]},'properties':{'O_KOTE':None,'T_KOTE':16}}
        self.assertEqual(j.vienna_features({'features':[f]}),[])

    def test_explicit_height(self):
        self.assertEqual(j.building_height({'height':'24.5','min_height':'3'})[:2],(24.5,3))
    def test_feet(self):
        self.assertAlmostEqual(j.meters('100 ft'),30.48)
    def test_estimated_levels_label(self):
        h,b,source=j.building_height({'building:levels':'5'})
        self.assertEqual(h,15);self.assertIn('geschätzt',source)
    def test_missing_height_label(self):
        self.assertIn('Standardhöhe',j.building_height({})[2])
    def test_invalid_nan_coordinate(self):
        self.assertEqual(j.ring([{'lat':float('nan'),'lon':16}]),[])
    def test_open_way_not_polygon(self):
        x={'type':'way','id':1,'tags':{'building':'yes'},'geometry':geometry([(16,48),(16.1,48),(16.1,48.1)])}
        self.assertEqual(j.osm_features({'elements':[x]}),[])
    def test_closed_footprint_and_height(self):
        pts=[(16.37,48.20),(16.38,48.20),(16.38,48.21),(16.37,48.20)]
        f=j.osm_features({'elements':[{'type':'way','id':1,'tags':{'building':'yes','height':'21'},'geometry':geometry(pts)}]})[0]
        self.assertEqual(f['geometry']['coordinates'][0][0][0],[16.37,48.20])
        self.assertEqual(f['properties']['height'],21)
    def test_relation_stitches_reversed_way_and_courtyard(self):
        outer=[(16,48),(17,48),(17,49),(16,49),(16,48)]
        inner=[(16.2,48.2),(16.4,48.2),(16.4,48.4),(16.2,48.2)]
        parts=[{'type':'way','ref':1,'role':'outer','geometry':geometry(outer[:3])},
               {'type':'way','ref':2,'role':'outer','geometry':geometry(list(reversed(outer[2:])))},
               {'type':'way','ref':3,'role':'inner','geometry':geometry(inner)}]
        f=j.osm_features({'elements':[{'type':'relation','id':8,'tags':{'building':'yes'},'members':parts}]})[0]
        self.assertEqual(len(f['geometry']['coordinates'][0]),2)
    def test_duplicate_relation_member_not_drawn(self):
        pts=geometry([(16,48),(17,48),(17,49),(16,48)])
        elements=[{'type':'relation','id':3,'tags':{'building':'yes'},'members':[{'type':'way','ref':4,'role':'outer','geometry':pts}]},{'type':'way','id':4,'tags':{'building':'yes'},'geometry':pts}]
        self.assertEqual(len(j.osm_features({'elements':elements})),1)
    def test_tile_vienna(self):
        n=65536;lon,lat=16.37315,48.20849
        import math
        x=int((lon+180)/360*n);y=int((1-math.asinh(math.tan(math.radians(lat)))/math.pi)/2*n)
        s,w,n,e=j.tile_bounds(x,y)
        self.assertTrue(s<=lat<=n and w<=lon<=e)
    def test_suspicious_url_rejected(self):
        for s in ['javascript:alert(1)','data:image/a','https://user:pass@example.org']:
            self.assertEqual(j.safe_url(s),'')
    def test_unknown_business_metadata_not_invented(self):
        fs=j.osm_features({'elements':[{'type':'node','id':1,'lat':48,'lon':16,'tags':{'shop':'supermarket','name':'TEST FIXTURE'}}]})
        self.assertNotIn('opening_hours',fs[0]['properties']['tags'])
        self.assertNotIn('rating',fs[0]['properties'])


class CacheTests(unittest.TestCase):
    def setUp(self):self.cache=j.Cache(Path(TMP.name)/('test-'+str(time.time_ns())+'.sqlite'))
    def test_cache_hit(self):
        f=lambda:{'items':[1]}
        self.assertFalse(self.cache.get('a',60,f)['cached'])
        self.assertTrue(self.cache.get('a',60,lambda:self.fail('Duplicate provider call'))['cached'])
    def test_concurrent_requests_coalesce(self):
        count=[]
        def load():count.append(1);time.sleep(.04);return {'items':[1]}
        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
            list(pool.map(lambda _:self.cache.get('b',60,load),range(4)))
        self.assertEqual(len(count),1)
        self.assertEqual(self.cache.keys,{})
    def test_stale_is_explicit(self):
        self.cache.write('c',{'items':[1]},-1)
        def fail():raise j.ApiError('offline')
        d=self.cache.get('c',60,fail,stale_for=10)
        self.assertTrue(d['stale']);self.assertEqual(d['warning'],'offline')
    def test_news_without_stale_fallback(self):
        self.cache.write('n',{'items':[1]},-1)
        with self.assertRaises(j.ApiError):self.cache.get('n',60,lambda:(_ for _ in ()).throw(j.ApiError('offline')))


class ProviderTests(unittest.TestCase):
    def test_secrets_not_returned(self):
        with patch.object(j,'config',return_value={**j.DEFAULTS,'gemini_key':'TOPSECRET','ha_token':'PRIVATE'}):
            self.assertNotIn('TOPSECRET',json.dumps(j.public_config()))
            self.assertNotIn('PRIVATE',json.dumps(j.public_config()))
    def test_single_model_call(self):
        c={**j.DEFAULTS,'gemini_key':'TEST'}
        with patch.object(j,'config',return_value=c),patch.object(j,'fetch',return_value={'candidates':[]}) as f:
            j.provider_generate({'contents':[]},'gemini')
            self.assertEqual(f.call_count,1)
            self.assertNotIn('TEST',f.call_args.args[0])
    def test_no_key(self):
        with patch.object(j,'config',return_value=j.DEFAULTS),self.assertRaises(j.ApiError) as ctx:j.provider_generate({})
        self.assertEqual(ctx.exception.status,409)
    def test_no_destructive_home_action(self):
        with self.assertRaises(j.ApiError):j.ha_action({'entity_id':'lock.front_door','action':'unlock','confirmed':True})
    def test_light_requires_confirmation(self):
        with self.assertRaises(j.ApiError):j.ha_action({'entity_id':'light.test','action':'turn_on'})
    def test_news_filters_old_and_invalid_dates(self):
        current=dt.datetime.now(dt.timezone.utc).strftime('%a, %d %b %Y %H:%M:%S GMT')
        xml=f'<rss><channel><item><title>fresh</title><link>https://example.org/1</link><pubDate>{current}</pubDate></item><item><title>old</title><link>https://example.org/2</link><pubDate>Mon, 01 Jan 2001 12:00:00 GMT</pubDate></item><item><title>unknown</title><link>https://example.org/3</link></item></channel></rss>'
        self.assertEqual([x['title'] for x in j.rss_items(xml,'TEST')],['fresh'])
    def test_bad_coordinate_rejected(self):
        with self.assertRaises(j.ApiError):j.weather('nan',16)


class HTTPTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server=j.create_server(0);cls.thread=threading.Thread(target=cls.server.serve_forever,daemon=True);cls.thread.start();cls.port=cls.server.server_port
    @classmethod
    def tearDownClass(cls):cls.server.shutdown();cls.server.server_close()
    def request(self,method,path,body=None,headers=None):
        con=http.client.HTTPConnection('127.0.0.1',self.port,timeout=5);con.request(method,path,body=body,headers=headers or {});r=con.getresponse();data=r.read();con.close();return r.status,data
    def test_app_served(self):self.assertEqual(self.request('GET','/')[0],200)
    def test_host_rebinding_blocked(self):self.assertEqual(self.request('GET','/api/bootstrap',headers={'Host':'evil.invalid'})[0],403)
    def test_cross_origin_blocked(self):self.assertEqual(self.request('GET','/api/bootstrap',headers={'Origin':'https://evil.invalid'})[0],403)
    def test_csrf_required(self):self.assertEqual(self.request('POST','/api/config','{}',{'Content-Type':'application/json'})[0],403)
    def test_python_and_original_archive_private(self):
        for path in ['/jarvis_server.py','/original/jarvis_v4_fixed_original.zip','/assets/%2e%2e/jarvis_server.py']:
            self.assertEqual(self.request('GET',path)[0],404)
    def test_head_cannot_bypass_files(self):self.assertEqual(self.request('HEAD','/jarvis_server.py')[0],405)
    def test_config_post_does_not_echo_key(self):
        status,b=self.request('POST','/api/config',json.dumps({'gemini_key':'TEST_ONLY'}),{'Content-Type':'application/json','X-Jarvis-Token':j.CSRF})
        self.assertEqual(status,200);self.assertNotIn(b'TEST_ONLY',b)


class DiagnosticsTests(unittest.TestCase):
    def test_diagnostics_has_no_secrets_and_flags_missing_key(self):
        with patch.object(j,'config',return_value={'provider':'gemini','gemini_key':'','claude_key':'','ha_url':'ftp://x','ha_token':'SECRET-TOKEN','tiles_asset_id':'abc','cesium_token':''}):
            d=j.diagnostics()
        blob=json.dumps(d)
        self.assertNotIn('SECRET-TOKEN',blob)
        self.assertTrue(any('API-Schlüssel' in w for w in d['warnings']))
        self.assertTrue(any('Home-Assistant-Adresse' in w for w in d['warnings']))
        self.assertTrue(any('Asset-ID' in w for w in d['warnings']))
        self.assertIn('mediapipe',d['vendor'])
    def test_static_types_are_explicit(self):
        m=j.Handler.extensions_map
        self.assertEqual(m['.mjs'],'text/javascript');self.assertEqual(m['.wasm'],'application/wasm')



if __name__=='__main__':unittest.main(verbosity=2)
