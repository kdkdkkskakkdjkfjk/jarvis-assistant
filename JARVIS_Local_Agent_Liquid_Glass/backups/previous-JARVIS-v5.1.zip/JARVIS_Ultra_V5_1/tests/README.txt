Backend: python -m unittest discover -s tests -v
Intent: node tests/test_intents.cjs
Browser (optional): npm install --no-save playwright; npx playwright install chromium
JARVIS zuerst starten, dann: node tests/browser_smoke.cjs
Der Browser-Test benutzt echte Datenquellen und schreibt lokale QA-Bilder. Bei Dienst-Ausfällen können Live-Tests fehlschlagen. Keine Mikrofon- oder Accountfreigaben werden automatisiert.

Handsteuerung: node tests/test_gestures.cjs (ohne Browser) · node tests/browser_hands.cjs (Jarvis muss laufen; nutzt Chromiums Testkamera, keine echte Hand)
