'use strict';
const assert = require('node:assert/strict');
const events = [];
global.document = {
  documentElement: { dataset: {} },
  getElementById: () => ({ attrs: {}, setAttribute(k,v){this.attrs[k]=v;}, innerHTML:'', title:'', addEventListener(k,fn){this.click=fn;} })
};
global.localStorage = { data: new Map(), getItem(k){return this.data.get(k)||null;}, setItem(k,v){this.data.set(k,v);} };
global.CustomEvent = class { constructor(type,init){this.type=type;this.detail=init.detail;} };
global.window = { dispatchEvent:e=>events.push(e), addEventListener(){} };
require('../assets/theme.js');
assert.equal(document.documentElement.dataset.theme,'brown');
assert.equal(localStorage.getItem('jarvis_theme'),'brown');
assert.equal(events.at(-1).detail.theme,'brown');
window.JarvisTheme.set('obsidian');
assert.equal(document.documentElement.dataset.theme,'obsidian');
assert.equal(localStorage.getItem('jarvis_theme'),'obsidian');
window.JarvisTheme.set('invalid');
assert.equal(document.documentElement.dataset.theme,'brown');
console.log('6 theme persistence and state checks passed');
