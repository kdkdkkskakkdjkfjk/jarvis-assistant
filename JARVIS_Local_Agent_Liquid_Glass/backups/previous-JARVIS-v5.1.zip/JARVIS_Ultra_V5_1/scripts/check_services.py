"""Run real external checks and record failures explicitly. No credentials printed."""
import argparse
import json
import math
from pathlib import Path
import sys
import time
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import jarvis_server as j


def main():
    p=argparse.ArgumentParser();p.add_argument('--output',default='live-checks.json');p.add_argument('--ai',action='store_true',help='Optional: ein echter KI-Aufruf, ggf. kostenpflichtig');a=p.parse_args()
    lon,lat=16.37315,48.20849
    x=int((lon+180)/360*65536);y=int((1-math.asinh(math.tan(math.radians(lat)))/math.pi)/2*65536)
    jobs=[('Ortssuche Wien',lambda:j.geocode('Wien')),('Wetter Wien',lambda:j.weather(lat,lon)),('Wiener Baukörper',lambda:j.world_tile(x,y)),('Lidl in Wien',lambda:j.places('Lidl',lat,lon,5000)),('Nachrichten Wien',lambda:j.news('Wien')),('Bilder Wien',lambda:j.images('Vienna'))]
    if a.ai:jobs.append(('KI',lambda:j.chat({'text':'Antworte auf Deutsch: Verbindungstest erfolgreich.','history':[]})))
    out={'at':j.now_iso(),'checks':[]}
    for name,fn in jobs:
        start=time.monotonic()
        try:
            d=fn();count=len(d.get('items',d.get('features',d.get('results',[]))))
            result={'name':name,'status':'ok','seconds':round(time.monotonic()-start,2),'records':count,'source':d.get('source'),'cached':d.get('cached',False)}
        except Exception as ex:result={'name':name,'status':'failed','seconds':round(time.monotonic()-start,2),'error':str(ex)}
        out['checks'].append(result);print(json.dumps(result,ensure_ascii=False),flush=True)
    Path(a.output).write_text(json.dumps(out,indent=2,ensure_ascii=False),encoding='utf-8')
    return 1 if any(x['status']=='failed' for x in out['checks']) else 0


if __name__=='__main__':raise SystemExit(main())
