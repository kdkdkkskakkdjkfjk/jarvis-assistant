"""One-time download of the MediaPipe hand-tracking runtime for offline use.

Files are fetched over HTTPS from the pinned npm release on jsDelivr (Apache-2.0) and Google's
public model bucket, written atomically to assets/vendor/mediapipe/, and their SHA-256 hashes are
recorded in MANIFEST.json (trust-on-first-use; compare hashes if you re-run). Nothing is executed.

    python scripts/fetch_handtracking.py            # download missing files
    python scripts/fetch_handtracking.py --force    # re-download everything
"""
import argparse
import hashlib
import json
import sys
import urllib.error
import urllib.request
from pathlib import Path

VERSION = '0.10.14'
NPM = f'https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@{VERSION}/'
MODEL = 'https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task'
DEST = Path(__file__).resolve().parents[1] / 'assets' / 'vendor' / 'mediapipe'
# (url, relative target, minimum plausible size in bytes, required?)
FILES = [
    (NPM + 'vision_bundle.mjs', 'vision_bundle.mjs', 50_000, True),
    (NPM + 'wasm/vision_wasm_internal.js', 'wasm/vision_wasm_internal.js', 20_000, True),
    (NPM + 'wasm/vision_wasm_internal.wasm', 'wasm/vision_wasm_internal.wasm', 1_000_000, True),
    (NPM + 'wasm/vision_wasm_nosimd_internal.js', 'wasm/vision_wasm_nosimd_internal.js', 20_000, False),
    (NPM + 'wasm/vision_wasm_nosimd_internal.wasm', 'wasm/vision_wasm_nosimd_internal.wasm', 1_000_000, False),
    (MODEL, 'hand_landmarker.task', 1_000_000, True),
    (NPM + 'LICENSE', 'LICENSE-mediapipe-tasks-vision.txt', 100, False),
]


def download(url, target, minimum):
    req = urllib.request.Request(url, headers={'User-Agent': 'jarvis-ultra-setup/5.1'})
    with urllib.request.urlopen(req, timeout=60) as r:
        data = r.read()
    if len(data) < minimum:
        raise ValueError(f'Datei zu klein ({len(data)} Bytes); Download unvollständig oder unerwartete Antwort.')
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp = target.with_suffix(target.suffix + '.part')
    tmp.write_bytes(data)
    tmp.replace(target)
    return hashlib.sha256(data).hexdigest(), len(data)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--force', action='store_true', help='vorhandene Dateien erneut laden')
    args = ap.parse_args(argv)
    manifest_path = DEST / 'MANIFEST.json'
    manifest = json.loads(manifest_path.read_text()) if manifest_path.exists() else {}
    failed = []
    for url, rel, minimum, required in FILES:
        target = DEST / rel
        if target.exists() and not args.force:
            print(f'vorhanden   {rel}')
            continue
        try:
            digest, size = download(url, target, minimum)
            old = manifest.get(rel, {}).get('sha256')
            if old and old != digest:
                print(f'WARNUNG: Hash von {rel} weicht von der früheren Installation ab.')
            manifest[rel] = {'sha256': digest, 'bytes': size, 'url': url, 'version': VERSION}
            print(f'geladen     {rel} ({size/1024:.0f} KB)')
        except (urllib.error.URLError, OSError, ValueError) as e:
            print(f'FEHLER      {rel}: {e}', file=sys.stderr)
            if required:
                failed.append(rel)
    DEST.mkdir(parents=True, exist_ok=True)
    manifest_path.write_text(json.dumps(manifest, indent=2))
    if failed:
        print('\nNicht alle benötigten Dateien konnten geladen werden. Internetverbindung/Proxy prüfen und erneut starten.', file=sys.stderr)
        return 1
    print('\nFertig. Die Handsteuerung kann jetzt ohne Internet starten.')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
