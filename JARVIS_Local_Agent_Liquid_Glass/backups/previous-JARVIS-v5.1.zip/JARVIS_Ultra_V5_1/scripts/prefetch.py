"""Resume a bounded OSM/Wien geometry cache job; never downloads raster tiles."""
import argparse
import json
import math
from pathlib import Path
import sys
import time
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from jarvis_server import DATA, world_tile, now_iso


def xy(lon,lat):
    return int((lon+180)/360*65536),int((1-math.asinh(math.tan(math.radians(lat)))/math.pi)/2*65536)


def main():
    p=argparse.ArgumentParser(description='Begrenzte Geometrie-Vorbereitung, wiederaufnehmbar')
    p.add_argument('--bbox',nargs=4,type=float,metavar=('WEST','SOUTH','EAST','NORTH'),default=[16.370,48.207,16.377,48.211])
    p.add_argument('--max-tiles',type=int,default=16)
    p.add_argument('--budget-seconds',type=int,default=1800)
    p.add_argument('--retry-failed',action='store_true')
    a=p.parse_args();w,s,e,n=a.bbox
    if not (-180<=w<e<=180 and -80<=s<n<=80):p.error('Ungültige BBOX.')
    if not 1<=a.max_tiles<=64:p.error('Maximal 64 Geometriekacheln pro Auftrag.')
    if not 10<=a.budget_seconds<=36000:p.error('Zeitbudget muss 10 bis 36000 Sekunden sein.')
    x0,y1=xy(w,s);x1,y0=xy(e,n)
    keys=[(x,y) for x in range(x0,x1+1) for y in range(y0,y1+1)]
    if len(keys)>a.max_tiles:p.error(f'{len(keys)} Kacheln überschreiten das Limit. Einen kleineren Bereich wählen. Europa wird beim Navigieren gestreamt.')
    import hashlib
    job=hashlib.sha256(json.dumps(a.bbox).encode()).hexdigest()[:12]
    path=DATA/f'prefetch-{job}.json'
    state=json.loads(path.read_text()) if path.exists() else {'bbox':a.bbox,'done':{},'failed':{},'created_at':now_iso()}
    if a.retry_failed:state['failed']={}
    started=time.monotonic()
    def save():
        state['updated_at']=now_iso();tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(state,indent=2,ensure_ascii=False));tmp.replace(path)
    try:
        for x,y in keys:
            key=f'{x}/{y}'
            if key in state['done'] or key in state['failed']:continue
            if time.monotonic()-started>a.budget_seconds:print('Zeitbudget erreicht. Derselbe Befehl setzt später fort.');break
            print(f'[{len(state["done"])+1}/{len(keys)}] Geometrie {key}',flush=True)
            try:
                d=world_tile(x,y);state['done'][key]={'features':len(d['features']),'source':d['source'],'fetched_at':d['fetched_at']}
            except Exception as ex:state['failed'][key]=str(ex);print('Fehler:',ex,flush=True)
            save();time.sleep(1.5)
    except KeyboardInterrupt:print('\nPausiert. Fortschritt gespeichert.')
    finally:save()
    print(f'{len(state["done"])} fertig, {len(state["failed"])} Fehler, {len(keys)} insgesamt.')
    print('Fehlgeschlagene Kacheln mit --retry-failed erneut versuchen.')
    print('Dies ist ein begrenzter Datenausschnitt, kein vollständiges Modell Österreichs oder Europas.')


if __name__=='__main__':main()
