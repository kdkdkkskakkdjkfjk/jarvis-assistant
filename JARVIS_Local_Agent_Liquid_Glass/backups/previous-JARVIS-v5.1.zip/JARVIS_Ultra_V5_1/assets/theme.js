(() => {
  'use strict';
  const root = document.documentElement;
  const button = document.getElementById('themeToggle');
  const apply = theme => {
    const value = theme === 'obsidian' ? 'obsidian' : 'brown';
    root.dataset.theme = value;
    try { localStorage.setItem('jarvis_theme', value); } catch (_) {}
    if (button) {
      const brown = value === 'brown';
      button.setAttribute('aria-pressed', String(brown));
      button.title = brown ? 'Zu Obsidian Glass wechseln' : 'Zu Liquid Glass Brown wechseln';
      button.innerHTML = brown ? '◐ <span>Brown Glass</span>' : '◑ <span>Obsidian Glass</span>';
    }
    window.dispatchEvent(new CustomEvent('jarvis-theme-change', { detail: { theme: value } }));
  };
  let saved = 'brown';
  try { saved = localStorage.getItem('jarvis_theme') || 'brown'; } catch (_) {}
  apply(saved);
  button?.addEventListener('click', () => apply(root.dataset.theme === 'brown' ? 'obsidian' : 'brown'));
  window.JarvisTheme = { set: apply, get: () => root.dataset.theme };
})();
