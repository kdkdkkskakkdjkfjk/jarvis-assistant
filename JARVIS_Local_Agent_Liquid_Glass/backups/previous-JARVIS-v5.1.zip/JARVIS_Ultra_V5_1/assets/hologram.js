/* JARVIS hologram viewer.
 * Real 3D objects (vertices, edges, rotation matrices, perspective projection, depth shading)
 * drawn on a Canvas 2D context. It only renders while its panel is visible, caps device pixel
 * ratio, and lowers point density automatically when frames get slow.
 * Models are procedural and illustrative: the globe's grid is a generic graticule, only the
 * Vienna marker uses a real coordinate (48.2085 N, 16.3731 E). */
((root) => {
  'use strict';
  const $ = s => document.querySelector(s);
  const reduced = () => matchMedia('(prefers-reduced-motion: reduce)').matches || document.body.dataset.motion === 'reduced';

  /* ---------- geometry ---------- */
  const PHI = (1 + Math.sqrt(5)) / 2;
  function icosahedron() {
    const v = [[-1, PHI, 0], [1, PHI, 0], [-1, -PHI, 0], [1, -PHI, 0], [0, -1, PHI], [0, 1, PHI], [0, -1, -PHI], [0, 1, -PHI], [PHI, 0, -1], [PHI, 0, 1], [-PHI, 0, -1], [-PHI, 0, 1]]
      .map(p => { const l = Math.hypot(...p); return p.map(c => c / l); });
    const edges = [];
    for (let i = 0; i < 12; i++) for (let j = i + 1; j < 12; j++) {
      if (Math.abs(Math.hypot(v[i][0] - v[j][0], v[i][1] - v[j][1], v[i][2] - v[j][2]) - 1.0515) < 0.02) edges.push([i, j]);
    }
    return { v, edges };
  }
  function ring(r, n, axis) {
    const pts = [];
    for (let i = 0; i < n; i++) {
      const a = i / n * Math.PI * 2, c = Math.cos(a) * r, s = Math.sin(a) * r;
      pts.push(axis === 'x' ? [0, c, s] : axis === 'y' ? [c, 0, s] : [c, s, 0]);
    }
    return pts;
  }
  const loop = (pts, off = 0) => pts.map((_, i) => [off + i, off + (i + 1) % pts.length]);
  function sphereDots(n) { // Fibonacci sphere
    const pts = [];
    for (let i = 0; i < n; i++) {
      const y = 1 - (i + .5) / n * 2, r = Math.sqrt(1 - y * y), a = i * Math.PI * (3 - Math.sqrt(5));
      pts.push([Math.cos(a) * r, y, Math.sin(a) * r]);
    }
    return pts;
  }
  const ll = (lat, lon, r = 1) => { const φ = lat * Math.PI / 180, λ = lon * Math.PI / 180; return [r * Math.cos(φ) * Math.sin(λ), r * Math.sin(φ), r * Math.cos(φ) * Math.cos(λ)]; };

  function buildModels() {
    const ico = icosahedron();
    const models = {};
    {
      const v = [...ico.v.map(p => p.map(c => c * 0.8))], edges = [...ico.edges];
      [['x', 1.1], ['y', 1.25], ['z', 1.4]].forEach(([ax, r]) => { const off = v.length; ring(r, 72, ax).forEach(p => v.push(p)); edges.push(...loop(ring(r, 72, ax), off)); });
      models.core = { name: 'Kern', v, edges, dots: sphereDots(160).map(p => p.map(c => c * 0.45)), facts: 'Prozedurales Beispielobjekt: Ikosaeder mit drei Ringen. Illustrativ, keine reale Struktur.' };
    }
    {
      const v = [], edges = [];
      for (let lat = -60; lat <= 60; lat += 30) { const off = v.length, pts = []; for (let lon = 0; lon < 360; lon += 10) pts.push(ll(lat, lon)); pts.forEach(p => v.push(p)); edges.push(...loop(pts, off)); }
      for (let lon = 0; lon < 180; lon += 30) { const off = v.length, pts = []; for (let lat = -90; lat < 270; lat += 10) { const a = lat * Math.PI / 180, l = lon * Math.PI / 180; pts.push([Math.cos(a) * Math.sin(l), Math.sin(a), Math.cos(a) * Math.cos(l)]); } pts.forEach(p => v.push(p)); edges.push(...loop(pts, off)); }
      models.globe = { name: 'Globus', v, edges, dots: sphereDots(260), marker: { p: ll(48.2085, 16.3731, 1.02), label: 'Wien' }, facts: 'Gradnetz ist generisch und enthält keine Küstenlinien. Nur der Marker „Wien“ nutzt eine echte Koordinate (48,2085° N, 16,3731° O).' };
    }
    {
      const v = [], edges = [], n = 3;
      for (let x = 0; x <= n; x++) for (let y = 0; y <= n; y++) for (let z = 0; z <= n; z++) v.push([x / n * 2 - 1, y / n * 2 - 1, z / n * 2 - 1]);
      const id = (x, y, z) => x * (n + 1) * (n + 1) + y * (n + 1) + z;
      for (let x = 0; x <= n; x++) for (let y = 0; y <= n; y++) for (let z = 0; z <= n; z++) {
        if (x < n) edges.push([id(x, y, z), id(x + 1, y, z)]); if (y < n) edges.push([id(x, y, z), id(x, y + 1, z)]); if (z < n) edges.push([id(x, y, z), id(x, y, z + 1)]);
      }
      models.cube = { name: 'Gitter', v: v.map(p => p.map(c => c * 0.72)), edges, dots: [], facts: 'Prozedurales Gitter zum Testen von Drehung und Skalierung.' };
    }
    return models;
  }

  // Small, dependency-free Wavefront OBJ adapter. Files stay in this tab and are
  // bounded so a user-supplied mesh cannot stall the low-memory target machine.
  function parseOBJ(text, label = 'Lokales Modell') {
    if (typeof text !== 'string' || text.length > 5 * 1024 * 1024) throw new Error('OBJ-Datei darf höchstens 5 MB groß sein.');
    const vertices = [], edges = new Set(); let faces = 0;
    for (const raw of text.split(/\r?\n/)) {
      const line = raw.trim(); if (!line || line[0] === '#') continue;
      const parts = line.split(/\s+/);
      if (parts[0] === 'v') {
        if (parts.length < 4 || vertices.length >= 20000) throw new Error('OBJ enthält ungültige oder zu viele Punkte (max. 20.000).');
        const p = parts.slice(1, 4).map(Number);
        if (!p.every(Number.isFinite)) throw new Error('OBJ enthält einen ungültigen Punkt.');
        vertices.push(p);
      } else if (parts[0] === 'f') {
        if (parts.length < 4 || ++faces > 30000) throw new Error('OBJ enthält ungültige oder zu viele Flächen (max. 30.000).');
        const face = parts.slice(1).map(token => {
          const rawIndex = Number(token.split('/')[0]);
          if (!Number.isInteger(rawIndex) || rawIndex === 0) throw new Error('OBJ enthält einen ungültigen Flächenverweis.');
          const idx = rawIndex > 0 ? rawIndex - 1 : vertices.length + rawIndex;
          if (idx < 0 || idx >= vertices.length) throw new Error('OBJ verweist auf einen fehlenden Punkt.');
          return idx;
        });
        for (let i = 0; i < face.length; i++) {
          const a = face[i], b = face[(i + 1) % face.length];
          edges.add(a < b ? `${a},${b}` : `${b},${a}`);
        }
      }
    }
    if (vertices.length < 3 || !faces || !edges.size) throw new Error('Keine nutzbare 3D-Geometrie in dieser OBJ-Datei gefunden.');
    const min = [0,1,2].map(k => Math.min(...vertices.map(p => p[k])));
    const max = [0,1,2].map(k => Math.max(...vertices.map(p => p[k])));
    const center = min.map((v,k) => (v + max[k]) / 2), extent = Math.max(...min.map((v,k) => max[k] - v));
    if (!(extent > 1e-9)) throw new Error('Das OBJ-Modell hat keine räumliche Ausdehnung.');
    const v = vertices.map(p => p.map((c,k) => (c - center[k]) / extent * 2.1));
    const edgeList = [...edges].map(pair => pair.split(',').map(Number));
    const dots = v.length > 2500 ? v.filter((_,i) => i % Math.ceil(v.length / 2500) === 0) : v;
    return { name: String(label).slice(0, 60), v, edges: edgeList, dots, facts: `Lokal importierte OBJ-Geometrie · ${v.length.toLocaleString('de-AT')} Punkte · ${faces.toLocaleString('de-AT')} Flächen. Nur im Browser verarbeitet; keine Datei wird hochgeladen.` };
  }

  /* ---------- rotation helpers (column-major free: plain 3x3) ---------- */
  const mul = (a, b) => [0, 1, 2].map(i => [0, 1, 2].map(j => a[i][0] * b[0][j] + a[i][1] * b[1][j] + a[i][2] * b[2][j]));
  const rx = a => [[1, 0, 0], [0, Math.cos(a), -Math.sin(a)], [0, Math.sin(a), Math.cos(a)]];
  const ry = a => [[Math.cos(a), 0, Math.sin(a)], [0, 1, 0], [-Math.sin(a), 0, Math.cos(a)]];
  const rz = a => [[Math.cos(a), -Math.sin(a), 0], [Math.sin(a), Math.cos(a), 0], [0, 0, 1]];
  const apply = (m, p) => [m[0][0] * p[0] + m[0][1] * p[1] + m[0][2] * p[2], m[1][0] * p[0] + m[1][1] * p[1] + m[1][2] * p[2], m[2][0] * p[0] + m[2][1] * p[1] + m[2][2] * p[2]];
  const ID = () => [[1, 0, 0], [0, 1, 0], [0, 0, 1]];

  /* ---------- viewer ---------- */
  const models = buildModels();
  const st = { model: 'core', R: mul(rx(-.35), ry(.6)), scale: 1, vel: { x: 0, y: 0, z: 0 }, running: false, raf: 0, lastT: 0, ft: [], quality: 1, dirty: true, auto: true, selected: false };
  let cv, ctx, W = 0, H = 0, dpr = 1, colors = { accent: '#83e8d2', ink: '#e7f1ed', edge: '#213940' };

  function readColors() {
    const cs = getComputedStyle(document.documentElement);
    const g = (n, d) => (cs.getPropertyValue(n).trim() || d);
    colors = { accent: g('--u-accent', '#83e8d2'), ink: g('--u-ink', '#e7f1ed'), edge: g('--u-edge', '#213940') };
  }
  function resize() {
    if (!cv) return;
    const r = cv.getBoundingClientRect();
    dpr = Math.min(window.devicePixelRatio || 1, st.quality < 1 ? 1 : 1.5);
    W = Math.max(1, Math.round(r.width)); H = Math.max(1, Math.round(r.height));
    cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0); st.dirty = true;
  }
  function project(p) {
    const f = 3.2, z = p[2] + f, k = f / z, s = Math.min(W, H) * 0.34 * st.scale;
    return { x: W / 2 + p[0] * k * s, y: H / 2 - p[1] * k * s, z: p[2], k };
  }
  function draw() {
    const m = models[st.model]; if (!ctx) return;
    ctx.clearRect(0, 0, W, H);
    const pts = m.v.map(p => project(apply(st.R, p)));
    ctx.lineWidth = 1; ctx.lineCap = 'round';
    ctx.strokeStyle = colors.accent;
    for (const [a, b] of m.edges) {
      const A = pts[a], B = pts[b], depth = (A.z + B.z) / 2; // -1 (far) .. +1 (near)
      ctx.globalAlpha = Math.max(.08, .26 + .42 * (depth + 1) / 2);
      ctx.beginPath(); ctx.moveTo(A.x, A.y); ctx.lineTo(B.x, B.y); ctx.stroke();
    }
    const dots = m.dots, step = st.quality < 1 ? 2 : 1;
    ctx.fillStyle = colors.ink;
    for (let i = 0; i < dots.length; i += step) {
      const P = project(apply(st.R, dots[i])); ctx.globalAlpha = Math.max(.05, .2 + .55 * (P.z + 1) / 2);
      const r = 0.7 + 1.1 * P.k * (P.z + 1.2) / 2; ctx.fillRect(P.x - r / 2, P.y - r / 2, r, r);
    }
    if (m.marker) {
      const rp = apply(st.R, m.marker.p), P = project(rp);
      if (rp[2] > -0.15) {
        ctx.globalAlpha = 1; ctx.fillStyle = colors.accent; ctx.beginPath(); ctx.arc(P.x, P.y, 4, 0, 7); ctx.fill();
        ctx.globalAlpha = .5; ctx.beginPath(); ctx.arc(P.x, P.y, 9 + 3 * Math.sin(performance.now() / 300), 0, 7); ctx.strokeStyle = colors.accent; ctx.stroke();
        ctx.globalAlpha = .9; ctx.fillStyle = colors.ink; ctx.font = '11px Inter, system-ui, sans-serif'; ctx.fillText(m.marker.label, P.x + 14, P.y + 4);
      }
    }
    // faint ground reflection ellipse for depth
    ctx.globalAlpha = .12; ctx.strokeStyle = colors.accent; ctx.beginPath(); ctx.ellipse(W / 2, H / 2 + Math.min(W, H) * .38 * st.scale, Math.min(W, H) * .3 * st.scale, Math.min(W, H) * .05 * st.scale, 0, 0, 7); ctx.stroke();
    ctx.globalAlpha = 1;
    const rd = $('#holoReadout'); if (rd) rd.textContent = `Skalierung ${(st.scale * 100).toFixed(0)} %`;
  }
  function frame(t) {
    st.raf = 0; if (!st.running) return;
    const dt = Math.min(64, t - (st.lastT || t)); st.lastT = t;
    st.ft.push(dt); if (st.ft.length > 45) {
      const avg = st.ft.reduce((a, b) => a + b, 0) / st.ft.length; st.ft = [];
      if (avg > 26 && st.quality > .5) { st.quality = .5; resize(); } else if (avg < 14 && st.quality < 1) { st.quality = 1; resize(); }
    }
    const v = st.vel, moving = Math.abs(v.x) + Math.abs(v.y) + Math.abs(v.z) > 1e-4;
    if (moving) { rotate(v.x * dt / 16, v.y * dt / 16, v.z * dt / 16, true); const d = Math.pow(.92, dt / 16); v.x *= d; v.y *= d; v.z *= d; }
    else if (st.auto && !reduced() && !st.selected) { rotate(0, .0025 * dt / 16, 0, true); }
    if (st.dirty || moving || (st.auto && !reduced()) || models[st.model].marker) { draw(); st.dirty = false; }
    st.raf = requestAnimationFrame(frame);
  }
  function rotate(dPitch, dYaw, dRoll, keepVel) {
    st.R = mul(rz(dRoll || 0), mul(rx(dPitch || 0), mul(ry(dYaw || 0), st.R))); st.dirty = true;
  }
  function setScale(s) { st.scale = Math.min(1.8, Math.max(.35, s)); st.dirty = true; }
  function setAuto(on) { st.auto = !!on; const b = $('#holoAuto'); if (b) b.setAttribute('aria-pressed', String(st.auto)); st.dirty = true; }
  function start() { if (st.running || !cv) return; st.running = true; st.lastT = 0; readColors(); resize(); st.raf = requestAnimationFrame(frame); }
  function stop() { st.running = false; if (st.raf) cancelAnimationFrame(st.raf); st.raf = 0; }
  function setModel(k) {
    if (!models[k]) return; st.model = k; st.dirty = true;
    document.querySelectorAll('[data-holo-model]').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.holoModel === k)));
    const f = $('#holoFacts'); if (f) f.textContent = models[k].facts;
    const n = $('#holoName'); if (n) n.textContent = models[k].name;
  }
  function reset() { st.R = mul(rx(-.35), ry(.6)); st.scale = 1; st.vel = { x: 0, y: 0, z: 0 }; st.dirty = true; }

  function bind() {
    cv = $('#holoCanvas'); if (!cv) return; ctx = cv.getContext('2d', { alpha: true });
    let drag = null;
    cv.addEventListener('pointerdown', e => { drag = { x: e.clientX, y: e.clientY, id: e.pointerId }; st.selected = true; st.vel = { x: 0, y: 0, z: 0 }; try { cv.setPointerCapture(e.pointerId); } catch (_) {} });
    cv.addEventListener('pointermove', e => {
      if (!drag) return; const dx = e.clientX - drag.x, dy = e.clientY - drag.y; drag.x = e.clientX; drag.y = e.clientY;
      rotate(dy * .008, dx * .008, 0); st.vel = { x: dy * .0012, y: dx * .0012, z: 0 };
    });
    const up = () => { drag = null; st.selected = false; };
    cv.addEventListener('pointerup', up); cv.addEventListener('pointercancel', up); cv.addEventListener('lostpointercapture', up);
    cv.addEventListener('wheel', e => { e.preventDefault(); setScale(st.scale * (e.deltaY < 0 ? 1.08 : 1 / 1.08)); }, { passive: false });
    cv.addEventListener('keydown', e => {
      const k = e.key; let used = true;
      if (k === 'ArrowLeft') rotate(0, -.15, 0); else if (k === 'ArrowRight') rotate(0, .15, 0);
      else if (k === 'ArrowUp') rotate(-.15, 0, 0); else if (k === 'ArrowDown') rotate(.15, 0, 0);
      else if (k === '+' || k === '=') setScale(st.scale * 1.1); else if (k === '-') setScale(st.scale / 1.1);
      else if (k === 'q' || k === 'Q') rotate(0, 0, -.15); else if (k === 'e' || k === 'E') rotate(0, 0, .15);
      else if (k === 'r' || k === 'R' || k === '0') reset(); else used = false;
      if (used) e.preventDefault();
    });
    document.querySelectorAll('[data-holo-model]').forEach(b => b.addEventListener('click', () => setModel(b.dataset.holoModel)));
    $('#holoObjFile')?.addEventListener('change', async e => {
      const file = e.currentTarget.files?.[0]; if (!file) return;
      try {
        if (!file.name.toLowerCase().endsWith('.obj')) throw new Error('Bitte eine Wavefront-OBJ-Datei (.obj) auswählen.');
        const model = parseOBJ(await file.text(), file.name.replace(/\.obj$/i, ''));
        delete models.imported; models.imported = model; setModel('imported');
      } catch (err) { const f = $('#holoFacts'); if (f) f.textContent = `Modell konnte nicht geladen werden: ${err.message}`; }
      finally { e.currentTarget.value = ''; }
    });
    $('#holoReset')?.addEventListener('click', reset);
    $('#holoAuto')?.addEventListener('click', () => setAuto(!st.auto));
    if ('ResizeObserver' in window) new ResizeObserver(() => { if (st.running) resize(); }).observe(cv);
    const sync = () => { const on = document.body.dataset.dashboardView === 'holo' && !document.hidden; on ? start() : stop(); };
    new MutationObserver(sync).observe(document.body, { attributes: true, attributeFilter: ['data-dashboard-view'] });
    window.addEventListener('jarvis-theme-change', () => { readColors(); st.dirty = true; });
    document.addEventListener('visibilitychange', sync); sync(); setModel('core');
  }

  const API = {
    rotate: (p, y, r) => { st.vel = { x: p * .15, y: y * .15, z: (r || 0) * .15 }; rotate(p, y, r || 0); },
    scaleBy: f => setScale(st.scale * f), setAuto, reset, setModel, models: () => Object.keys(models),
    isActive: () => st.running, canvas: () => cv, _state: st, _project: project, parseOBJ
  };
  root.JarvisHolo = API;
  if (typeof document !== 'undefined') (document.readyState === 'loading' ? document.addEventListener('DOMContentLoaded', bind) : bind());
})(typeof window === 'undefined' ? globalThis : window);
