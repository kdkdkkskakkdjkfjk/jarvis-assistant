/* JARVIS v5 integration: preserves existing tools, calendar, cameras and Piper. */
(() => {
 'use strict';
 const U=JarvisCore,$=s=>document.querySelector(s),e=U.esc;
 let contextGeneration=0,requestId=0,activeController=null,lastIntent=null,lastPlace='',toastTimer,systemTimer=null;
 const renderers=new Map();
 const reduced=()=>matchMedia('(prefers-reduced-motion: reduce)').matches||document.body.dataset.motion==='reduced';
 function toast(text){$('#ultraToast').textContent=text;$('#ultraToast').hidden=false;clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('#ultraToast').hidden=true,6500);}
 function panel(type,title){const id=++contextGeneration;$('#ultraContext').hidden=false;$('#contextType').textContent=type;$('#contextTitle').textContent=title;$('#contextContent').innerHTML='<div class="u-loading">Daten werden abgerufen …</div>';return id;}
 function failure(error,id){if(id!==undefined&&id!==contextGeneration)return;$('#contextContent').innerHTML=`<p class="u-error">${e(error.message||error)}</p><p class="u-note">Es werden keine Ersatzdaten erfunden. Prüfe die Verbindung oder versuche es später erneut.</p>`;}
 function append(role,text){const area=$('#conversation');area.querySelector('.u-welcome')?.remove();const node=document.createElement('article');node.className='u-message '+role;node.textContent=text;area.append(node);while(area.children.length>60)area.firstElementChild.remove();area.scrollTop=area.scrollHeight;return node;}
 function sources(node,items=[]){if(!items.length)return;const block=document.createElement('div');items.forEach((s,i)=>{const u=U.url(s.url);if(!u)return;const a=document.createElement('a');a.textContent=`[${i+1}] ${s.title||new URL(u).hostname}`;a.href=u;a.target='_blank';a.rel='noopener noreferrer';block.append(a);});node.append(block);}
 function complete(node,text,src=[]){node.classList.remove('pending');node.textContent=text;sources(node,src);const time=document.createElement('time');time.textContent=new Date().toLocaleTimeString('de-AT',{hour:'2-digit',minute:'2-digit'});node.append(time);$('#conversation').scrollTop=$('#conversation').scrollHeight;}
 function trace(node,text){node.textContent='';const span=document.createElement('span');span.className='u-trace';span.textContent=text;node.append(span);}
 const wc=code=>code===0?['☀','Klar']:code<=3?['☁','Bewölkt']:code<=48?['≋','Nebel']:code<=67?['☂','Regen']:code<=77?['❄','Schnee']:code<=82?['☂','Regenschauer']:code<=86?['❄','Schneeschauer']:['ϟ','Gewitter'];
 const val=(x,s='')=>Number.isFinite(x)?Math.round(x)+s:'—';
 async function locate(place){const d=await U.api('geocode?q='+encodeURIComponent(place));if(!d.results.length)throw new Error('Ort nicht gefunden: '+place);lastPlace=d.results[0].name;return d.results[0];}
 async function weatherView(place,day=0){
  const id=panel('WETTER / VORHERSAGE',place);try{
   const p=await locate(place),d=await U.api(`weather?lat=${p.latitude}&lon=${p.longitude}`);if(id!==contextGeneration)return null;
   const c=d.current,dy=d.daily,hh=d.hourly,[icon,label]=wc(c.weather_code),hours=hh.time.map((t,i)=>({t,i})).filter(x=>x.t>=c.time.slice(0,13)+':00').slice(0,24);
   const points=hours.map(x=>hh.temperature_2m[x.i]).filter(Number.isFinite),min=Math.min(...points),max=Math.max(...points);const path=points.map((v,i)=>`${i?'L':'M'}${i/Math.max(1,points.length-1)*450},${70-(v-min)/Math.max(1,max-min)*55}`).join(' ');
   $('#contextTitle').textContent=`${p.name} · ${day===1?'morgen':day===2?'übermorgen':'Wetter'}`;
   $('#contextContent').innerHTML=`<div class="u-weather-hero"><div><span class="u-kicker">JETZT · ${e(c.time.slice(11))}</span><strong>${val(c.temperature_2m,'°')}</strong><p>${e(label)}<br>Gefühlt ${val(c.apparent_temperature,'°')}</p></div><div class="u-weather-icon" aria-hidden="true">${icon}</div></div><div class="u-weather-metrics"><div class="u-weather-metric"><span>WIND</span><strong>${val(c.wind_speed_10m)} km/h</strong></div><div class="u-weather-metric"><span>LUFTFEUCHTE</span><strong>${val(c.relative_humidity_2m,'%')}</strong></div><div class="u-weather-metric"><span>REGEN ${day?'MORGEN':'HEUTE'}</span><strong>${val(dy.precipitation_probability_max[day],'%')}</strong></div></div><span class="u-kicker">DIE NÄCHSTEN 24 STUNDEN · TEMPERATUR</span>${points.length?`<svg class="u-weather-chart" viewBox="0 0 450 90" role="img" aria-label="Temperaturverlauf der nächsten 24 Stunden"><path d="${path}"/><text x="0" y="86" fill="#8fa6ae" font-size="9">${val(min,'°')} bis ${val(max,'°')}</text></svg>`:''}<div class="u-hourly">${hours.map(({t,i})=>`<div class="u-hour"><span>${e(t.slice(11))}</span><strong>${val(hh.temperature_2m[i],'°')}</strong><small>${val(hh.precipitation_probability[i],'%')}</small></div>`).join('')}</div><span class="u-kicker">7-TAGE-VORHERSAGE</span><div>${dy.time.map((t,i)=>`<div class="u-daily-row ${i===day?'is-selected':''}"><span>${i===0?'Heute':i===1?'Morgen':new Date(t+'T12:00:00').toLocaleDateString('de-AT',{weekday:'short',day:'numeric',month:'numeric'})}</span><span>${wc(dy.weather_code[i])[0]}</span><span>${val(dy.temperature_2m_min[i],'°')} / ${val(dy.temperature_2m_max[i],'°')}</span><small>${val(dy.precipitation_sum[i])} mm</small></div>`).join('')}</div><p class="u-note">${e(U.attribution(d))}<br>Ortszeit: ${e(d.timezone)} · <a href="https://open-meteo.com/" target="_blank" rel="noopener noreferrer">Open-Meteo</a> · CC BY 4.0<br>Prozentwerte zeigen Niederschlagswahrscheinlichkeit. Millimeter zeigen die Tagesmenge.</p>`;
   return {text:`${day===1?'Morgen':day===2?'Übermorgen':'Heute'} werden in ${p.name} ${Math.round(dy.temperature_2m_min[day])} bis ${Math.round(dy.temperature_2m_max[day])} Grad erwartet. ${wc(dy.weather_code[day])[1]}, Regenwahrscheinlichkeit ${dy.precipitation_probability_max[day]} Prozent.${d.stale?' Die zwischengespeicherten Werte sind veraltet.':''}`,data:d};
  }catch(err){failure(err,id);throw err;}
 }
 function newsHTML(items){return items.map(x=>`<article class="u-news-card">${U.url(x.image)?`<img src="${e(U.url(x.image))}" alt="Artikelbild: ${e(x.title)}" loading="lazy" referrerpolicy="no-referrer">`:''}<div><small>${e(x.source)} · ${e(U.fmtTime(x.published_at||x.t))}</small><a href="${e(U.url(x.url))}" target="_blank" rel="noopener noreferrer">${e(x.title)} ↗</a>${x.summary?`<p>${e(x.summary)}</p>`:''}</div></article>`).join('');}
 function photoErrors(node){node.querySelectorAll('img').forEach(img=>img.addEventListener('error',()=>{const p=document.createElement('p');p.className='u-note';p.textContent='Bildquelle derzeit nicht erreichbar.';img.replaceWith(p);},{once:true}));}
 async function newsView(query='Österreich',category='all'){
  const id=panel('NACHRICHTEN / QUELLEN',query);try{const d=await U.api('news?q='+encodeURIComponent(query)+'&category='+category);if(id!==contextGeneration)return null;
   const filters=[['all','Alle'],['austria','Österreich'],['world','Welt'],['business','Wirtschaft'],['science','Wissen'],['sport','Sport']];
   $('#contextContent').innerHTML=`<div class="u-news-filters">${filters.map(([k,t])=>`<button class="u-news-filter" data-category="${k}" aria-pressed="${k===category}">${t}</button>`).join('')}</div><p class="u-note">${d.items.length} Meldungen aus den letzten ${d.window_days} Tagen · ${e(U.attribution(d))}</p>${d.items.length?newsHTML(d.items):'<p>Keine aktuellen Treffer zu dieser Suche gefunden.</p>'}`;
   $('#contextContent').querySelectorAll('[data-category]').forEach(b=>b.onclick=()=>newsView(query,b.dataset.category).catch(()=>{}));photoErrors($('#contextContent'));
   return {text:d.items.length?`${d.items.length} veröffentlichte Meldungen zu ${query}. Die neueste: ${d.items[0].title}.`:`Keine aktuellen Meldungen zu ${query} gefunden.`,data:d};
  }catch(err){failure(err,id);throw err;}
 }
 function imagesHTML(items){return `<div class="u-gallery">${items.map(x=>`<figure><a href="${e(U.url(x.source_url))}" target="_blank" rel="noopener noreferrer"><img src="${e(U.url(x.url))}" alt="${e(x.title)}" loading="lazy"></a><figcaption><span class="u-image-title">${e(x.title)}</span>${e(x.artist||'Urheber auf der Quelldatei')} · ${e(x.license||'Lizenz auf der Quelldatei prüfen')}<a href="${e(U.url(x.source_url))}" target="_blank" rel="noopener noreferrer">Wikimedia Commons ↗</a></figcaption></figure>`).join('')}</div>`;}
 async function imagesView(query){const id=panel('BILDER / ORIGINALQUELLEN',query);try{const d=await U.api('images?q='+encodeURIComponent(query));if(id!==contextGeneration)return null;$('#contextContent').innerHTML=(d.items.length?imagesHTML(d.items):'<p>Keine Bilder aus dieser Quelle gefunden.</p>')+`<p class="u-note">${e(U.attribution(d))} · Motive stammen aus der Suchquelle; Zuordnung anhand der Bildbeschriftung prüfen.</p>`;photoErrors($('#contextContent'));return {text:`${d.items.length} Bilder mit Quellen- und Lizenzangaben zu ${query}.`,data:d};}catch(err){failure(err,id);throw err;}}
 async function placeView(place){
  window.jarvisShowView('citylab');const p=await JarvisWorld.search(place);if(!p)return null;
  const id=panel('ORT / BILDER & MELDUNGEN',p.name);
  const [im,nw]=await Promise.allSettled([U.api('images?q='+encodeURIComponent(p.name)),U.api('news?q='+encodeURIComponent(p.name))]);
  if(id!==contextGeneration)return null;
  $('#contextContent').innerHTML=`<p class="u-note">${e(p.label||p.name)} · ${e(p.source)}<br>Die Karte zeigt diesen Standort. Bild- und Nachrichtensuche beziehen sich auf den Ortsnamen.</p><div class="u-linkrow"><button id="cityNearby">Sehenswürdigkeiten suchen</button><button id="contextCityWeather">Wetter anzeigen</button></div><div style="margin-top:18px">${im.status==='fulfilled'&&im.value.items.length?imagesHTML(im.value.items.slice(0,4)):'<p class="u-note">Keine Ortsbilder verfügbar.</p>'}</div><span class="u-kicker" style="margin-top:22px">AKTUELLE MELDUNGEN</span>${nw.status==='fulfilled'?(nw.value.items.length?newsHTML(nw.value.items.slice(0,3)):'<p class="u-note">Keine aktuellen Treffer.</p>'):'<p class="u-note">Nachrichtenquelle derzeit nicht erreichbar.</p>'}`;
  $('#cityNearby').onclick=()=>{closeContext();JarvisWorld.findPlaces('Sehenswürdigkeiten').catch(toast);};$('#contextCityWeather').onclick=()=>weatherView(p.name).catch(()=>{});photoErrors($('#contextContent'));
  return {text:`Die 3D-Karte steht bei ${p.name}. Gebäude und Orte laden beim Heranzoomen; Datenqualität und Quellen sind eingeblendet.`};
 }
 function closeContext(){contextGeneration++;$('#ultraContext').hidden=true;}
 function confirmAction(text){return new Promise(resolve=>{const dlg=$('#actionConfirm');if(dlg.open){resolve(false);return;}$('#actionDescription').textContent=text;const done=yes=>{dlg.close();$('#actionAccept').onclick=null;$('#actionCancel').onclick=null;resolve(yes);};$('#actionAccept').onclick=()=>done(true);$('#actionCancel').onclick=()=>done(false);dlg.oncancel=ev=>{ev.preventDefault();done(false);};dlg.showModal();$('#actionCancel').focus();});}
 async function homeView(){
  if(document.body.dataset.dashboardView!=='devices')window.jarvisShowView('devices');$('#homeDeviceStatus').innerHTML='<div class="u-loading">Geräte werden abgefragt …</div>';
  try{const d=await U.api('home');$('#homeDeviceStatus').textContent=U.attribution(d);$('#homeDeviceGrid').innerHTML=d.devices.length?d.devices.map((x,i)=>`<article class="u-device-card"><span class="u-kicker">${e(x.domain)}</span><h3>${e(x.name)}</h3><strong>${e(x.state)} ${e(x.unit)}</strong>${x.controllable?`<button data-device="${i}" ${['unknown','unavailable'].includes(x.state)?'disabled':''}>${x.state==='on'?'Ausschalten':'Einschalten'}</button>`:'<small>Statusanzeige · keine Steuerung freigegeben</small>'}</article>`).join(''):'<p>Keine unterstützten Geräte gefunden.</p>';
   $('#homeDeviceGrid').querySelectorAll('[data-device]').forEach(b=>b.onclick=async()=>{const device=d.devices[+b.dataset.device],action=device.state==='on'?'turn_off':'turn_on';if(!await confirmAction(`${device.name}\n${action==='turn_on'?'Licht einschalten':'Licht ausschalten'}?`))return;b.disabled=true;try{await U.api('home/action',{body:{entity_id:device.entity_id,action,confirmed:true}});toast('Schaltauftrag angenommen. Gerätestatus wird neu abgefragt.');await homeView();}catch(err){toast(err.message);b.disabled=false;}});
  }catch(err){$('#homeDeviceStatus').innerHTML=`<p class="u-error">${e(err.message)}</p><button id="setupHome">Verbindung einrichten</button>`;$('#homeDeviceGrid').replaceChildren();$('#setupHome').onclick=openCfg;}
 }
 async function systemView(){
  if(document.body.dataset.dashboardView!=='system')return;
  try{const d=await U.api('system'),gb=n=>(n/1073741824).toFixed(1)+' GB';
   const cards=[['CPU',d.cpu_percent===null?'Nicht gemessen':d.cpu_percent.toFixed(1)+' %',d.cpu_count+' logische Kerne',d.cpu_percent],['ARBEITSSPEICHER',d.ram_percent===null?'Nicht gemessen':d.ram_percent.toFixed(1)+' %',d.ram_total?gb(d.ram_used)+' / '+gb(d.ram_total):'Optionale psutil-Erweiterung',d.ram_percent],['DATENTRÄGER',gb(d.disk_free)+' frei',gb(d.disk_used)+' / '+gb(d.disk_total),d.disk_used/d.disk_total*100],['GRAFIKPROZESSOR','Nicht verbunden','Kein GPU-Telemetriedienst eingerichtet',null]];
   $('#systemStats').innerHTML=cards.map(([title,v,n,p])=>`<article class="u-system-card"><h3>${title}</h3><strong>${e(v)}</strong>${p!==null?`<div class="u-meter"><i style="width:${Math.max(0,Math.min(100,p))}%"></i></div>`:''}<small>${e(n)}</small></article>`).join('');$('#systemProcesses').innerHTML=`<span class="u-kicker">PROZESSE / RAM-ANTEIL</span>${d.processes.map(p=>`<div class="u-process-row"><strong>${e(p.name)}</strong><span>PID ${p.pid} · ${p.memory_percent}% RAM</span></div>`).join('')||'<p class="u-note">Prozessliste nicht verfügbar. Optional: python -m pip install psutil</p>'}<p class="u-note">${e(U.attribution(d))}${d.note?'<br>'+e(d.note):''}</p>`;
  }catch(err){$('#systemStats').innerHTML=`<p class="u-error">${e(err.message)}</p>`;}
 }
 const oldShow=window.jarvisShowView;
 window.jarvisShowView=name=>{if(name==='earth')name='citylab';oldShow(name);if(name==='citylab')JarvisWorld.open();if(name==='devices')$('#deskCrumb').textContent='Smart Home';if(name==='system')$('#deskCrumb').textContent='System';};
 const obs=new MutationObserver(()=>{const view=document.body.dataset.dashboardView;if(view==='earth'){window.jarvisShowView('citylab');return;}if(view==='devices')homeView();clearInterval(systemTimer);systemTimer=null;if(view==='system'){systemView();systemTimer=setInterval(()=>{if(!document.hidden)systemView();},10000);}});obs.observe(document.body,{attributes:true,attributeFilter:['data-dashboard-view']});
 // Wrap external calendar mutation with a reviewable, explicit confirmation.
 const priorEvent=window.addGoogleEvent;
 window.addGoogleEvent=async text=>await confirmAction('Google-Kalendertermin anlegen:\n'+text+'\n\nBitte Datum, Uhrzeit und Bezeichnung prüfen.')?priorEvent(text):'Kalendereintrag abgebrochen.';
 // Existing generated command markers may no longer perform external actions.
 act=function(k,v){if(k==='TERMIN'){S.ev.push(v);evr();}else if(k==='TIMER'){const m=Number(v);if(Number.isFinite(m)&&m>0&&m<=10080)featureAlarm('Timer',`${m} Minuten`,m*60000);}};
 async function askAI(text,node,search=false,signal){trace(node,search?'Websuche und Antwort werden angefordert …':'KI verarbeitet die Anfrage …');const d=await U.api('chat',{body:{text,history:S.hist.slice(-16),facts:memText()+'\nKalender: '+S.cal.items.slice(0,10).map(calText).join('; ')+'\nLetzter Ort: '+lastPlace,search},signal});return d;}
 const memory=t=>{
  let m=t.match(/^(?:merk(?:e)?\s+dir|speicher(?:e)?|vergiss\s+nicht)\s*(?:bitte\s*)?[:,]?\s+(.+)$/i);
  if(m){const list=memList();list.push(m[1].trim().slice(0,300));localStorage.setItem('jarvis_memory',JSON.stringify(list.slice(-40)));return 'Gemerkt. Du kannst „Vergiss mein Gedächtnis“ sagen, um die gespeicherten Angaben zu löschen.';}
  if(/^(?:vergiss|lösche)\s+(?:alles|mein gedächtnis|alles über mich)/i.test(t)){localStorage.removeItem('jarvis_memory');return 'Gespeicherte Angaben gelöscht.';}return null;
 };
 const knownLocal=/^(?:aufgabe|notiz|erinnere|erinnerung|timer|stoppuhr|pomodoro|rechne|berechne|wandle|quiz|tagesbriefing|ort merken|sonnenaufgang|sonnenuntergang|bambu|stundenplan|google kalender|trage|trag|erstelle|neuer termin|öffne schnellzugriff|fußweg|autofahrt|route|helle route|kameras|kamera|wie spät|wie viel uhr)/i;
 send=async function(text,options={}){
  text=String(text||'').trim();if(!text)return;
  if(/^(?:stopp|stop|abbrechen|ruhe)[.! ]*$/i.test(text)){cancel();return;}
  if(S.sendBusy){toast('Eine Anfrage läuft. Mit „Stopp“ kannst du sie abbrechen.');return;}
  const id=++requestId;activeController=new AbortController();S.sendBusy=true;set('thinking');$('#in').value='';unlockAudio();append('user',text);const node=append('assistant','');trace(node,'Anfrage wird zugeordnet …');
  let kind=U.intent(text,S.home,lastPlace),result,ai=null;
  if(lastIntent?.type==='weather'&&/^(?:und\s+)?(?:wie\s+)?(?:morgen|übermorgen|heute)[?!. ]*$/i.test(text))kind={...lastIntent,day:/übermorgen/i.test(text)?2:/morgen/i.test(text)?1:0};
  try{
   const remembered=memory(text);
   if(remembered)result={text:remembered};
   else if(kind.type==='weather'){trace(node,'Ort auflösen → Wetterdaten abrufen → Vorhersage anzeigen');result=await weatherView(kind.place,kind.day);}
   else if(kind.type==='news'){trace(node,'Nachrichtenquellen abrufen → Datum prüfen → Meldungen anzeigen');result=await newsView(kind.query);}
   else if(kind.type==='images')result=await imagesView(kind.query);
   else if(kind.type==='place')result=await placeView(kind.place);
   else if(kind.type==='places'){window.jarvisShowView('citylab');const d=await JarvisWorld.findPlaces(kind.query,kind.place);result={text:`${d?.features.length||0} kartierte Treffer für ${kind.query} bei ${kind.place}. Wähle einen Treffer für Standort und verfügbare Angaben.`};}
   else if(kind.type==='nearby'){const pos=await new Promise((resolve,reject)=>navigator.geolocation?navigator.geolocation.getCurrentPosition(resolve,reject,{timeout:12000,maximumAge:60000}):reject(new Error('Standortabfrage nicht unterstützt.')));window.jarvisShowView('citylab');const p={name:'Mein Standort',latitude:pos.coords.latitude,longitude:pos.coords.longitude};await JarvisWorld.fly(p);const d=await JarvisWorld.findPlaces(kind.query,null,p);result={text:`${d.features.length} kartierte Treffer in deiner Umgebung.`};}
   else if(kind.type==='home'){window.jarvisShowView('devices');result={text:'Die Smart-Home-Zentrale fragt den aktuellen Status ab. Wähle das konkrete Licht und bestätige die gewünschte Aktion.'};}
   else if(kind.type==='system'){window.jarvisShowView('system');result={text:'Die Systemansicht fragt echte Messwerte vom lokalen JARVIS-Server ab. Nicht verbundene Messungen sind entsprechend gekennzeichnet.'};}
   else if(kind.type==='hands'){const H=window.JarvisHands;if(!H)result={text:'Die Handsteuerung ist in dieser Seite nicht geladen.'};else if(kind.action==='off'){H.disable?H.disable('Per Sprachbefehl gestoppt.'):H.toggle();result={text:'Handsteuerung aus. Die Kamera ist freigegeben.'};}else{document.querySelector('#handPanel')&&(document.querySelector('#handPanel').hidden=false);H.enable();result={text:'Ich starte die Handsteuerung. Der Browser fragt dich gegebenenfalls nach der Kameraerlaubnis; ohne Zustimmung bleibt die Kamera aus.'};}}
   else if(kind.type==='holoModel'){window.jarvisShowView('holo');window.JarvisHolo?.setModel(kind.model);result={text:`Das ${kind.model==='globe'?'Globus':kind.model==='cube'?'Gitter':'Kern'}-Hologramm ist ausgewählt.`};}
   else if(kind.type==='holoControl'){window.jarvisShowView('holo');const H=window.JarvisHolo; if(!H)result={text:'Das 3D-Labor ist noch nicht bereit.'};else{if(kind.action==='reset')H.reset();else if(kind.action==='in')H.scaleBy(1.15);else if(kind.action==='out')H.scaleBy(1/1.15);else if(kind.action==='autoOn')H.setAuto(true);else if(kind.action==='autoOff')H.setAuto(false);result={text:({reset:'Das Objekt wurde zurückgesetzt.',in:'Das Objekt wurde vergrößert.',out:'Das Objekt wurde verkleinert.',autoOn:'Automatische Drehung aktiviert.',autoOff:'Automatische Drehung pausiert.'})[kind.action]};}}
   else if(kind.type==='view'){window.jarvisShowView(kind.view);result={text:kind.view==='holo'?'Das 3D-Labor ist geöffnet. Drehen mit Maus, Pfeiltasten oder zwei gepinchten Händen.':'Zurück im Kontrollraum.'};}
   else if(kind.type==='navigate'){window.JarvisHands?.navigate(kind.dir);result={text:'Panel gewechselt.'};}
   else if(kind.type==='calendar'){window.jarvisShowView('schedule');result={text:S.cal.token||S.cal.imported?'Hier sind deine verfügbaren Kalenderdaten.':'Der Kalender ist noch nicht verbunden. Du kannst Google Kalender verbinden oder eine ICS-Datei importieren.'};}
   else if(kind.type==='math'){
    const exp=text.replace(/^(?:rechne|berechne|was (?:ist|sind|ergibt)|wie viel ist)\s*/i,'').replace(/[?=]+$/,'');const n=calculateExpression(exp);result={text:`${exp} = ${n}`};
   }else if(/^(?:hallo|hi|hey|servus|guten morgen|guten abend)[!. ]*$/i.test(text))result={text:'Hallo! Ich bin bereit. Du kannst nach Wetter, Orten und Nachrichten fragen oder mit mir etwas durchdenken.'};
   else if(knownLocal.test(text)||FX.quizOn){const r=await handleLocalFeature(text);if(r!==null)result={text:r};}
   if(!result){if(renderers.has(kind.type))result=await renderers.get(kind.type)(kind);else{ai=await askAI(kind.query||text,node,kind.type==='search'||kind.search,activeController.signal);result={text:ai.text};}}
   if(id!==requestId)return;
   if(!result)result={text:'Die Anfrage wurde durch einen neueren Kontext ersetzt.'};
   complete(node,result.text,ai?.sources||[]);
   if(ai?.search_entry){const frame=document.createElement('iframe');frame.className='u-grounding';frame.title='Google-Suchhinweise';frame.setAttribute('sandbox','allow-popups allow-popups-to-escape-sandbox');frame.srcdoc=ai.search_entry;node.append(frame);}
   if(ai&&kind.search&&!ai.searched){const p=document.createElement('small');p.className='u-note';p.textContent='Für diese Antwort wurde keine Websuche bestätigt.';node.append(p);}
   S.hist.push({role:'user',content:text},{role:'assistant',content:result.text});S.hist=S.hist.slice(-20);lastIntent=kind;
   S.sendBusy=false;if(localStorage.getItem('ultra_speak')!=='0')say(result.text.slice(0,1800));else set('idle');
  }catch(err){if(id!==requestId)return;const msg=err.name==='AbortError'?'Anfrage abgebrochen.':err.message||'Anfrage fehlgeschlagen.';node.classList.add('error');complete(node,msg);S.sendBusy=false;set('idle');toast(msg);}
  finally{if(id===requestId){S.sendBusy=false;activeController=null;if(S.state==='thinking')set('idle');}}
 };
 function cancel(){requestId++;activeController?.abort();activeController=null;S.sendBusy=false;S.live=0;$('#live').classList.remove('on');try{stop();}catch{}closeContext();set('idle');toast('Anfrage und Sprachausgabe gestoppt.');}
 window.jarvisCancel=cancel;
 // Keep legacy news consumers on the same real, dated source pipeline.
 getNewsFast=async query=>(await U.api('news?q='+encodeURIComponent(query||'Österreich'))).items;
 getCommonsImages=async query=>(await U.api('images?q='+encodeURIComponent(query))).items.map(x=>({...x,thumb:x.url,description:x.title,license:x.license}));
 getPlaceImages=getCommonsImages;getTopicImages=getCommonsImages;
 ask=async()=>{const h=S.hist.slice();const last=h.pop();const d=await U.api('chat',{body:{text:last?.content||'',history:h,facts:memText()}});return d.text;};
 const legacyLoadHome=loadHome;
 loadHome=async()=>{try{const p=await locate(S.home),d=await U.api(`weather?lat=${p.latitude}&lon=${p.longitude}`);S.wx=`${p.name}: ${d.current.temperature_2m} Grad, ${wc(d.current.weather_code)[1]}`;$('#homeWeatherValue').textContent=val(d.current.temperature_2m,'°')+' · '+p.name;$('#homeWeatherDetail').textContent=wc(d.current.weather_code)[1]+' · '+U.fmtTime(d.fetched_at);$('#wx').textContent=S.wx;}catch{$('#homeWeatherDetail').textContent='Quelle derzeit nicht erreichbar';}};
 const originalCfg=openCfg;
 openCfg=function(){originalCfg();const cfg=U.state.config;$('#k').value='';$('#k').placeholder=cfg?.[$('#p').value]?'Schlüssel gespeichert · leer lassen zum Beibehalten':'API-Schlüssel eintragen';$('#uModel').value=cfg?.[S.prov+'_model']||'';$('#uCesium').value=cfg?.cesium_token||'';$('#uTiles').value=cfg?.tiles_asset_id||'';$('#uHaUrl').value=cfg?.ha_url||'';$('#uHaToken').value='';$('#uVoice').checked=localStorage.getItem('ultra_speak')!=='0';$('#uMotion').checked=localStorage.getItem('ultra_motion')==='reduced';$('#uSettingsStatus').textContent=cfg?'Backend erreichbar. Zugangsdaten werden hier nicht zurückgelesen.':'Backend nicht erreichbar. Mit Start-Jarvis.bat starten.';};
 $('#cfg').onclick=openCfg;
 $('#p').onchange=()=>{$('#k').value='';const cfg=U.state.config;$('#uModel').value=cfg?.[$('#p').value+'_model']||'';$('#k').placeholder=cfg?.[$('#p').value]?'Schlüssel gespeichert':'API-Schlüssel eintragen';};
 $('#sv').onclick=async()=>{
  const b=$('#sv');b.disabled=true;
  try{const provider=$('#p').value,key=$('#k').value.trim(),payload={provider,cesium_token:$('#uCesium').value.trim(),tiles_asset_id:$('#uTiles').value.trim(),ha_url:$('#uHaUrl').value.trim(),ha_token:$('#uHaToken').value.trim()};if(key)payload[provider+'_key']=key;const model=$('#uModel').value.trim();if(model)payload[provider+'_model']=model;
   const cfg=await U.api('config',{body:payload});U.state.config=cfg;S.prov=provider;S.key=cfg[provider]?'backend':'';S.home=$('#h').value.trim()||'Wien';S.gcid=$('#gcid').value.trim();S.timetable=$('#timetable').value;S.piperVoice=$('#piperVoice').value;
   ['prov','home','gcid','timetable'].forEach(k=>localStorage.setItem(k,S[k]));localStorage.setItem('piper_voice',S.piperVoice);localStorage.setItem('ultra_speak',$('#uVoice').checked?'1':'0');localStorage.setItem('ultra_motion',$('#uMotion').checked?'reduced':'full');document.body.dataset.motion=$('#uMotion').checked?'reduced':'full';$('#k').value='';$('#uHaToken').value='';$('#dlg').close();renderSchedule();renderCalendar();window.jarvisDashboardRefresh?.();loadHome();toast('Einstellungen gespeichert. Nach Änderungen an 3D-Daten die Seite neu laden.');
  }catch(err){$('#uSettingsStatus').textContent=err.message;}finally{b.disabled=false;}
 };
 // Closing settings must never implicitly store secrets in localStorage.
 $('#dlg').onclose=()=>{};$('#dlg').onkeydown=ev=>{if(ev.key==='Enter'&&ev.target.tagName!=='TEXTAREA'){ev.preventDefault();$('#sv').click();}};
 $('#contextClose').onclick=closeContext;$('#homeWorld').onclick=()=>window.jarvisShowView('citylab');$('#homeWeather').onclick=()=>weatherView(S.home).catch(()=>{});$('#homeNews').onclick=()=>newsView().catch(()=>{});$('#homeRefresh').onclick=homeView;$('#systemRefresh').onclick=systemView;
 const stopBtn=document.createElement('button');stopBtn.id='ultraStop';stopBtn.textContent='■';stopBtn.title='Anfrage und Sprachausgabe stoppen';stopBtn.setAttribute('aria-label',stopBtn.title);stopBtn.onclick=cancel;$('#bar').append(stopBtn);
 $('#in').setAttribute('aria-label','Nachricht an Jarvis');$('#in').placeholder='Frag Jarvis …';$('#conversation').addEventListener('click',ev=>{const b=ev.target.closest('[data-ask]');if(b)send(b.dataset.ask);});
 document.addEventListener('keydown',ev=>{if(ev.key==='Escape'&&!$('#dlg').open&&!$('#actionConfirm').open)closeContext();});
 document.body.dataset.motion=localStorage.getItem('ultra_motion')||'full';
 U.ready.then(async cfg=>{
  const migration={};for(const [key,old] of [['gemini_key','key_gemini'],['claude_key','key_claude'],['ha_token','ha_token'],['ha_url','ha_url']]){const v=localStorage.getItem(old);if(v&&v!=='backend')migration[key]=v;}
  if(Object.keys(migration).length){try{cfg=await U.api('config',{body:migration});['key_gemini','key_claude','ha_token','ha_url'].forEach(k=>localStorage.removeItem(k));}catch{toast('Alte Zugangsdaten konnten noch nicht übernommen werden. Bitte Einstellungen prüfen.');}}
  U.state.config=cfg;S.prov=cfg.provider;S.key=cfg[cfg.provider]?'backend':'';$('#ultraConnection').textContent=cfg[cfg.provider]?'Backend bereit · KI konfiguriert':'Backend bereit · KI noch einrichten';loadHome();
 }).catch(()=>{$('#ultraConnection').textContent='Backend nicht erreichbar';toast('Bitte ZIP vollständig entpacken und Start-Jarvis.bat ausführen.');});
 window.JarvisUltra={weatherView,newsView,imagesView,placeView,homeView,systemView,registerVisual:(type,fn)=>renderers.set(type,fn),intent:U.intent,confirmAction,cancel,diagnostics:()=>({context:!$('#ultraContext').hidden,busy:S.sendBusy,history:S.hist.length,backend:!!U.state.config})};
})();
