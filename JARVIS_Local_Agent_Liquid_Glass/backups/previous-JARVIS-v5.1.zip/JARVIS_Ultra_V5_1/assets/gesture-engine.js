/* JARVIS gesture engine: turns hand landmarks into discrete, debounced events.
 * Pure logic, no DOM and no camera access, so it is fully unit-testable.
 * Input per frame: update(hands, tMs) with hands = [{landmarks:[21 x {x,y,z}], handedness}]
 * (x,y normalised 0..1, already mirrored so moving the hand right increases x).
 * Output: array of events, e.g. {type:'pinchStart'|'click'|'dragStart'|'drag'|'dragEnd'|
 *   'swipe'|'scroll'|'palmHold'|'twoHandStart'|'twoHand'|'twoHandEnd'|'lost'|'found'|'move'}.
 * Original implementation (MediaPipe landmark indices are public API; no third-party code copied). */
((root) => {
  'use strict';
  const DEFAULTS = {
    sensitivity: 1,        // 0.5 (calm) .. 2 (fast): scales pointer reach and scroll gain
    smoothing: 0.6,        // 0 (raw) .. 0.95 (very smooth): One-Euro minimum cutoff
    pinchOn: 0.30,         // pinch engages below this thumb-index distance / palm size
    pinchOff: 0.46,        // pinch releases above this (hysteresis)
    pinchFrames: 2,        // consecutive frames required to switch pinch state
    dragThreshold: 0.025,  // normalised travel before a pinch becomes a drag
    palmHoldMs: 700,
    palmCooldownMs: 1800,
    swipeDistance: 0.26,   // normalised travel inside swipeWindowMs
    swipeWindowMs: 320,
    swipeCooldownMs: 900,
    swipeRestMs: 250,      // hand must slow down this long before another swipe can arm
    scrollGain: 2.2,
    lostMs: 450,           // no hands for this long = tracking lost (releases held pinch)
    twoHandMinDist: 0.08
  };
  const dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
  const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));

  /* One Euro filter: strong smoothing when still, low lag when moving fast. */
  function oneEuro(minCutoff, beta = 0.02, dCutoff = 1) {
    let xPrev = null, dxPrev = 0, tPrev = 0;
    const alpha = (cutoff, dt) => { const r = 2 * Math.PI * cutoff * dt; return r / (r + 1); };
    return {
      reset() { xPrev = null; dxPrev = 0; },
      step(x, t) {
        if (xPrev === null) { xPrev = x; tPrev = t; return x; }
        const dt = Math.max((t - tPrev) / 1000, 1e-3);
        const dx = (x - xPrev) / dt;
        const dxHat = dxPrev + alpha(dCutoff, dt) * (dx - dxPrev);
        const cutoff = minCutoff + beta * Math.abs(dxHat);
        const xHat = xPrev + alpha(cutoff, dt) * (x - xPrev);
        xPrev = xHat; dxPrev = dxHat; tPrev = t;
        return xHat;
      }
    };
  }

  function palmSize(l) { return Math.max(dist(l[0], l[9]), 1e-4); }
  /* A finger counts as extended when its tip is clearly farther from the wrist than its PIP joint. */
  function fingerUp(l, tip, pip) { return dist(l[0], l[tip]) > dist(l[0], l[pip]) * 1.12; }
  function pose(l) {
    const idx = fingerUp(l, 8, 6), mid = fingerUp(l, 12, 10), ring = fingerUp(l, 16, 14), pink = fingerUp(l, 20, 18);
    const thumb = dist(l[4], l[17]) > dist(l[3], l[17]) * 1.08;
    const pinch = dist(l[4], l[8]) / palmSize(l);
    return {
      idx, mid, ring, pink, thumb, pinch,
      open: idx && mid && ring && pink && thumb,
      peace: idx && mid && !ring && !pink,
      fist: !idx && !mid && !ring && !pink
    };
  }

  function createEngine(userCfg = {}) {
    let cfg = Object.assign({}, DEFAULTS, userCfg);
    const filt = { x: null, y: null };
    const mkFilters = () => { const c = 0.4 + (1 - clamp(cfg.smoothing, 0, 0.95)) * 6; filt.x = oneEuro(c); filt.y = oneEuro(c); };
    mkFilters();

    const S = {
      pinched: false, pinchCount: 0, dragging: false, pinchStart: null, cursor: { x: .5, y: .5 },
      palmSince: 0, palmCooldownUntil: 0, palmArmed: true,
      swipeTrail: [], swipeCooldownUntil: 0, swipeArmed: true, restSince: 0,
      scrollPrev: null, scrolling: false,
      twoHand: null, lastSeen: 0, tracking: false, lost: false
    };

    function reach(p) { // map the central region of the camera frame onto the whole screen
      const span = clamp(0.62 / cfg.sensitivity, 0.3, 0.95), lo = (1 - span) / 2;
      return { x: clamp((p.x - lo) / span, 0, 1), y: clamp((p.y - lo) / span, 0, 1) };
    }

    function releaseAll(ev, reason) {
      if (S.dragging) ev.push({ type: 'dragEnd', x: S.cursor.x, y: S.cursor.y, reason });
      else if (S.pinched) ev.push({ type: 'pinchCancel', x: S.cursor.x, y: S.cursor.y, reason });
      if (S.twoHand) ev.push({ type: 'twoHandEnd', reason });
      if (S.scrolling) ev.push({ type: 'scrollEnd' });
      S.pinched = false; S.dragging = false; S.pinchStart = null; S.pinchCount = 0;
      S.twoHand = null; S.scrolling = false; S.scrollPrev = null; S.palmSince = 0;
      S.swipeTrail = []; filt.x.reset(); filt.y.reset();
    }

    function update(hands, t) {
      const ev = [];
      hands = (hands || []).filter(h => h && h.landmarks && h.landmarks.length >= 21);
      if (!hands.length) {
        if (S.tracking && t - S.lastSeen > cfg.lostMs) {
          releaseAll(ev, 'lost'); S.tracking = false; S.lost = true; ev.push({ type: 'lost' });
        }
        return ev;
      }
      S.lastSeen = t;
      if (!S.tracking) { S.tracking = true; if (S.lost) { S.lost = false; ev.push({ type: 'found' }); } }

      /* ---- two-hand manipulation: both hands pinching ---- */
      if (hands.length >= 2) {
        const a = hands[0].landmarks, b = hands[1].landmarks;
        const pa = pose(a), pb = pose(b);
        const bothPinch = pa.pinch < cfg.pinchOff && pb.pinch < cfg.pinchOff;
        const ca = { x: (a[4].x + a[8].x) / 2, y: (a[4].y + a[8].y) / 2 };
        const cb = { x: (b[4].x + b[8].x) / 2, y: (b[4].y + b[8].y) / 2 };
        const d = dist(ca, cb), ang = Math.atan2(cb.y - ca.y, cb.x - ca.x), mid = { x: (ca.x + cb.x) / 2, y: (ca.y + cb.y) / 2 };
        if (bothPinch && d > cfg.twoHandMinDist) {
          if (S.pinched || S.dragging) releaseAll(ev, 'twoHand');
          if (!S.twoHand) {
            S.twoHand = { d0: d, a0: ang, prevD: d, prevA: ang, prevMid: mid, t0: t };
            ev.push({ type: 'twoHandStart', x: mid.x, y: mid.y });
          } else {
            let dA = ang - S.twoHand.prevA; while (dA > Math.PI) dA -= 2 * Math.PI; while (dA < -Math.PI) dA += 2 * Math.PI;
            ev.push({ type: 'twoHand', scale: d / S.twoHand.d0, scaleStep: d / S.twoHand.prevD, rotateStep: dA,
              dx: mid.x - S.twoHand.prevMid.x, dy: mid.y - S.twoHand.prevMid.y, x: mid.x, y: mid.y });
            S.twoHand.prevD = d; S.twoHand.prevA = ang; S.twoHand.prevMid = mid;
          }
          return ev;
        }
        if (S.twoHand) { ev.push({ type: 'twoHandEnd', reason: 'release' }); S.twoHand = null; }
      } else if (S.twoHand) { ev.push({ type: 'twoHandEnd', reason: 'second hand lost' }); S.twoHand = null; }

      /* ---- single (primary) hand ---- */
      const l = hands[0].landmarks, p = pose(l);
      const px = filt.x.step(l[8].x, t), py = filt.y.step(l[8].y, t);
      const cur = reach({ x: px, y: py });
      S.cursor = cur;
      ev.push({ type: 'move', x: cur.x, y: cur.y, pinch: p.pinch, pose: p.open ? 'open' : p.peace ? 'peace' : p.fist ? 'fist' : 'other' });

      // pinch state with hysteresis + frame debounce
      const wantPinch = S.pinched ? p.pinch < cfg.pinchOff : p.pinch < cfg.pinchOn;
      if (wantPinch !== S.pinched) {
        S.pinchCount++;
        if (S.pinchCount >= cfg.pinchFrames) {
          S.pinchCount = 0;
          if (wantPinch) {
            S.pinched = true; S.pinchStart = { x: cur.x, y: cur.y, t };
            ev.push({ type: 'pinchStart', x: cur.x, y: cur.y });
          } else {
            if (S.dragging) ev.push({ type: 'dragEnd', x: cur.x, y: cur.y, reason: 'release' });
            else ev.push({ type: 'click', x: S.pinchStart.x, y: S.pinchStart.y });
            S.pinched = false; S.dragging = false; S.pinchStart = null;
          }
        }
      } else S.pinchCount = 0;
      if (S.pinched) {
        const moved = Math.hypot(cur.x - S.pinchStart.x, cur.y - S.pinchStart.y);
        if (!S.dragging && moved > cfg.dragThreshold) {
          S.dragging = true; ev.push({ type: 'dragStart', x: S.pinchStart.x, y: S.pinchStart.y });
        }
        if (S.dragging) ev.push({ type: 'drag', x: cur.x, y: cur.y, dx: cur.x - S.pinchStart.x, dy: cur.y - S.pinchStart.y });
        S.palmSince = 0; S.swipeTrail = []; S.scrolling && (S.scrolling = false, ev.push({ type: 'scrollEnd' }));
        return ev;
      }

      // scroll: two fingers up (peace pose), vertical movement only
      if (p.peace) {
        const y = (l[8].y + l[12].y) / 2;
        if (!S.scrolling) { S.scrolling = true; S.scrollPrev = y; ev.push({ type: 'scrollStart' }); }
        else {
          const dy = (y - S.scrollPrev) * cfg.scrollGain * cfg.sensitivity; S.scrollPrev = y;
          if (Math.abs(dy) > 0.002) ev.push({ type: 'scroll', dy });
        }
        S.palmSince = 0; S.swipeTrail = [];
        return ev;
      } else if (S.scrolling) { S.scrolling = false; ev.push({ type: 'scrollEnd' }); }

      // open palm: swipe + hold
      if (p.open) {
        if (!S.palmSince) S.palmSince = t;
        const c = l[9];
        S.swipeTrail.push({ x: c.x, y: c.y, t });
        while (S.swipeTrail.length && t - S.swipeTrail[0].t > cfg.swipeWindowMs) S.swipeTrail.shift();
        const first = S.swipeTrail[0], dx = c.x - first.x, dy = c.y - first.y;
        const speed = Math.hypot(dx, dy) / Math.max((t - first.t) / 1000, 0.05);
        if (speed < 0.35) { if (!S.restSince) S.restSince = t; if (t - S.restSince > cfg.swipeRestMs) S.swipeArmed = true; }
        else S.restSince = 0;
        if (S.swipeArmed && t >= S.swipeCooldownUntil && Math.abs(dx) > cfg.swipeDistance / cfg.sensitivity &&
            Math.abs(dy) < Math.abs(dx) * 0.6 && S.swipeTrail.length >= 3) {
          ev.push({ type: 'swipe', direction: dx > 0 ? 'right' : 'left', distance: Math.abs(dx) });
          S.swipeCooldownUntil = t + cfg.swipeCooldownMs; S.swipeArmed = false; S.swipeTrail = []; S.palmSince = t;
        } else if (S.palmArmed && speed < 0.2 && t - S.palmSince >= cfg.palmHoldMs && t >= S.palmCooldownUntil) {
          ev.push({ type: 'palmHold' }); // fires once per hold; the palm must be lowered/changed before it can fire again
          S.palmCooldownUntil = t + cfg.palmCooldownMs; S.palmSince = 0; S.palmArmed = false;
        }
        if (speed >= 0.2) S.palmSince = t; // moving: restart the hold timer
      } else { S.palmSince = 0; S.swipeTrail = []; S.restSince = 0; S.palmArmed = true; }
      return ev;
    }

    return {
      update,
      reset() { const e = []; releaseAll(e); S.tracking = false; S.lost = false; return e; },
      setConfig(c) { cfg = Object.assign(cfg, c); mkFilters(); },
      getConfig() { return Object.assign({}, cfg); },
      state() { return { pinched: S.pinched, dragging: S.dragging, twoHand: !!S.twoHand, tracking: S.tracking, scrolling: S.scrolling, cursor: S.cursor }; }
    };
  }

  const API = { createEngine, DEFAULTS, pose, oneEuro };
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
  root.JarvisGestures = API;
})(typeof window === 'undefined' ? globalThis : window);
