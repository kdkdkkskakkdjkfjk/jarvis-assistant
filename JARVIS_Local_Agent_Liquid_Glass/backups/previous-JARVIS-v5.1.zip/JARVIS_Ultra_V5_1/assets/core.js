/* Shared transport, safe DOM helpers and contextual intent routing. */
((root) => {
  'use strict';
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => `&#${c.charCodeAt(0)};`);
  const url = s => { try { const u = new URL(s); return /^https?:$/.test(u.protocol) && !u.username && !u.password ? u.href : ''; } catch { return ''; } };
  const intent = (raw, home='Wien', lastPlace='') => {
    const t=String(raw||'').trim(), lo=t.toLocaleLowerCase('de');
    let m;
    if (/^(?:rechne|berechne|was (?:ist|sind|ergibt)|wie viel ist)?\s*[\d(][\d\s.,+*/()^×÷−-]*(?:\s*(?:plus|minus|mal|geteilt durch)\s*[\d().,]+)*[?=]*$/i.test(t)) return {type:'math', query:t};
    if (/\b(?:hand(?:steuerung|tracking|erkennung)|gestensteuerung)\b/i.test(t)) {
      if (/\b(?:aus\w*|deaktivier\w*|stopp\w*|beend\w*|abschalt\w*)\b/i.test(t)) return {type:'hands',action:'off'};
      if (/\b(?:ein\w*|an\w*|aktivier\w*|start\w*)\b/i.test(t)) return {type:'hands',action:'on'};
    }
    if (/\b(?:hologramm|3d[- ]?modell|3d[- ]?objekt)\b/i.test(t)) {
      if (/\b(?:globus|globe|welt)\b/i.test(t)) return {type:'holoModel',model:'globe'};
      if (/\b(?:gitter|würfel|wuerfel|cube)\b/i.test(t)) return {type:'holoModel',model:'cube'};
      if (/\b(?:kern|core)\b/i.test(t)) return {type:'holoModel',model:'core'};
      if (/\b(?:zurück\w*|zurueck\w*|reset)\b/i.test(t)) return {type:'holoControl',action:'reset'};
      if (/\b(?:größer\w*|groesser\w*|vergrößer\w*|vergroesser\w*|zoom\s*rein)\b/i.test(t)) return {type:'holoControl',action:'in'};
      if (/\b(?:kleiner\w*|verkleiner\w*|zoom\s*raus)\b/i.test(t)) return {type:'holoControl',action:'out'};
      if (/\b(?:automatische\s+drehung|auto\s*drehung)\b/i.test(t)) return {type:'holoControl',action:/\b(?:aus|stop|stopp|beenden)\b/i.test(t)?'autoOff':'autoOn'};
    }
    if (/^(?:zeig(?:e)?|öffne|oeffne|starte)\s+(?:mir\s+)?(?:das\s+|den\s+)?(?:hologramm|3d[- ]?labor|holo[- ]?labor)\b/i.test(t)) return {type:'view',view:'holo'};
    if (/^(?:(?:zeig(?:e)?|öffne|oeffne)\s+(?:mir\s+)?(?:den\s+|das\s+)?)?(?:kontrollraum|startseite|home)[?!.]*$/i.test(t)) return {type:'view',view:'home'};
    if (/^(?:nächste[sn]?|naechste[sn]?|weiter(?:e[sn]?)?)\s+(?:panel|seite|ansicht)\b/i.test(t)) return {type:'navigate',dir:1};
    if (/^(?:vorherige[sn]?|zurück(?:e[sn]?)?)\s+(?:panel|seite|ansicht)\b/i.test(t)) return {type:'navigate',dir:-1};
    if (/\b(wetter|temperatur|regenwahrscheinlichkeit|regnet|sonnig|bewölkt)\b/i.test(t)) {
      m=t.match(/\b(?:in|für|von|bei)\s+(.+?)(?:\s+(?:morgen|heute|übermorgen|am wochenende))?[?!.]*$/i);
      return {type:'weather', place:m?.[1]?.replace(/\b(?:morgen|heute|übermorgen)\b/gi,'').trim() || (/dort|da\b/i.test(t) && lastPlace ? lastPlace : home), day:/übermorgen/i.test(t)?2:/morgen/i.test(t)?1:0};
    }
    if (/\b(nachrichten|schlagzeilen|news)\b/i.test(t)) {
      const q=t.replace(/^(?:zeig(?:e)?\s+(?:mir\s+)?|suche\s+)?(?:aktuelle[n]?\s+)?(?:nachrichten|schlagzeilen|news)(?:\s+(?:zu|über|aus|von))?\s*:?\s*/i,'').replace(/[?!.]+$/,'');
      return {type:'news',query:q||'Österreich'};
    }
    if (/^(?:suche|such|finde|zeige|zeig)\s+(?:mir\s+)?(?:bilder|fotos)\s*(?:von|zu|über|:)?\s+/i.test(t)) return {type:'images',query:t.replace(/^(?:suche|such|finde|zeige|zeig)\s+(?:mir\s+)?(?:bilder|fotos)\s*(?:von|zu|über|:)?\s+/i,'')};
    if (/^(?:suche|such)\s+(?:im\s+)?(?:web|internet)\s*:?\s*/i.test(t)) return {type:'search',query:t.replace(/^(?:suche|such)\s+(?:im\s+)?(?:web|internet)\s*:?\s*/i,'')};
    if (/\b(?:cpu|ram|gpu|systemstatus|hardwareauslastung|pc-status|speicherauslastung)\b/i.test(t)) return {type:'system'};
    if (/smart\s*home|home assistant|^(?:schalte|dimme|stelle.*heizung|setze.*heizung)/i.test(t)) return {type:'home',query:t};
    if (/^(?:zeig(?:e)?|öffne)\s+(?:mir\s+)?(?:meinen?\s+|den\s+)?kalender/i.test(t)) return {type:'calendar'};
    if ((m=t.match(/^(?:finde|suche|such|zeige|zeig)\s+(?:mir\s+)?(.+?)\s+(?:in|bei)\s+(.+?)[?!.]*$/i)) && !/^(?:meiner|der) nähe/i.test(m[2]) && /geschäft|restaurant|café|cafe|apotheke|lidl|hofer|billa|spar|aldi|rewe|sehenswürdigkeit|supermarkt|tankstelle/i.test(m[1])) return {type:'places',query:m[1].replace(/^(?:einen?|die|alle)\s+/i,''),place:m[2]};
    if (/\b(?:in (?:meiner|der) nähe|meiner umgebung)\b/i.test(t)) return {type:'nearby',query:t.replace(/^(?:finde|suche|such|zeige|zeig)\s+(?:mir\s+)?(?:einen?\s+)?/i,'').replace(/\s+(?:in (?:meiner|der) nähe|in meiner umgebung).*/i,'')};
    if ((m=t.match(/^(?:zeig(?:e)?|öffne|oeffne)\s+(?:mir\s+)?(?:die\s+)?(?:3d[- ]?(?:welt|karte|ansicht|globus)|globus|erde|google earth)(?:\s+(?:von|in|über)\s+(.+?))?[?!.]*$/i))) return {type:'place',place:m[1]||home};
    if ((m=t.match(/^(?:zeig(?:e)?\s+(?:mir\s+)?|karte\s+(?:von|öffnen:)\s*|fliege\s+(?:nach|zu)\s+)(.+?)[?!.]*$/i)) && !/^(?:ein(?:e[rmns]?)?|das|den|die|wie|was|warum)\b/i.test(m[1]) && !/\b(?:diagramm|mathe|rechnung|foto|bild|nachricht|aktie|protein|atom|planet|galaxy|iphone|samsung)\b/i.test(m[1])) return {type:'place',place:m[1]};
    return {type:'text',query:t,search:/\b(aktuell|heute|jetzt|neueste|live|spielstand|aktienkurs|verkehr|störung)\b/i.test(lo)};
  };
  const state={config:null,csrf:'',pending:new Map()};
  async function api(path, options={}) {
    const c=new AbortController(), t=setTimeout(()=>c.abort(),options.timeout||55000);
    const outer=options.signal;
    const abort=()=>c.abort();
    if(outer?.aborted)c.abort(); else outer?.addEventListener('abort',abort,{once:true});
    try {
      if(options.body && !state.csrf) await ready;
      const r=await fetch('/api/'+path,{method:options.body?'POST':'GET',headers:options.body?{'Content-Type':'application/json','X-Jarvis-Token':state.csrf}:{},body:options.body?JSON.stringify(options.body):undefined,signal:c.signal});
      const data=await r.json();
      if(!r.ok||data.error)throw Object.assign(new Error(data.error?.message||`HTTP ${r.status}`),{code:data.error?.code,status:r.status});
      return data;
    } catch(e) { if(e.name==='AbortError')throw Object.assign(new Error(outer?.aborted?'Anfrage abgebrochen.':'Der Dienst hat das Zeitlimit überschritten.'),{name:'AbortError'}); throw e; }
    finally{clearTimeout(t);outer?.removeEventListener('abort',abort);}
  }
  const ready = typeof window==='undefined' ? Promise.resolve() : api('bootstrap',{timeout:5000}).then(c=>{state.config=c;state.csrf=c.csrf;return c;});
  ready.catch(()=>{});
  const fmtTime=t=>{const d=new Date(t);return Number.isFinite(+d)?d.toLocaleString('de-AT',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'}):'Zeitpunkt unbekannt';};
  const attribution=d=>`${d.source||'Datenquelle'} · ${d.stale?'Zwischenspeicher, veraltet · ':''}Abruf ${fmtTime(d.fetched_at)}`;
  const U={esc,url,intent,state,api,ready,fmtTime,attribution};
  if(typeof module!=='undefined'&&module.exports)module.exports=U;
  root.JarvisCore=U;
})(typeof window==='undefined'?globalThis:window);
