/* 26 real component families × 4 feedback states = 104 registered states.
 * Four reusable motion primitives, not 104 simultaneous effects.
 * Lifecycle: IntersectionObserver for entry, delegated input, no render loop.
 */
(() => {
 'use strict';
 const families={
  navigation:'.rail-btn', overview:'.u-overview-card', message:'.u-message',
  suggestion:'[data-ask]', worldRegion:'.world-region button', worldSearch:'#worldSearchForm button',
  worldLayer:'[data-world-layer]', worldCamera:'.world-camera button', worldResult:'.world-result',
  worldInspector:'.world-inspector', worldNearby:'[data-nearby]', worldQuality:'#worldQuality',
  weatherHour:'.u-hour', weatherDay:'.u-daily-row', weatherMetric:'.u-weather-metric',
  newsFilter:'.u-news-filter', newsCard:'.u-news-card', imageCard:'.u-gallery figure',
  deviceCard:'.u-device-card', systemCard:'.u-system-card', toolCard:'.feature-card',
  scheduleCard:'.schedule-art-card', connectionCard:'.connection-card', cameraCard:'.camera-panel',
  settingField:'#dlg label', contextPanel:'.ultra-context'
 };
 const states=['enter','hover','press','focus'],registry=Object.entries(families).flatMap(([family,selector])=>states.map(state=>({id:family+'.'+state,family,selector,state,purpose:{enter:'Neu sichtbaren Inhalt einordnen',hover:'Zeigerziel hervorheben',press:'Betätigung bestätigen',focus:'Tastaturziel sichtbar machen'}[state]})));
 const animations=new WeakMap(),seen=new WeakSet(),reduced=()=>matchMedia('(prefers-reduced-motion: reduce)').matches||document.body.dataset.motion==='reduced';
 const selector=Object.values(families).join(',');
 function animate(el,state){if(!el||reduced()||document.hidden)return;animations.get(el)?.cancel();let frames;
  if(state==='enter')frames=[{opacity:0,translate:'0 8px'},{opacity:1,translate:'0 0'}];
  if(state==='hover')frames=[{filter:'brightness(1)'},{filter:'brightness(1.13)'},{filter:'brightness(1)'}];
  if(state==='press')frames=[{scale:'1'},{scale:'.98'},{scale:'1'}];
  if(state==='focus')frames=[{outlineColor:'#83e8d200',outlineOffset:'0px'},{outlineColor:'#83e8d2',outlineOffset:'3px'}];
  const a=el.animate(frames,{duration:state==='enter'?320:220,easing:'cubic-bezier(.2,.75,.25,1)'});animations.set(el,a);a.onfinish=()=>animations.delete(el);
 }
 const io=new IntersectionObserver(entries=>entries.forEach(x=>{if(x.isIntersecting){animate(x.target,'enter');io.unobserve(x.target);}}),{threshold:.08});
 const attach=node=>{if(node.nodeType!==1)return;const all=[...(node.matches(selector)?[node]:[]),...node.querySelectorAll(selector)];for(const el of all){if(seen.has(el))continue;seen.add(el);io.observe(el);}};
 attach(document.body);
 const mo=new MutationObserver(records=>{for(const r of records){r.addedNodes.forEach(attach);r.removedNodes.forEach(n=>{if(n.nodeType!==1)return;io.unobserve(n);n.querySelectorAll(selector).forEach(x=>io.unobserve(x));});}});mo.observe(document.body,{childList:true,subtree:true});
 document.addEventListener('pointerover',ev=>{const el=ev.target.closest(selector);if(el&&!el.contains(ev.relatedTarget))animate(el,'hover');},{passive:true});
 document.addEventListener('pointerdown',ev=>animate(ev.target.closest(selector),'press'),{passive:true});
 document.addEventListener('focusin',ev=>animate(ev.target.closest(selector),'focus'));
 window.addEventListener('pagehide',()=>{mo.disconnect();io.disconnect();},{once:true});
 window.JarvisMotion={registry,states:registry.length,families};
})();
