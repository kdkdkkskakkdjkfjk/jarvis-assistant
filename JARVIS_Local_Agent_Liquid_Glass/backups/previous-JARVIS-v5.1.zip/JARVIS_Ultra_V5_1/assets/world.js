/* Geographic 3D scene, bounded on-demand OSM tiles and optional ion streaming. */
(() => {
  'use strict';
  const U=JarvisCore, q=s=>document.querySelector(s);
  let C,V,loading,searchSeq=0,tileEpoch=0,visible=false,ionBuildings=false,hasTerrain=false,photoTiles=false;
  let detailSource='OSM · Gebäudeextrusion';
  let layers={buildings:true,roads:true,places:true,land:true},imagery='satellite',current={name:'Wien · Stephansplatz',latitude:48.20849,longitude:16.37315};
  const tileCache=new Map(),objects=new Map(),failed=new Map();
  let streaming=false,queued=false,orbitTimer=0,abortController=null,loadedTileset=null,selected=null;
  const status=(text,error=false)=>{q('#worldStatus').textContent=text;q('#worldStatus').classList.toggle('error',error);};
  const reduced=()=>matchMedia('(prefers-reduced-motion: reduce)').matches||document.body.dataset.motion==='reduced';
  function stats(){q('#worldBuildings').textContent=ionBuildings?'3D Tiles':String([...objects.values()].filter(x=>x.kind==='building').length);q('#worldTiles').textContent=String(tileCache.size);q('#worldData').textContent=photoTiles?'3D-Tiles-Modell':ionBuildings?'OSM 3D Tiles':detailSource;q('#worldTerrain').textContent=hasTerrain?'Gelände aktiv':'Gelände: Ellipsoid';}
  function error(message){status(message,true);q('#worldError').textContent=message;q('#worldError').hidden=false;}
  async function lib(){
    if(window.Cesium){C=window.Cesium;return;}
    if(!loading)loading=new Promise((resolve,reject)=>{window.CESIUM_BASE_URL='assets/vendor/cesium/';const s=document.createElement('script');s.src=CESIUM_BASE_URL+'Cesium.js';s.onload=()=>{C=window.Cesium;resolve();};s.onerror=()=>{loading=null;s.remove();reject(new Error('3D-Engine fehlt. ZIP vollständig entpacken und über Start-Jarvis.bat starten.'));};document.head.append(s);});
    return loading;
  }
  async function setImagery(){
    if(!V)return;
    V.imageryLayers.removeAll();
    const p=imagery==='satellite'?new C.UrlTemplateImageryProvider({url:'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',maximumLevel:19,credit:'Imagery © Esri, Maxar, Earthstar Geographics, GIS User Community'}):new C.UrlTemplateImageryProvider({url:'https://tile.openstreetmap.org/{z}/{x}/{y}.png',maximumLevel:19,credit:'© OpenStreetMap contributors · ODbL'});
    let reported=false;p.errorEvent.addEventListener(()=>{if(!reported){reported=true;error('Bildkacheln nicht erreichbar. Kartentyp wechseln oder Verbindung prüfen. Gebäude laden unabhängig davon.');}});
    V.imageryLayers.addImageryProvider(p);V.scene.requestRender();
    q('#worldImagery').textContent=imagery==='satellite'?'Satellit':'Straßenkarte';
  }
  async function init(){
    await lib();if(V)return;
    C.Ion.defaultAccessToken='';
    V=new C.Viewer('worldCanvas',{baseLayer:false,baseLayerPicker:false,geocoder:false,homeButton:false,sceneModePicker:false,navigationHelpButton:false,animation:false,timeline:false,fullscreenButton:false,infoBox:false,selectionIndicator:false,requestRenderMode:true,maximumRenderTimeChange:Infinity,shadows:false,shouldAnimate:false});
    V.resolutionScale=Math.min(1,1.5/(window.devicePixelRatio||1));V.scene.globe.enableLighting=false;
    V.scene.globe.depthTestAgainstTerrain=true;V.scene.screenSpaceCameraController.minimumZoomDistance=35;V.scene.screenSpaceCameraController.maximumZoomDistance=25000000;
    V.scene.highDynamicRange=false;V.scene.postProcessStages.fxaa.enabled=true;
    V.scene.globe.tileCacheSize=80;V.scene.globe.maximumScreenSpaceError=3;
    await setImagery();
    V.screenSpaceEventHandler.removeInputAction(C.ScreenSpaceEventType.LEFT_DOUBLE_CLICK);
    V.screenSpaceEventHandler.setInputAction(e=>{
      const p=V.scene.pick(e.position);
      if(p?.id?._jarvis){inspect(p.id._jarvis);return;}
      if(p?.getPropertyIds){const tags={};p.getPropertyIds().forEach(k=>{tags[k]=p.getProperty(k);});const position=V.scene.pickPositionSupported?V.scene.pickPosition(e.position):null;const c=position?C.Cartographic.fromCartesian(position):null;inspect({properties:{name:tags.name||tags['name:en']||'3D-Gebäude',tags,kind:'building',source:'Cesium ion / Datenanbieter'},geometry:{type:'Point',coordinates:c?[C.Math.toDegrees(c.longitude),C.Math.toDegrees(c.latitude)]:[current.longitude,current.latitude]}});}
    },C.ScreenSpaceEventType.LEFT_CLICK);
    V.camera.moveEnd.addEventListener(()=>{if(visible){tileEpoch++;stream();updateCamera();}});
    V.scene.renderError.addEventListener((scene,e)=>error('WebGL-Fehler: '+(e?.message||'Grafiktreiber prüfen.')));
    const cfg=await U.ready.catch(()=>null);
    if(cfg?.cesium_token){
      C.Ion.defaultAccessToken=cfg.cesium_token;
      status('Lade Gelände und 3D-Tiles …');
      const work=await Promise.allSettled([
        C.createWorldTerrainAsync({requestVertexNormals:true,requestWaterMask:true}).then(t=>{V.terrainProvider=t;hasTerrain=true;}),
        (cfg.tiles_asset_id?C.Cesium3DTileset.fromIonAssetId(Number(cfg.tiles_asset_id),{maximumScreenSpaceError:8,cacheBytes:128*1024*1024,maximumCacheOverflowBytes:32*1024*1024}):C.createOsmBuildingsAsync({maximumScreenSpaceError:12,enableShowOutline:false})).then(t=>{loadedTileset=V.scene.primitives.add(t);ionBuildings=true;photoTiles=!!cfg.tiles_asset_id;})
      ]);
      const errors=work.filter(x=>x.status==='rejected');
      if(errors.length)error('Ein Cesium-Datendienst ist nicht verfügbar. Token, Asset-Freigabe und Netzwerk prüfen. Verfügbare Daten bleiben sichtbar.');
    }
    stats();
  }
  function updateCamera(){if(!V)return;const h=V.camera.positionCartographic.height;q('#worldAltitude').textContent=h>10000?`${(h/1000).toFixed(1)} km`:`${Math.round(h)} m`;}
  function viewCenter(){
    const canvas=V.scene.canvas,ray=V.camera.getPickRay(new C.Cartesian2(canvas.clientWidth/2,canvas.clientHeight/2));
    const pos=ray&&V.scene.globe.pick(ray,V.scene)||V.camera.pickEllipsoid(new C.Cartesian2(canvas.clientWidth/2,canvas.clientHeight/2));
    return pos?C.Cartographic.fromCartesian(pos):null;
  }
  function xy(lat,lon){const n=65536;return [(lon+180)/360*n,(1-Math.asinh(Math.tan(lat*Math.PI/180))/Math.PI)/2*n];}
  function tileKeys(center){
    const [fx,fy]=xy(C.Math.toDegrees(center.latitude),C.Math.toDegrees(center.longitude));const x=Math.floor(fx),y=Math.floor(fy);
    const dx=fx-x>.5?1:-1,dy=fy-y>.5?1:-1;
    return [[x,y],[x+dx,y],[x,y+dy],[x+dx,y+dy]].filter(([a,b])=>a>=0&&a<65536&&b>=0&&b<65536).map(([a,b])=>`${a}/${b}`);
  }
  function polygonHierarchy(rings){return new C.PolygonHierarchy(C.Cartesian3.fromDegreesArray(rings[0].flat()),rings.slice(1).map(r=>new C.PolygonHierarchy(C.Cartesian3.fromDegreesArray(r.flat()))));}
  function colour(t, fallback){try{return C.Color.fromCssColorString(t)||C.Color.fromCssColorString(fallback);}catch{return C.Color.fromCssColorString(fallback);}}
  function addFeature(f,key){
    const p=f.properties||{},kind=p.kind;
    if((kind==='building'&&ionBuildings)||!f.geometry)return;
    if(objects.has(f.id)){objects.get(f.id).tiles.add(key);return;}
    const entities=[],tags=p.tags||{},geo=f.geometry;
    if(geo.type==='MultiPolygon'){
      geo.coordinates.forEach((rings,i)=>{
        if(!rings[0]?.length)return;
        const isBuilding=kind==='building',col=colour(tags['building:colour']||tags['colour'],isBuilding?'#c5b69c':kind==='water'?'#156876':'#41594a');
        const e=V.entities.add({id:`osm:${f.id}:${i}`,name:p.name||'Gebäude',polygon:{hierarchy:polygonHierarchy(rings),height:isBuilding?p.min_height:0,extrudedHeight:isBuilding?p.height:undefined,material:col,outline:false,heightReference:hasTerrain?C.HeightReference.RELATIVE_TO_GROUND:C.HeightReference.NONE,extrudedHeightReference:hasTerrain?C.HeightReference.RELATIVE_TO_GROUND:C.HeightReference.NONE,shadows:C.ShadowMode.ENABLED}});
        e._jarvis=f;e.show=layers[isBuilding?'buildings':'land'];entities.push(e);
        if(isBuilding){const roof=V.entities.add({id:`roof:${f.id}:${i}`,polygon:{hierarchy:polygonHierarchy(rings),height:p.height+.02,heightReference:hasTerrain?C.HeightReference.RELATIVE_TO_GROUND:C.HeightReference.NONE,material:colour(tags['roof:colour'],'#80786c'),outline:false,shadows:C.ShadowMode.ENABLED}});roof._jarvis=f;roof.show=layers.buildings;entities.push(roof);}
      });
    }else if(geo.type==='LineString'&&kind==='road'){
      const major=/^(motorway|trunk|primary|secondary)$/.test(tags.highway||'');
      const e=V.entities.add({id:`osm:${f.id}`,polyline:{positions:C.Cartesian3.fromDegreesArray(geo.coordinates.flat()),width:major?3:1.5,clampToGround:true,material:colour(major?'#e2bd75':'#91b7c0','#91b7c0')}});e._jarvis=f;e.show=layers.roads;entities.push(e);
    }else if(geo.type==='Point'){
      const e=V.entities.add({id:`osm:${f.id}`,name:p.name,position:C.Cartesian3.fromDegrees(...geo.coordinates,2),point:{pixelSize:7,color:C.Color.fromCssColorString('#7ce5cf'),outlineColor:C.Color.fromCssColorString('#092330'),outlineWidth:2,heightReference:C.HeightReference.CLAMP_TO_GROUND,disableDepthTestDistance:7000},label:{text:p.name||'',font:'12px sans-serif',showBackground:true,backgroundColor:C.Color.fromCssColorString('#0c2029').withAlpha(.85),pixelOffset:new C.Cartesian2(0,-17),heightReference:C.HeightReference.CLAMP_TO_GROUND,distanceDisplayCondition:new C.DistanceDisplayCondition(0,1200),disableDepthTestDistance:1200,scale:.9}});e._jarvis=f;e.show=layers.places;entities.push(e);
    }
    if(entities.length)objects.set(f.id,{entities,kind,tiles:new Set([key])});
  }
  function evict(key){const tile=tileCache.get(key);if(!tile)return;tile.ids.forEach(id=>{const obj=objects.get(id);if(!obj)return;obj.tiles.delete(key);if(!obj.tiles.size){obj.entities.forEach(e=>V.entities.remove(e));objects.delete(id);}});tileCache.delete(key);}
  async function stream(){
    if(!V||!visible)return;
    if(streaming){queued=true;return;}
    if(V.camera.positionCartographic.height>8500){status('Regionansicht · Detaildaten laden beim Heranzoomen');return;}
    const center=viewCenter();if(!center)return;
    const keys=tileKeys(center),epoch=tileEpoch;streaming=true;queued=false;let count=0,errors=0;
    try{
      for(const key of keys){
        if(!visible||epoch!==tileEpoch)break;
        if(tileCache.has(key)){const t=tileCache.get(key);tileCache.delete(key);tileCache.set(key,t);count++;continue;}
        if(Date.now()-(failed.get(key)||0)<60000){errors++;continue;}
        status(`Lade geografische Details ${count+1}/${keys.length} …`);q('#worldProgress').style.width=`${count/keys.length*100}%`;
        abortController=new AbortController();
        try{
          const [x,y]=key.split('/'),d=await U.api(`world/tile?x=${x}&y=${y}`,{signal:abortController.signal});
          if(!visible||epoch!==tileEpoch)break;
          V.entities.suspendEvents();try{d.features.forEach(f=>addFeature(f,key));}finally{V.entities.resumeEvents();}
          tileCache.set(key,{ids:d.features.map(f=>f.id),fetched:d.fetched_at});
          while(tileCache.size>12||objects.size>6500){const first=[...tileCache.keys()].find(k=>!keys.includes(k));if(!first)break;evict(first);}
          detailSource=d.detail||detailSource;q('#worldSource').textContent=U.attribution(d)+' · '+(d.license||'')+(d.note?' · '+d.note:'')+(d.osm_timestamp?' · OSM-Stand '+U.fmtTime(d.osm_timestamp):'');
          count++;stats();V.scene.requestRender();
        }catch(e){if(e.name==='AbortError')break;failed.set(key,Date.now());errors++;error(e.message+' · Erneut laden ist möglich.');}
      }
      if(epoch===tileEpoch&&visible){q('#worldProgress').style.width='100%';if(!errors)status(`${objects.size} Kartenobjekte · ${tileCache.size} Kacheln im Speicher`);}
    }finally{streaming=false;abortController=null;if(queued&&visible){queued=false;setTimeout(stream,120);}}
  }
  async function fly(p,range=1800){
    await init();current=p;
    q('#worldLocation').textContent=p.name||p.label||'Ausgewählter Ort';q('#worldCoordinates').textContent=`${p.latitude.toFixed(5)}° N / ${p.longitude.toFixed(5)}° E`;
    const target=C.Cartesian3.fromDegrees(p.longitude,p.latitude);
    V.camera.flyToBoundingSphere(new C.BoundingSphere(target,100),{duration:reduced()?0:1.7,offset:new C.HeadingPitchRange(C.Math.toRadians(18),C.Math.toRadians(-43),range),complete:()=>{updateCamera();stream();}});
    V.scene.requestRender();window.dispatchEvent(new CustomEvent('jarvis-place',{detail:p}));
    if(reduced()){updateCamera();stream();}
  }
  async function open(place){
    visible=true;
    try{await init();V.useDefaultRenderLoop=true;V.resize();if(place)await search(place);else if(!tileCache.size)await fly(current);else{V.scene.requestRender();stream();}}
    catch(e){error(e.message);}
  }
  async function search(term){
    const seq=++searchSeq;status('Suche '+term+' …');q('#worldError').hidden=true;
    const results=await U.api('geocode?q='+encodeURIComponent(term));
    if(seq!==searchSeq)return null;
    if(!results.results.length)throw new Error('Kein Ort gefunden. Bitte Name, Straße und Stadt genauer angeben.');
    const p=results.results[0];
    q('#worldMatches').innerHTML=results.results.slice(0,4).map((r,i)=>`<button class="world-result" data-place-choice="${i}"><strong>${U.esc(r.name)}</strong><small>${U.esc(r.label)}</small></button>`).join('');
    q('#worldMatches').hidden=results.results.length<2;
    q('#worldMatches').querySelectorAll('button').forEach((b,i)=>b.onclick=()=>{fly(results.results[i]);q('#worldMatches').hidden=true;});
    const broad=/^(österreich|austria|europa|europe|deutschland|italien|frankreich)$/i.test(term.trim());
    await fly(p,broad?(/europ/i.test(term)?4200000:650000):1800);return p;
  }
  function centerOf(f){const g=f.geometry;if(g.type==='Point')return g.coordinates;const ring=g.type==='MultiPolygon'?g.coordinates[0][0]:g.coordinates;return [ring.reduce((s,p)=>s+p[0],0)/ring.length,ring.reduce((s,p)=>s+p[1],0)/ring.length];}
  function inspect(f){
    selected=f;const p=f.properties||{},t=p.tags||{},[lon,lat]=centerOf(f),website=U.url(t.website||t['contact:website']),source=U.url(p.source_url),kind=p.kind==='building'?'Gebäude':t.shop?'Geschäft':t.amenity||'Kartenobjekt';
    const fields=[['Kategorie',t.building||t.shop||t.amenity||kind],['Adresse',[t['addr:street'],t['addr:housenumber'],t['addr:postcode'],t['addr:city']].filter(Boolean).join(' ')],['Höhe',p.height?`${p.height.toFixed(1)} m · ${p.height_source}`:''],['Öffnungszeiten',t.opening_hours],['Telefon',t.phone||t['contact:phone']],['Innenräume',t.indoor||'Keine verifizierten Grundrisse geladen']].filter(x=>x[1]);
    q('#worldInspector').innerHTML=`<div class="u-kicker">${U.esc(kind)} <button id="worldInspectorClose" aria-label="Objektdetails schließen">×</button></div><h2>${U.esc(p.name||t.name||'Unbenanntes Gebäude')}</h2><dl>${fields.map(([k,v])=>`<div><dt>${U.esc(k)}</dt><dd>${U.esc(v)}</dd></div>`).join('')}</dl><div class="u-linkrow">${website?`<a href="${U.esc(website)}" target="_blank" rel="noopener noreferrer">Website ↗</a>`:''}<a href="https://www.google.com/maps/dir/?api=1&destination=${lat},${lon}" target="_blank" rel="noopener noreferrer">Route ↗</a>${source?`<a href="${U.esc(source)}" target="_blank" rel="noopener noreferrer">Datenquelle ↗</a>`:''}</div><p class="u-note">${lat.toFixed(6)}, ${lon.toFixed(6)} · ${U.esc(p.source||'OpenStreetMap')}<br>Öffnungszeiten sind Karteneinträge; keine Live-Bestätigung. Bewertungen sind nicht angebunden.</p>`;
    q('#worldInspector').hidden=false;q('#worldInspectorClose').onclick=()=>q('#worldInspector').hidden=true;
    const pic=U.url(t.image);if(pic){const a=document.createElement('a');a.href=pic;a.target='_blank';a.rel='noopener noreferrer';a.textContent='Verlinktes Bild aus dem Karteneintrag ↗';q('#worldInspector').append(a);}
  }
  async function findPlaces(term,place,coords){
    await open();let p=coords||current;if(place)p=await search(place);if(!p)return;
    status('Suche reale Orte: '+term+' …');
    const d=await U.api(`places?q=${encodeURIComponent(term)}&lat=${p.latitude}&lon=${p.longitude}`);
    q('#worldMatches').hidden=false;
    q('#worldMatches').innerHTML=`<p class="u-note">${d.features.length} Treffer im Umkreis von ${d.radius_m} m · ${U.esc(U.attribution(d))}</p>`+(d.features.length?d.features.map((f,i)=>`<button class="world-result" data-poi-index="${i}"><strong>${U.esc(f.properties.name)}</strong><small>${U.esc(f.properties.tags['addr:street']||f.properties.tags.shop||f.properties.tags.amenity||'Karteneintrag')}</small></button>`).join(''):'<p>Keine passenden kartierten Orte gefunden. Suche mit genauerem Namen oder an einem anderen Standort.</p>');
    if(tileCache.has('search'))evict('search');d.features.forEach(f=>addFeature(f,'search'));tileCache.set('search',{ids:d.features.map(f=>f.id)});
    q('#worldMatches').querySelectorAll('[data-poi-index]').forEach(b=>b.onclick=()=>{const f=d.features[+b.dataset.poiIndex],[lon,lat]=f.geometry.coordinates;fly({name:f.properties.name,latitude:lat,longitude:lon},650);inspect(f);});
    status(`${d.features.length} reale Karteneinträge gefunden`);V.scene.requestRender();return d;
  }
  function pause(){visible=false;tileEpoch++;abortController?.abort();stopOrbit();if(V)V.useDefaultRenderLoop=false;}
  function stopOrbit(){clearInterval(orbitTimer);orbitTimer=0;q('#worldOrbit')?.setAttribute('aria-pressed','false');if(V)V.camera.lookAtTransform(C.Matrix4.IDENTITY);}
  function bind(){
    q('#worldSearchForm').onsubmit=e=>{e.preventDefault();search(q('#worldSearch').value).catch(e=>error(e.message));};
    q('#worldImagery').onclick=()=>{imagery=imagery==='satellite'?'map':'satellite';setImagery();};
    q('#worldRetry').onclick=()=>{failed.clear();q('#worldError').hidden=true;if(!V)open();else stream();};
    q('#worldHome').onclick=()=>fly({name:'Wien · Stephansplatz',latitude:48.20849,longitude:16.37315});
    q('#worldAustria').onclick=()=>fly({name:'Österreich',latitude:47.6,longitude:14.15},650000);
    q('#worldEurope').onclick=()=>fly({name:'Europa',latitude:50.4,longitude:12.5},4200000);
    q('#worldLocate').onclick=()=>navigator.geolocation?navigator.geolocation.getCurrentPosition(p=>fly({name:'Mein Standort',latitude:p.coords.latitude,longitude:p.coords.longitude}),e=>error(e.message),{timeout:12000,maximumAge:60000}):error('Standortabfrage nicht unterstützt.');
    q('#worldNorth').onclick=()=>{if(V)V.camera.flyTo({destination:V.camera.positionWC.clone(),orientation:{heading:0,pitch:V.camera.pitch,roll:0},duration:reduced()?0:.6});};
    q('#worldTop').onclick=()=>{if(!V)return;const c=viewCenter();if(c)V.camera.flyToBoundingSphere(new C.BoundingSphere(C.Cartesian3.fromRadians(c.longitude,c.latitude),80),{duration:reduced()?0:.7,offset:new C.HeadingPitchRange(0,C.Math.toRadians(-90),1800)});};
    q('#worldOrbit').onclick=()=>{if(!V)return;if(orbitTimer){stopOrbit();return;}if(reduced()){status('Rundflug ist bei reduzierter Bewegung deaktiviert.');return;}const c=viewCenter();if(!c)return;const center=C.Cartesian3.fromRadians(c.longitude,c.latitude);V.camera.lookAt(center,new C.HeadingPitchRange(V.camera.heading,C.Math.toRadians(-40),1600));q('#worldOrbit').setAttribute('aria-pressed','true');orbitTimer=setInterval(()=>{if(!visible||document.hidden){stopOrbit();return;}V.camera.rotateRight(.003);V.scene.requestRender();},50);};
    document.querySelectorAll('[data-world-layer]').forEach(b=>b.onclick=()=>{const key=b.dataset.worldLayer;layers[key]=!layers[key];b.setAttribute('aria-pressed',String(layers[key]));objects.forEach(o=>{if((key==='buildings'&&o.kind==='building')||(key==='roads'&&o.kind==='road')||(key==='places'&&o.kind==='poi'))o.entities.forEach(e=>e.show=layers[key]);});if(key==='buildings'&&loadedTileset)loadedTileset.show=layers[key];V?.scene.requestRender();});
    document.querySelectorAll('[data-nearby]').forEach(b=>b.onclick=()=>findPlaces(b.dataset.nearby).catch(e=>error(e.message)));
    q('#worldQuality').onchange=e=>{if(!V)return;const high=e.target.value==='high';V.resolutionScale=high?Math.min(1,2/devicePixelRatio):Math.min(.8,1.25/devicePixelRatio);V.shadows=high;V.scene.globe.maximumScreenSpaceError=high?2:4;V.scene.requestRender();};
    new ResizeObserver(()=>{if(V&&visible){V.resize();V.scene.requestRender();}}).observe(q('#worldCanvas'));
    document.addEventListener('visibilitychange',()=>{if(document.hidden){stopOrbit();if(V)V.useDefaultRenderLoop=false;}else if(visible&&V){V.useDefaultRenderLoop=true;V.scene.requestRender();}});
    new MutationObserver(()=>{const active=document.body.dataset.dashboardView==='citylab';if(!active&&visible)pause();else if(active&&!visible)open();}).observe(document.body,{attributes:true,attributeFilter:['data-dashboard-view']});
  }
  /* Programmatic camera control used by hand tracking (two-hand zoom/pan/twist/tilt). All no-ops until the engine exists. */
  window.JarvisWorldControl={
    ready:()=>!!V,
    state(){if(!V)return null;const c=V.camera,g=c.positionCartographic;return{height:g.height,heading:c.heading,pitch:c.pitch,lon:g.longitude,lat:g.latitude};},
    zoom(factor){if(!V||!(factor>0))return;const h=V.camera.positionCartographic.height,f=Math.min(1.5,Math.max(.67,factor));const amount=h*(1-1/f);if(amount>0)V.camera.zoomIn(amount);else V.camera.zoomOut(-amount);V.scene.requestRender();},
    pan(dx,dy){if(!V)return;const h=Math.max(50,V.camera.positionCartographic.height);if(dx)V.camera[dx>0?'moveLeft':'moveRight'](Math.abs(dx)*h*1.4);if(dy)V.camera[dy>0?'moveUp':'moveDown'](Math.abs(dy)*h*1.1);V.scene.requestRender();},
    twist(angle){if(!V||!angle)return;const c=V.camera;c.setView({orientation:{heading:c.heading+angle,pitch:c.pitch,roll:0}});V.scene.requestRender();},
    tilt(d){if(!V||!d)return;const c=V.camera;c.setView({orientation:{heading:c.heading,pitch:Math.min(-.12,Math.max(-1.55,c.pitch+d)),roll:0}});V.scene.requestRender();}
  };
  window.JarvisWorld={open,search,fly,findPlaces,pause,inspect,get current(){return current;},diagnostics:()=>({engine:!!V,objects:objects.size,buildings:[...objects.values()].filter(o=>o.kind==='building').length,tiles:tileCache.size,terrain:hasTerrain,ion:ionBuildings,streaming,webgl:!!V?.scene.context,rendering:V?.useDefaultRenderLoop})};
  window.openGlobe=async p=>{window.jarvisShowView?.('citylab');return open(p);};
  window.jarvisCityLabSearch=p=>{window.jarvisShowView?.('citylab');return search(p);};
  bind();
})();
