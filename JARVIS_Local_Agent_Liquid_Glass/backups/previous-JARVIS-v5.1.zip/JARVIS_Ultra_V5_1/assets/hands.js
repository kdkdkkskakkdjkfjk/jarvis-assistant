/* JARVIS hand control.
 * - Camera starts ONLY after an explicit click (or keyboard shortcut / voice command) and is
 *   fully released (tracks stopped) on disable, tab hide, or page unload.
 * - Frames are processed locally in the browser; nothing is uploaded or stored.
 * - MediaPipe Tasks Vision (Apache-2.0) is loaded from assets/vendor/mediapipe (run
 *   scripts/fetch_handtracking.py once). Without local files the user is asked before the
 *   pinned CDN copy is used.
 * Every gesture has a mouse/keyboard equivalent (see KEYS below). */
((root) => {
  'use strict';
  const G = root.JarvisGestures;
  if (!G) { console.warn('gesture-engine.js fehlt'); return; }
  const $ = s => document.querySelector(s);
  const LS = 'jarvis_hands_v1';
  const MP_VERSION = '0.10.14';
  const LOCAL = 'assets/vendor/mediapipe/';
  const CDN = `https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@${MP_VERSION}`;
  const MODEL_LOCAL = LOCAL + 'hand_landmarker.task';
  const MODEL_CDN = 'https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task';
  const VIEW_ORDER = () => [...document.querySelectorAll('.desk-rail .rail-btn[data-view]')].map(b => b.dataset.view).filter((v, i, a) => v !== 'cameras' && a.indexOf(v) === i);

  const defaults = { sensitivity: 1, smoothing: .6, preview: true, mirror: true, palmAction: 'pause', swipeAction: 'views', scrollAction: 'scroll', pinchOn: .30 };
  let cfg = Object.assign({}, defaults);
  try { Object.assign(cfg, JSON.parse(localStorage.getItem(LS) || '{}')); } catch (_) {}
  const save = () => { try { localStorage.setItem(LS, JSON.stringify(cfg)); } catch (_) {} };

  const S = { on: false, status: 'off', stream: null, video: null, lm: null, raf: 0, vfc: 0, paused: false, lastTs: -1, fps: 0, frames: 0, fpsT: 0, engine: null, loading: false, hover: null, held: null, cursor: { x: .5, y: .5 }, lowLight: 0, noHandSince: 0, pending: null };
  const say = (msg, kind) => { const el = $('#handStatus'); if (el) { el.textContent = msg; el.dataset.kind = kind || ''; } };
  const setState = (st, msg) => {
    S.status = st; document.body.dataset.hands = st;
    const b = $('#handToggle'); if (b) { b.setAttribute('aria-pressed', String(st === 'active' || st === 'paused' || st === 'starting')); b.dataset.state = st; }
    const chip = $('#handChipText'); if (chip) chip.textContent = ({ off: 'Handsteuerung aus', starting: 'Startet …', active: 'Hand aktiv', paused: 'Pausiert', lost: 'Keine Hand', error: 'Fehler' })[st] || st;
    if (msg) say(msg, st === 'error' ? 'err' : '');
  };

  /* ---------- UI (built with the existing design tokens) ---------- */
  function buildUI() {
    if ($('#handDock')) return;
    const dock = document.createElement('div'); dock.id = 'handDock'; dock.className = 'hand-dock';
    dock.innerHTML = `
      <button id="handToggle" class="hand-chip" type="button" aria-pressed="false" aria-haspopup="dialog" title="Handsteuerung ein/aus (Alt+H)">
        <i class="hand-dot" aria-hidden="true"></i><span id="handChipText">Handsteuerung aus</span></button>
      <div id="handPanel" class="hand-panel" role="dialog" aria-label="Handsteuerung" hidden>
        <div class="hand-panel-head"><strong>Handsteuerung</strong><button id="handClose" type="button" aria-label="Schließen">✕</button></div>
        <p class="hand-note">Die Kamera wird nur nach deinem Klick gestartet. Bilder werden lokal ausgewertet, nicht gespeichert und nicht gesendet.</p>
        <div class="hand-preview" id="handPreviewBox"><video id="handVideo" playsinline muted></video><canvas id="handOverlay"></canvas><span class="hand-preview-empty">Kamera aus</span></div>
        <div id="handStatus" class="hand-status" role="status" aria-live="polite">Aus. Alt+H oder Schalter drücken.</div>
        <div class="hand-actions"><button id="handStart" type="button" class="hand-primary">Kamera starten</button><button id="handPause" type="button" disabled>Pause</button></div>
        <label>Empfindlichkeit <output id="handSensOut"></output><input id="handSens" type="range" min=".5" max="2" step=".1"></label>
        <label>Glättung <output id="handSmoothOut"></output><input id="handSmooth" type="range" min="0" max=".9" step=".05"></label>
        <label>Pinch-Schwelle <output id="handPinchOut"></output><input id="handPinch" type="range" min=".2" max=".45" step=".01"></label>
        <label class="hand-row"><span>Kameravorschau</span><input id="handPrev" type="checkbox"></label>
        <label class="hand-row"><span>Offene Handfläche (halten)</span><select id="handPalm"><option value="pause">Steuerung pausieren/fortsetzen</option><option value="home">Zum Kontrollraum</option><option value="stop">Antwort/Sprache stoppen</option><option value="none">Nichts</option></select></label>
        <label class="hand-row"><span>Wischen</span><select id="handSwipe"><option value="views">Panels wechseln</option><option value="none">Nichts</option></select></label>
        <button id="handCal" type="button">Kalibrieren (Hand ruhig zeigen)</button>
        <details class="hand-keys"><summary>Tastatur-Alternativen</summary><ul>
          <li><kbd>Alt</kbd>+<kbd>H</kbd> Handsteuerung ein/aus</li><li><kbd>Alt</kbd>+<kbd>←</kbd>/<kbd>→</kbd> Panel wechseln (Wischen)</li>
          <li><kbd>Alt</kbd>+<kbd>↑</kbd>/<kbd>↓</kbd> Scrollen</li><li>Maus/Enter statt Pinch</li><li>Hologramm: Pfeiltasten, <kbd>+</kbd>/<kbd>-</kbd>, <kbd>Q</kbd>/<kbd>E</kbd>, <kbd>R</kbd></li></ul></details>
        <details class="hand-keys"><summary>Gesten</summary><ul>
          <li>Pinch (Daumen+Zeigefinger): auswählen</li><li>Pinch halten + bewegen: ziehen / Karte bewegen</li>
          <li>Zwei Hände pinchen, auseinander/drehen: zoomen/drehen (Karte, Hologramm)</li>
          <li>Offene Hand schnell seitlich: Panel wechseln</li><li>Zeige- + Mittelfinger hoch, vertikal bewegen: scrollen</li><li>Offene Handfläche ~0,7 s halten: konfigurierte Aktion</li></ul></details>
      </div>`;
    (document.querySelector('.desk-top-actions') || document.body).appendChild(dock);
    document.body.appendChild($('#handPanel')); // panel lives at the page root so no parent stacking context can cover it
    const cur = document.createElement('div'); cur.id = 'handCursor'; cur.className = 'hand-cursor'; cur.hidden = true; cur.setAttribute('aria-hidden', 'true'); document.body.appendChild(cur);
    $('#handSens').value = cfg.sensitivity; $('#handSmooth').value = cfg.smoothing; $('#handPinch').value = cfg.pinchOn;
    $('#handPrev').checked = cfg.preview; $('#handPalm').value = cfg.palmAction; $('#handSwipe').value = cfg.swipeAction;
    syncOut();
    $('#handToggle').addEventListener('click', e => { const p = $('#handPanel'); if (S.on) { p.hidden = !p.hidden; } else { p.hidden = false; } });
    $('#handClose').addEventListener('click', () => { $('#handPanel').hidden = true; $('#handToggle').focus(); });
    $('#handStart').addEventListener('click', () => S.on ? disable('Kamera gestoppt.') : enable());
    $('#handPause').addEventListener('click', togglePause);
    const upd = () => { cfg.sensitivity = +$('#handSens').value; cfg.smoothing = +$('#handSmooth').value; cfg.pinchOn = +$('#handPinch').value; cfg.preview = $('#handPrev').checked; cfg.palmAction = $('#handPalm').value; cfg.swipeAction = $('#handSwipe').value; save(); syncOut(); applyCfg(); };
    ['handSens', 'handSmooth', 'handPinch'].forEach(id => $('#' + id).addEventListener('input', upd));
    ['handPrev', 'handPalm', 'handSwipe'].forEach(id => $('#' + id).addEventListener('change', upd));
    $('#handCal').addEventListener('click', calibrate);
    setState('off');
  }
  const syncOut = () => { $('#handSensOut').textContent = cfg.sensitivity.toFixed(1) + '×'; $('#handSmoothOut').textContent = Math.round(cfg.smoothing * 100) + ' %'; $('#handPinchOut').textContent = cfg.pinchOn.toFixed(2); };
  function applyCfg() {
    S.engine?.setConfig({ sensitivity: cfg.sensitivity, smoothing: cfg.smoothing, pinchOn: cfg.pinchOn, pinchOff: Math.min(.6, cfg.pinchOn + .16) });
    const pb = $('#handPreviewBox'); if (pb) pb.dataset.hidden = String(!cfg.preview);
  }

  /* ---------- MediaPipe loading ---------- */
  async function localAvailable() {
    try { const r = await fetch('/api/diagnostics'); return r.ok && !!(await r.json()).vendor?.mediapipe; } catch (_) { return false; }
  }
  async function loadLandmarker() {
    if (S.lm) return S.lm;
    let base = LOCAL, model = MODEL_LOCAL, bundle = LOCAL + 'vision_bundle.mjs', wasm = LOCAL + 'wasm';
    if (!(await localAvailable())) {
      const ok = confirm('Die Handerkennung (MediaPipe) ist noch nicht lokal installiert.\n\nOK: einmalig aus dem Internet laden (cdn.jsdelivr.net und storage.googleapis.com), danach vom Browser zwischengespeichert.\nAbbrechen: nichts laden.\n\nDauerhaft offline: python scripts/fetch_handtracking.py ausführen.');
      if (!ok) throw Object.assign(new Error('Handerkennung nicht geladen (keine Zustimmung).'), { code: 'declined' });
      bundle = CDN + '/vision_bundle.mjs'; wasm = CDN + '/wasm'; model = MODEL_CDN;
    }
    say('Handmodell wird geladen …');
    const mod = await import(/* @vite-ignore */ bundle);
    const fileset = await mod.FilesetResolver.forVisionTasks(wasm);
    const mk = delegate => mod.HandLandmarker.createFromOptions(fileset, { baseOptions: { modelAssetPath: model, delegate }, runningMode: 'VIDEO', numHands: 2, minHandDetectionConfidence: .55, minHandPresenceConfidence: .5, minTrackingConfidence: .5 });
    try { S.lm = await mk('GPU'); S.delegate = 'GPU'; } catch (e) { S.lm = await mk('CPU'); S.delegate = 'CPU'; }
    return S.lm;
  }

  /* ---------- camera lifecycle ---------- */
  async function enable() {
    if (S.on || S.loading) return;
    if (!navigator.mediaDevices?.getUserMedia) { setState('error', 'Dieser Browser bietet keinen Kamerazugriff. Verwende Chrome/Edge über http://localhost. Maus und Tastatur funktionieren weiter.'); return; }
    S.loading = true; setState('starting', 'Kamera wird angefordert …'); $('#handStart').disabled = true;
    try {
      S.stream = await navigator.mediaDevices.getUserMedia({ video: { width: { ideal: 640 }, height: { ideal: 480 }, frameRate: { ideal: 30, max: 30 }, facingMode: 'user' }, audio: false });
    } catch (e) {
      S.loading = false; $('#handStart').disabled = false;
      const msg = e.name === 'NotAllowedError' ? 'Kamerazugriff abgelehnt. Erlaube die Kamera im Schloss-Symbol der Adressleiste und starte erneut. Maus und Tastatur funktionieren weiter.'
        : e.name === 'NotFoundError' ? 'Keine Kamera gefunden. Schließe eine Webcam an.' : e.name === 'NotReadableError' ? 'Die Kamera wird von einem anderen Programm verwendet.' : `Kamera nicht verfügbar (${e.name || 'Fehler'}).`;
      setState('error', msg); return;
    }
    try {
      const v = $('#handVideo'); v.srcObject = S.stream; await v.play(); S.video = v;
      S.stream.getVideoTracks()[0]?.addEventListener('ended', () => disable('Die Kamera wurde getrennt.', 'error'));
      await loadLandmarker();
    } catch (e) {
      S.loading = false; releaseCamera(); $('#handStart').disabled = false;
      setState(e.code === 'declined' ? 'off' : 'error', e.code === 'declined' ? e.message : `Handerkennung konnte nicht gestartet werden: ${e.message || e}. Prüfe die Internetverbindung oder führe scripts/fetch_handtracking.py aus.`); return;
    }
    S.loading = false; S.on = true; S.paused = false;
    S.engine = G.createEngine({ sensitivity: cfg.sensitivity, smoothing: cfg.smoothing, pinchOn: cfg.pinchOn, pinchOff: Math.min(.6, cfg.pinchOn + .16) });
    applyCfg(); document.body.classList.add('hands-on');
    $('#handStart').disabled = false; $('#handStart').textContent = 'Kamera stoppen'; $('#handPause').disabled = false; $('#handPause').textContent = 'Pause';
    $('#handPreviewBox').classList.add('live');
    setState('active', `Aktiv (${S.delegate}). Zeige eine Hand in die Kamera.`); loopStart();
  }
  function releaseCamera() {
    if (S.vfc && S.video?.cancelVideoFrameCallback) try { S.video.cancelVideoFrameCallback(S.vfc); } catch (_) {}
    if (S.raf) cancelAnimationFrame(S.raf); S.raf = 0; S.vfc = 0;
    S.stream?.getTracks().forEach(t => t.stop()); S.stream = null;
    const v = $('#handVideo'); if (v) { v.pause(); v.srcObject = null; }
  }
  function disable(msg, state) {
    if (S.engine) dispatch(S.engine.reset());
    S.on = false; S.paused = false; S.loading = false; releaseCamera();
    try { S.lm?.close?.(); } catch (_) {} S.lm = null; // free WASM/GPU memory
    document.body.classList.remove('hands-on'); clearHover(); const c = $('#handCursor'); if (c) c.hidden = true;
    $('#handStart') && ($('#handStart').textContent = 'Kamera starten', $('#handStart').disabled = false); $('#handPause') && ($('#handPause').disabled = true);
    $('#handPreviewBox')?.classList.remove('live'); clearOverlay();
    setState(state || 'off', msg || 'Aus. Kamera freigegeben.');
  }
  function togglePause() {
    if (!S.on) return; S.paused = !S.paused;
    if (S.paused) { dispatch(S.engine.reset()); const c = $('#handCursor'); c.hidden = true; clearHover(); setState('paused', 'Pausiert. Kamera läuft weiter; offene Handfläche halten oder Pause drücken.'); $('#handPause').textContent = 'Fortsetzen'; }
    else { setState('active', 'Aktiv.'); $('#handPause').textContent = 'Pause'; }
  }
  document.addEventListener('visibilitychange', () => { if (document.hidden && S.on) disable('Kamera gestoppt, weil der Tab verborgen wurde.'); });
  addEventListener('pagehide', () => { if (S.on) disable(); });

  /* ---------- detection loop (throttled, only while needed) ---------- */
  function loopStart() {
    const v = S.video, useVfc = 'requestVideoFrameCallback' in HTMLVideoElement.prototype;
    const tick = (now, meta) => {
      if (!S.on) return;
      const ts = performance.now();
      if (v.readyState >= 2 && v.currentTime !== S.lastTs) {
        S.lastTs = v.currentTime;
        let res = null; try { res = S.lm.detectForVideo(v, ts); } catch (e) { console.warn('detect', e); }
        onResult(res, ts);
      }
      S.vfc = useVfc ? v.requestVideoFrameCallback(tick) : 0; if (!useVfc) S.raf = requestAnimationFrame(tick);
    };
    if (useVfc) S.vfc = v.requestVideoFrameCallback(tick); else S.raf = requestAnimationFrame(tick);
  }
  function onResult(res, ts) {
    S.frames++; if (ts - S.fpsT > 1000) { S.fps = S.frames; S.frames = 0; S.fpsT = ts; const f = $('#handFps'); if (f) f.textContent = S.fps; }
    const hands = (res?.landmarks || []).map((lm, i) => ({ landmarks: lm.map(p => ({ x: cfg.mirror ? 1 - p.x : p.x, y: p.y, z: p.z })), handedness: res.handednesses?.[i]?.[0]?.categoryName }));
    S._cal?.(hands); drawOverlay(hands);
    if (!hands.length) { S.noHandSince = S.noHandSince || ts; if (ts - S.noHandSince > 2500 && S.status === 'active') hintLowLight(); }
    else { S.noHandSince = 0; S.lowLight = 0; }
    if (S.paused) { // while paused only the palm-hold may resume
      const ev = S.engine.update(hands, ts).filter(e => e.type === 'palmHold'); if (ev.length) togglePause(); return;
    }
    dispatch(S.engine.update(hands, ts));
  }
  function hintLowLight() {
    // coarse brightness probe of the preview frame, only when no hand is found
    try {
      const c = document.createElement('canvas'); c.width = 32; c.height = 24; const x = c.getContext('2d', { willReadFrequently: true });
      x.drawImage(S.video, 0, 0, 32, 24); const d = x.getImageData(0, 0, 32, 24).data; let s = 0; for (let i = 0; i < d.length; i += 4) s += d[i] * .3 + d[i + 1] * .59 + d[i + 2] * .11;
      const avg = s / (d.length / 4); say(avg < 45 ? 'Zu dunkel für die Handerkennung. Mehr Licht von vorne einschalten.' : 'Keine Hand sichtbar. Hand mit offener Fläche in das Kamerabild halten.', avg < 45 ? 'warn' : '');
    } catch (_) {}
  }

  /* ---------- preview overlay ---------- */
  const BONES = [[0, 1], [1, 2], [2, 3], [3, 4], [0, 5], [5, 6], [6, 7], [7, 8], [5, 9], [9, 10], [10, 11], [11, 12], [9, 13], [13, 14], [14, 15], [15, 16], [13, 17], [17, 18], [18, 19], [19, 20], [0, 17]];
  function clearOverlay() { const c = $('#handOverlay'); if (c) c.getContext('2d').clearRect(0, 0, c.width, c.height); }
  function drawOverlay(hands) {
    if (!cfg.preview) return; const c = $('#handOverlay'); if (!c) return;
    const w = c.clientWidth | 0, h = c.clientHeight | 0; if (c.width !== w) c.width = w; if (c.height !== h) c.height = h;
    const x = c.getContext('2d'); x.clearRect(0, 0, w, h); x.lineWidth = 1.5; x.strokeStyle = getComputedStyle(document.documentElement).getPropertyValue('--u-accent').trim() || '#83e8d2'; x.fillStyle = x.strokeStyle;
    for (const hd of hands) {
      const L = hd.landmarks; x.globalAlpha = .75; x.beginPath(); for (const [a, b] of BONES) { x.moveTo(L[a].x * w, L[a].y * h); x.lineTo(L[b].x * w, L[b].y * h); } x.stroke();
      x.globalAlpha = 1; for (const i of [4, 8]) { x.beginPath(); x.arc(L[i].x * w, L[i].y * h, 3, 0, 7); x.fill(); }
    }
  }

  /* ---------- gesture → UI actions ---------- */
  const toPx = p => ({ x: p.x * innerWidth, y: p.y * innerHeight });
  const isHandUi = el => !!el?.closest?.('#handDock, #handPanel, #handCursor');
  function targetAt(p) { const c = $('#handCursor'); if (c) c.style.pointerEvents = 'none'; return document.elementFromPoint(p.x, p.y); }
  const interactive = el => el?.closest?.('button, a[href], input, select, textarea, summary, [role=button], [data-ask], .u-overview-card, .rail-btn, .world-matches button, [tabindex]:not([tabindex="-1"])');
  function clearHover() { S.hover?.classList.remove('hand-hover'); S.hover = null; }
  function setHover(el) { if (el === S.hover) return; clearHover(); if (el) { el.classList.add('hand-hover'); S.hover = el; } }
  function fire(el, type, p, extra) {
    if (!el) return; const init = Object.assign({ bubbles: true, cancelable: true, composed: true, clientX: p.x, clientY: p.y, screenX: p.x, screenY: p.y, button: 0, buttons: type.endsWith('up') ? 0 : 1, pointerId: 77, pointerType: 'mouse', isPrimary: true, view: window }, extra || {});
    const isPtr = type.startsWith('pointer'); el.dispatchEvent(isPtr ? new PointerEvent(type, init) : new MouseEvent(type, init));
  }
  const world = () => root.JarvisWorldControl;
  const holoOn = () => document.body.dataset.dashboardView === 'holo' && root.JarvisHolo;
  const canvasUnder = el => el?.closest?.('#worldCanvas, #holoCanvas');

  function dispatch(events) {
    for (const e of events) {
      switch (e.type) {
        case 'move': {
          const p = toPx(e), c = $('#handCursor'); S.cursor = p;
          c.hidden = false; c.style.transform = `translate(${p.x}px,${p.y}px)`; c.dataset.pose = e.pose; c.classList.toggle('pinch', e.pinch < cfg.pinchOn);
          if (S.status !== 'active') setState('active', 'Hand erkannt.');
          if (!S.held) { const t = targetAt(p); setHover(isHandUi(t) ? null : interactive(t)); }
          break; }
        case 'pinchStart': { const p = toPx(e), t = targetAt(p); S.held = { el: t, p, moved: false, drag: null }; $('#handCursor').classList.add('down'); break; }
        case 'click': {
          $('#handCursor').classList.remove('down'); const p = toPx(e), t = S.held?.el || targetAt(p); S.held = null; if (!t) break;
          const el = interactive(t);
          if (el && !el.disabled) { rippleAt(p); el.focus?.({ preventScroll: true }); el.click(); }
          else if (canvasUnder(t)) { fire(t, 'pointerdown', p); fire(t, 'mousedown', p); fire(t, 'pointerup', p); fire(t, 'mouseup', p); fire(t, 'click', p); rippleAt(p); }
          break; }
        case 'dragStart': {
          const h = S.held; if (!h) break; const el = h.el;
          const win = el?.closest?.('[data-hand-draggable]');
          if (win) h.drag = { kind: 'window', win, ox: parseFloat(win.dataset.dx || 0), oy: parseFloat(win.dataset.dy || 0), start: h.p };
          else if (canvasUnder(el)) { h.drag = { kind: 'canvas', el: canvasUnder(el) }; fire(h.drag.el, 'pointerdown', h.p); fire(h.drag.el, 'mousedown', h.p); }
          else if (el?.matches?.('input[type=range]')) h.drag = { kind: 'range', el };
          else h.drag = { kind: 'scrollpan', start: h.p, top: scroller()?.scrollTop || 0 };
          break; }
        case 'drag': {
          const h = S.held; if (!h?.drag) break; const p = toPx(e), d = h.drag;
          if (d.kind === 'window') { const dx = d.ox + p.x - d.start.x, dy = d.oy + p.y - d.start.y; d.win.dataset.dx = dx; d.win.dataset.dy = dy; d.win.style.translate = `${dx}px ${dy}px`; }
          else if (d.kind === 'canvas') { fire(d.el, 'pointermove', p); fire(d.el, 'mousemove', p); }
          else if (d.kind === 'range') { const r = d.el.getBoundingClientRect(), f = Math.min(1, Math.max(0, (p.x - r.left) / r.width)); d.el.value = (+d.el.min) + f * (+d.el.max - +d.el.min); d.el.dispatchEvent(new Event('input', { bubbles: true })); }
          else if (d.kind === 'scrollpan') { const s = scroller(); if (s) s.scrollTop = d.top - (p.y - d.start.y); }
          break; }
        case 'dragEnd': case 'pinchCancel': {
          const h = S.held; $('#handCursor').classList.remove('down'); S.held = null;
          if (h?.drag?.kind === 'canvas') { const p = toPx(e); fire(h.drag.el, 'pointerup', p); fire(h.drag.el, 'mouseup', p); }
          break; }
        case 'swipe': if (cfg.swipeAction === 'views') navigate(e.direction === 'right' ? -1 : 1); break;
        case 'scroll': case 'scrollStart': case 'scrollEnd': if (e.type === 'scroll') { const s = scroller(); if (s) s.scrollTop += e.dy * innerHeight; } break;
        case 'palmHold': palmAction(); break;
        case 'twoHandStart': S.two = { holo: !!holoOn(), world: !!world() && document.body.dataset.dashboardView === 'citylab' }; $('#handCursor').hidden = true; break;
        case 'twoHand': {
          if (S.two?.holo) { root.JarvisHolo.scaleBy(Math.pow(e.scaleStep, 1.4)); root.JarvisHolo.rotate(-e.dy * 4, e.dx * 6, e.rotateStep); }
          else if (S.two?.world) { world().zoom(Math.pow(e.scaleStep, 1.5)); world().pan(e.dx, e.dy); world().twist(-e.rotateStep); }
          break; }
        case 'twoHandEnd': S.two = null; break;
        case 'lost': clearHover(); $('#handCursor').hidden = true; $('#handCursor').classList.remove('down'); if (S.on && !S.paused) setState('lost', 'Hand verloren. Zeige sie wieder in die Kamera.'); break;
        case 'found': if (S.on && !S.paused) setState('active', 'Hand wieder erkannt.'); break;
      }
    }
  }
  function scroller() { return document.querySelector('.desk-main') || document.scrollingElement; }
  function rippleAt(p) { const r = document.createElement('i'); r.className = 'hand-ripple'; r.style.left = p.x + 'px'; r.style.top = p.y + 'px'; document.body.appendChild(r); setTimeout(() => r.remove(), 600); }
  function navigate(dir) {
    const order = VIEW_ORDER(); if (!order.length) return; const cur = document.body.dataset.dashboardView || 'home';
    let i = order.indexOf(cur); if (i < 0) i = 0; const next = order[(i + dir + order.length) % order.length];
    if (S.held) return; root.jarvisShowView?.(next);
    const names = { home: 'Kontrollraum', news: 'Nachrichten', earth: 'Karte', citylab: 'Welt', holo: 'Hologramm', connections: 'Verbindungen', devices: 'Smart Home', system: 'System' };
    say(`Panel: ${names[next] || next}`);
  }
  function palmAction() {
    if (cfg.palmAction === 'pause') togglePause();
    else if (cfg.palmAction === 'home') root.jarvisShowView?.('home');
    else if (cfg.palmAction === 'stop') { document.querySelector('#stopBtn, [data-stop], button[title*="stopp" i]')?.click(); speechSynthesis?.cancel?.(); }
  }
  function calibrate() {
    if (!S.on) { say('Zuerst die Kamera starten.', 'warn'); return; }
    if (S.paused) togglePause();
    say('Halte die Hand 3 Sekunden ruhig mit offener Fläche in die Kamera …');
    const samples = [];
    S._cal = hands => { const l = hands?.[0]?.landmarks; if (l) { const P = G.pose(l); if (P.open) samples.push(P.pinch); } };
    setTimeout(() => {
      S._cal = null;
      if (samples.length < 10) { say('Keine ruhige offene Hand erkannt. Mehr Licht verwenden und erneut versuchen.', 'warn'); return; }
      const mean = samples.reduce((a, b) => a + b, 0) / samples.length;
      // heuristic: pinch engages at ~28 % of the open-hand thumb/index spread
      cfg.pinchOn = Math.min(.4, Math.max(.2, +(mean * .28).toFixed(2))); $('#handPinch').value = cfg.pinchOn; save(); syncOut(); applyCfg();
      say(`Kalibriert: Pinch-Schwelle ${cfg.pinchOn.toFixed(2)}. Teste einen Pinch.`);
    }, 3000);
  }

  /* ---------- keyboard fallbacks ---------- */
  addEventListener('keydown', e => {
    if (!e.altKey || e.ctrlKey || e.metaKey) return;
    if (e.code === 'KeyH') { e.preventDefault(); S.on ? disable('Kamera gestoppt.') : ($('#handPanel').hidden = false, enable()); }
    else if (e.key === 'ArrowRight') { e.preventDefault(); navigate(1); } else if (e.key === 'ArrowLeft') { e.preventDefault(); navigate(-1); }
    else if (e.key === 'ArrowDown') { e.preventDefault(); const s = scroller(); s && (s.scrollTop += 240); } else if (e.key === 'ArrowUp') { e.preventDefault(); const s = scroller(); s && (s.scrollTop -= 240); }
  });
  addEventListener('keydown', e => { if (e.key === 'Escape' && $('#handPanel') && !$('#handPanel').hidden) { $('#handPanel').hidden = true; } });

  root.JarvisHands = { enable, disable: m => disable(m || 'Kamera gestoppt.'), toggle: () => (S.on ? disable('Kamera gestoppt.') : enable()), pause: togglePause, navigate, isOn: () => S.on, state: () => ({ status: S.status, paused: S.paused, fps: S.fps, delegate: S.delegate || null, config: Object.assign({}, cfg) }),
    /* test hook: feed landmark frames without a camera (used by browser tests) */
    _feed: (hands, ts) => dispatch((S.engine || (S.engine = G.createEngine(cfg))).update(hands, ts)) };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', buildUI); else buildUI();
})(typeof window === 'undefined' ? globalThis : window);
